from typing import List, Set, Tuple

from rmt.core import logger
from rmt.core.core_exceptions import UpdateError, UpdateValueError
from rmt.core.data_management.abstract_authoring_data_reader import AbstractAuthoringDataReader
from rmt.core.data_management.abstract_authoring_mapping_reader import AbstractAuthoringMappingReader
from rmt.core.data_management.abstract_contributors_reader import AbstractContributorsReader
from rmt.core.data_management.abstract_repository_folder_table_data_reader import AbstractRepositoryFolderTableDataReader
from rmt.core.data_management.abstract_repository_folder_table_data_writer import AbstractRepositoryFolderTableDataWriter
from rmt.core.data_management.abstract_repository_folder_table_mapping_reader import AbstractRepositoryFolderTableMappingReader
from rmt.core.data_management.abstract_repository_folder_table_mapping_writer import AbstractRepositoryFolderTableMappingWriter
from rmt.core.data_management.authoring_data_adapter import AuthoringDataAdapter
from rmt.core.data_management.authoring_mapping_adapter import AuthoringMappingAdapter
from rmt.core.data_management.contributor import Contributor, ContributorType
from rmt.core.data_management.contributor_repository_updater import ContributorRepositoryUpdater
from rmt.core.data_management.primitive_types import TableName
from rmt.core.data_management.repository import Repository
from rmt.core.data_management.table_data import TableData
from rmt.core.data_management.table_mapping import TableMapping
from rmt.core.data_management.tables_validator import TablesValidator


class RepositoryUpdater:
    """
    This class support the user story of updating
    the repository folder (=staging as currently apear in API, just different terminology)
    The class is responsible for updating the repository folder with the data and mapping of the customer contributor
    as read from the authoring data and mapping files (the csv files)
    for each given table data of customer it will override the data of the customer for that table in repository folder
    same for mapping. note we are only writing customer data and mapping to the repository folder
    if a customer authoring data for some table is same as the customer data for that table in repository
    it will not update the repository folder.same for mapping.
    if a customer authoring data or mapping for some table is not valid it will not update the repository folder at all
    and write an error to the log
    for the user to be able to follow errors and fix them we want to collect as much errors as we can
    and not stop at the first error.so first checking authoring data and mapping and then write all errors
    if all authoring data and mapping is valid then continue read from repository folder the data and mapping
    for the tables which appear in the authoring data and mapping, from all contributors to the repository class
    which represents the repository folder.
    then update the repository class with the customer data and mapping and get what was actually changed
    then validate the tables that was changed (with all data and mapping from all contributors)
    and if valid write the those tables data and mapping to the repository folder
    validations (as explained above are done first on the authoring data and mapping and then with all data and mapping from all contributors in the repository folder)
    1. each table data has unique keys and unique names
    2. each table mapping has unique source values across all target keys (no same source value for different target keys)
    3. each mapping target key must exist in the table data keys
    4. each data key from some contributor must be in the range of the contributor keys
    5. each contributor name in the authoring data and mapping must be a valid contributor name
    (the authoring data and mapping contains data and mapping from all contributors only for the user to follow, when we read we ignore
    authoring data and mapping from other contributors than the customer contributor, still we validate the contributors names
    in the authoring data and mapping to make sure the data or mapping is not corrupted)
    """
    @staticmethod
    def update_repository_folder_reference_data(
        authoring_data_reader: AbstractAuthoringDataReader,
        authoring_mapping_reader: AbstractAuthoringMappingReader,
        repository_contributors_reader: AbstractContributorsReader,
        repository_folder_table_mapping_reader: AbstractRepositoryFolderTableMappingReader,
        repository_folder_table_data_reader: AbstractRepositoryFolderTableDataReader,
        repository_folder_table_mapping_writer: AbstractRepositoryFolderTableMappingWriter,
        repository_folder_table_data_writer: AbstractRepositoryFolderTableDataWriter,
    ):
        # read contributors
        contributors = repository_contributors_reader.read()

        for contributor in contributors:
            if contributor.name == ContributorType.Customer.name:
                customer_contributor = contributor
                break
        if customer_contributor is None:
            logger.error("Customer contributor not found")
            return

        authoring_valid = True
        # read authoring table mapping
        try:
            customer_table_mapping_list, mapping_authoring_errors = RepositoryUpdater._get_customer_table_mapping_list(authoring_mapping_reader,
                                                                                                                       customer_contributor,
                                                                                                                       contributors)
            for error in mapping_authoring_errors:
                logger.error(f"{error}")
        except ValueError as e:
            logger.error(f"Error reading customer mapping authoring: {e}")
            authoring_valid = False

        # read authoring table data
        try:
            customer_table_data_list, data_authroing_errors = RepositoryUpdater._get_customer_table_date_list(authoring_data_reader,
                                                                                                              customer_contributor,
                                                                                                              contributors)
            for error in data_authroing_errors:
                logger.error(f"{error}")
        except ValueError as e:
            logger.error(f"Error reading customer data authoring: {e}")
            authoring_valid = False

        # return if not any authoring is not valid
        if not authoring_valid:
            raise UpdateError("No data was updated. Validation errors found.")

        # create repository and read data and mapping of the relevant tables from repository folder to repository class
        repository = RepositoryUpdater._get_repository_with_tables_data_and_mapping(
            contributors, repository_folder_table_mapping_reader, repository_folder_table_data_reader
        )

        # complete table data and mapping list of customer from repository (for deleted tables)
        customer_table_data_list = RepositoryUpdater._complete_table_data_list_of_contributor_from_repository(
            customer_contributor, repository, customer_table_data_list
        )

        customer_table_mapping_list = RepositoryUpdater._complete_table_mapping_list_of_contributor_from_repository(
            customer_contributor, repository, customer_table_mapping_list
        )

        # update repository with the customer data and mapping (and get what was updated)
        customer_repository_updater = ContributorRepositoryUpdater(repository, customer_contributor)
        updated_table_mapping_list = customer_repository_updater.set_table_mapping_list(customer_table_mapping_list)
        updated_table_data_list = customer_repository_updater.set_table_data_list(customer_table_data_list)

        # get union of updated table names
        updated_tables_names = RepositoryUpdater._get_table_names(updated_table_data_list, updated_table_mapping_list)

        # validate updated tables and if valid, write to updated data and mapping to repository folder
        tables_validator = TablesValidator(repository)
        if tables_validator.validate_tables(updated_tables_names) and len(mapping_authoring_errors + data_authroing_errors) == 0:
            logger.info("Validation passed. Updating repository folder with the updated data and mapping.")
            repository_folder_table_mapping_writer.write(customer_contributor.name, updated_table_mapping_list)
            repository_folder_table_data_writer.write(customer_contributor.name, updated_table_data_list)
        else:
            if tables_validator.validation_errors:
                for error in tables_validator.validation_errors:
                    logger.error(f"{error}")
            raise UpdateError("No data was updated. Validation errors found.")

    @staticmethod
    def _get_table_names(table_data_list: List[TableData], table_mapping_list: List[TableMapping]) -> Set[TableName]:
        return set([table_data.table_name for table_data in table_data_list] +
                   [table_mapping.table_name for table_mapping in table_mapping_list])

    @staticmethod
    def _get_customer_table_date_list(authoring_data_reader: AbstractAuthoringDataReader, customer_contributor: Contributor,
                                      contributors: Set[Contributor]) -> Tuple[List[TableData], List[UpdateValueError]]:
        authoring_data_entries, read_errors = authoring_data_reader.read(customer_contributor, contributors)
        authoring_data_adapter = AuthoringDataAdapter(contributors)
        table_data_list, convert_errors = authoring_data_adapter.get_table_data_for_contributor(authoring_data_entries, customer_contributor)
        return table_data_list, read_errors + convert_errors

    @staticmethod
    def _get_customer_table_mapping_list(authoring_mapping_reader: AbstractAuthoringMappingReader, customer_contributor: Contributor,
                                         contributors: Set[Contributor]) -> Tuple[List[TableMapping], List[UpdateValueError]]:
        authoring_mapping_entries, read_errors = authoring_mapping_reader.read(customer_contributor, contributors)
        authoring_mapping_adapter = AuthoringMappingAdapter(contributors)
        table_mapping_list, convert_errors = authoring_mapping_adapter.get_table_mapping_for_contributor(authoring_mapping_entries, customer_contributor)
        return table_mapping_list, read_errors + convert_errors

    @staticmethod
    def _complete_table_data_list_of_contributor_from_repository(customer_contributor: Contributor, repository: Repository,
                                                                 table_data_list: List[TableData]) -> List[TableData]:

        repository_table_names = repository.get_data_table_names_for_contributor(customer_contributor)
        authoring_table_names = set([table_data.table_name for table_data in table_data_list])
        for table_name in repository_table_names:
            if table_name not in authoring_table_names:
                table_data = TableData(table_name)
                table_data_list.append(table_data)
        return table_data_list

    @staticmethod
    def _complete_table_mapping_list_of_contributor_from_repository(customer_contributor: Contributor, repository: Repository,
                                                                    table_mapping_list: List[TableMapping]) -> List[TableMapping]:

        repository_table_names = repository.get_mapping_table_names_for_contributor(customer_contributor)
        authoring_table_names = set([table_mapping.table_name for table_mapping in table_mapping_list])
        for table_name in repository_table_names:
            if table_name not in authoring_table_names:
                table_mapping = TableMapping(table_name)
                table_mapping_list.append(table_mapping)
        return table_mapping_list

    @staticmethod
    def _get_repository_with_tables_data_and_mapping(
        contributors: Set[Contributor],
        repository_folder_table_mapping_reader: AbstractRepositoryFolderTableMappingReader,
        repository_folder_table_data_reader: AbstractRepositoryFolderTableDataReader,
    ) -> Repository:
        repository = Repository(contributors)

        for contributor in contributors:
            table_data_list = repository_folder_table_data_reader.read(contributor.name)
            repository.add_table_data_list(contributor, table_data_list)

            table_mapping_list = repository_folder_table_mapping_reader.read(contributor.name)
            repository.add_table_mapping_list(contributor, table_mapping_list)

        return repository

# SIG # Begin Windows Authenticode signature block
# MIIoLQYJKoZIhvcNAQcCoIIoHjCCKBoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCR3zxvnDKikSXF
# /W5y6EJ2sSksmrfcQ+pl0kwo0YZDXqCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOD+e/MVIQmSm0UEH2VqBozO
# EPJBbtA+6aZuA/NExzu4MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEANCuzc8dxdNFPdoYkqtb00S/h3lfgrAefbsI8LiZ4TrT9OuP7w92/IsG2
# oNVtmTwpkJreePaXwSiLjgBn+Vi3fh3NSlLemsUAyC880edMh9hUHctLuMlFH7i+
# hWRQJxNR2HbAF7y/WcBlE0rniA2Gbcf+1C1/2EM+5rHEYB2NIALCaq1WPoxunqwu
# FLf7PHRdi+zvN2oeaH/yVxsAIChlDKElDuT9IOKjh91BfkTcfUbAp4lL8T94WbKP
# WpvpjJTzqL/80IXFzpnm6hByKFtN/+0FtQwrut96edMDDPpz+lvQFBiFBdHnf7vR
# 3dg8cdi9yBpwbOBmzAGw9jodJ+Zw+6GCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCC
# F38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCYTUYLxHs4P2s/KPxIyJgyPYO2L4jmUhp3f6cxfkbuqgIGaEsezMp6
# GBMyMDI1MDcxNjA0MjIxMS45MDlaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046ODkwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHtMIIHIDCCBQigAwIBAgITMwAAAg4syyh9lSB1YwABAAACDjANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQz
# MDNaFw0yNjA0MjIxOTQzMDNaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046ODkwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCs5t7iRtXt0hbeo9ME78ZYjIo3saQuWMBFQ7X4s9vo
# oYRABTOf2poTHatx+EwnBUGB1V2t/E6MwsQNmY5XpM/75aCrZdxAnrV9o4Tu5sBe
# pbbfehsrOWRBIGoJE6PtWod1CrFehm1diz3jY3H8iFrh7nqefniZ1SnbcWPMyNIx
# uGFzpQiDA+E5YS33meMqaXwhdb01Cluymh/3EKvknj4dIpQZEWOPM3jxbRVAYN5J
# 2tOrYkJcdDx0l02V/NYd1qkvUBgPxrKviq5kz7E6AbOifCDSMBgcn/X7RQw630Qk
# zqhp0kDU2qei/ao9IHmuuReXEjnjpgTsr4Ab33ICAKMYxOQe+n5wqEVcE9OTyhmW
# ZJS5AnWUTniok4mgwONBWQ1DLOGFkZwXT334IPCqd4/3/Ld/ItizistyUZYsml/C
# 4ZhdALbvfYwzv31Oxf8NTmV5IGxWdHnk2Hhh4bnzTKosEaDrJvQMiQ+loojM7f5b
# gdyBBnYQBm5+/iJsxw8k227zF2jbNI+Ows8HLeZGt8t6uJ2eVjND1B0YtgsBP0cs
# BlnnI+4+dvLYRt0cAqw6PiYSz5FSZcbpi0xdAH/jd3dzyGArbyLuo69HugfGEEb/
# sM07rcoP1o3cZ8eWMb4+MIB8euOb5DVPDnEcFi4NDukYM91g1Dt/qIek+rtE88VS
# 8QIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFIVxRGlSEZE+1ESK6UGI7YNcEIjbMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQB14L2TL+L8OXLxnGSal2h30mZ7FsBFooiY
# kUVOY05F9pnwPTVufEDGWEpNNy2OfaUHWIOoQ/9/rjwO0hS2SpB0BzMAk2gyz92N
# GWOpWbpBdMvrrRDpiWZi/uLS4ZGdRn3P2DccYmlkNP+vaRAXvnv+mp27KgI79mJ9
# hGyCQbvtMIjkbYoLqK7sF7Wahn9rLjX1y5QJL4lvEy3QmA9KRBj56cEv/lAvzDq7
# eSiqRq/pCyqyc8uzmQ8SeKWyWu6DjUA9vi84QsmLjqPGCnH4cPyg+t95RpW+73sn
# hew1iCV+wXu2RxMnWg7EsD5eLkJHLszUIPd+XClD+FTvV03GfrDDfk+45flH/eKR
# Zc3MUZtnhLJjPwv3KoKDScW4iV6SbCRycYPkqoWBrHf7SvDA7GrH2UOtz1Wa1k27
# sdZgpG6/c9CqKI8CX5vgaa+A7oYHb4ZBj7S8u8sgxwWK7HgWDRByOH3CiJu4LJ8h
# 3TiRkRArmHRp0lbNf1iAKuL886IKE912v0yq55t8jMxjBU7uoLsrYVIoKkzh+sAk
# gkpGOoZL14+dlxVM91Bavza4kODTUlwzb+SpXsSqVx8nuB6qhUy7pqpgww1q4SNh
# AxFnFxsxiTlaoL75GNxPR605lJ2WXehtEi7/+YfJqvH+vnqcpqCjyQ9hNaVzuOEH
# X4MyuqcjwjCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQ
# MIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjg5MDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBK
# 6HY/ZWLnOcMEQsjkDAoB/JZWCKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7CEb0DAiGA8yMDI1MDcxNTE4MjYy
# NFoYDzIwMjUwNzE2MTgyNjI0WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDsIRvQ
# AgEAMAoCAQACAg1cAgH/MAcCAQACAhLzMAoCBQDsIm1QAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQELBQADggEBAASp4wp4YUI9uQN56JenI9IbLxFdW88V1zsSzkfNV6x6
# 76Ewx0JFRZxRkJntwOFaB61N17vyZH5q5h6VYZXIRdQsfIuYygt2u7qwCi95+P0h
# aiTPxt87TJx8luNGXkxk08zqBZUe5UOEQiTiH95wQWu8wn8p46/D930gm+lL5PEF
# SQBcV+Tl0QTiE0pwsugkAsiq3KHK8TH2cm1Pdd4N3gP6IM0inYJLdRpRPG7lJq85
# CqIRZkzPgfv77Pm7o0kwnquyn+R7hBp5LdyOCDwpXoq+vhFBAY5NTmsvY2tO4DSC
# eWlww4C69X2fu8izrBje3JNIvwkb4eEVKNg+a32UQNwxggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAg4syyh9lSB1YwABAAAC
# DjANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCBMBl+Q+dvkh9dQqL8Pp4bLJxPAHAECx7UZqrm20/mK
# pDCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIAF0HXMl8OmBkK267mxobKSi
# hwOdP0eUNXQMypPzTxKGMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAIOLMsofZUgdWMAAQAAAg4wIgQg7LIrRrdv8VzuwKA0fq46IXa0
# Z3HIuxntce8pPxKOQWcwDQYJKoZIhvcNAQELBQAEggIAn40P4wlr5IViAZCsSAbi
# rzLKk8tbmxzXTF4RdFogurbYVrGljxGSo/uEuXPoA2NRQ3ymKWFCdciOLbTwjgUv
# J6SOa78KoBiuwgf9kw3ldnpe/ZSGYlqlzUUTyIU+u83O957as6jr4xEF8g1a/4hG
# MnvNeV6ak87TgbplpLJo7SPFA6PuzO8N0joavLtPWdBHQC0S2I45j0B/ojpy93OK
# XYFPQoTq0lw3YKcnLNnsKJpMq56xHLVAnnWtn1yk2NtCOrj9P6lpMnpZG79Lybdf
# SNPQ0pcd0I/isF8kseGTQ+bBUoANpi1Av6ysW0h6l99CjvPlj+Z1b1QQZ+ICHONO
# 79DJgsL5fpYZLeI+QZ7V60dNvI0RlkgQvLVMvQK7q8ss4m0bNOz2XEJKNnDyOJlh
# TKCWeEW7lae/mRE2mNfMfX069IP7PGvNQ8VxtYGEx24ls4K311bM6hCpbg49YrSj
# fAeFn7yLe7RbevLWuTyb/YRnoKR/Rj8tFu3jA535a+NrIrmhtEZdWpnHgGhj4efE
# y0gmCAt3AHJLbdNK1pPp7zDYKV0XZxRiUKhV6UgypC4DprAxHUtkoTZ2BogpMnX6
# Yy+RKgdQbo4wTclwY/bYovMeWZ4nMLctIRpwh8xUD+t/PCty1lqth/5Eoq98yZX/
# V2jwgGZQtFsmtlIojNtw5aU=
# SIG # End Windows Authenticode signature block