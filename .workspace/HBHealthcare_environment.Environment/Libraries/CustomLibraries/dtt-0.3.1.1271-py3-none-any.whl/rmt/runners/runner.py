import traceback
from typing import List

from common.model.base_source_configuration import BaseSourceConfiguration
from pyspark.sql import SparkSession

import rmt.core.logger as logger
from rmt.app.authoring_files_generator import AuthoringFilesGenerator
from rmt.app.reference_tables_creator import ReferenceTablesCreator
from rmt.app.reference_values_mapper import ReferenceValuesMapper
from rmt.app.repository_updater import RepositoryUpdater
from rmt.contract.configuration.internal.rmt_spec_reader import RMTSpecReader
from rmt.core.core_exceptions import AuthoringFileError, AuthoringFilesGenerationError, UpdateError
from rmt.file_model.data_export.authoring_data_file_writer import AuthoringDataFileWriter
from rmt.file_model.data_export.authoring_mapping_file_writer import AuthoringMappingFileWriter
from rmt.file_model.data_management.authoring_data_file_reader import AuthoringDataFileReader
from rmt.file_model.data_management.authoring_mapping_file_reader import AuthoringMappingFileReader
from rmt.file_model.data_management.contributors_json_reader import ContributorsFileReader
from rmt.file_model.data_management.data_management_context import DataManagementContext
from rmt.file_model.data_management.repository_folder import RepositoryFolder
from rmt.file_model.data_management.repository_folder_table_data_reader import RepositoryFolderTableDataReader
from rmt.file_model.data_management.repository_folder_table_data_writer import RepositoryFolderTableDataWriter
from rmt.file_model.data_management.repository_folder_table_mapping_reader import RepositoryFolderTableMappingReader
from rmt.file_model.data_management.repository_folder_table_mapping_writer import RepositoryFolderTableMappingWriter
from rmt.file_model.tables_creating.reference_tables_data_file_reader import ReferenceTablesDataFileReader
from rmt.file_model.values_mapping.mapping_definitions_file_reader import MappingDefinitionsFileReader
from rmt.filesystem.file_system_client import FileSystemClient
from rmt.runners.paths_parameters_handler import PathsParametersHandler
from rmt.source_processor.source_processor import SourceProcessor

REFERENCE_MAPPING_PATH = "REFERENCE_MAPPING"


class Runner:
    def __init__(
        self,
        spark: SparkSession,
        file_system_client: FileSystemClient,
        rmt_spec_path: str,
    ) -> None:
        self._spark = spark
        self._file_system_client = file_system_client
        logger.info("RMT execution started")
        logger.info(f"RMT Spec file: {rmt_spec_path}")
        self._rmt_spec = RMTSpecReader.read(rmt_spec_path, file_system_client)
        self._paths_parameters_handler = PathsParametersHandler(file_system_client, self._rmt_spec.source_domain)

    def create_reference_values_mapping(self,
                                        ordered_mapping_definitions_folders: List[str] = None,
                                        number_of_partition_files: int = -1,
                                        staging_reference_data_folder_path=None):

        try:
            logger.info(
                f"Running RMT to map values using mapping definitions.Input parameters:"
                f"ordered_mapping_definitions_folders: {ordered_mapping_definitions_folders}, "
                f"number_of_partition_files: {number_of_partition_files}"
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )

            mapping_folder_paths = self._paths_parameters_handler.get_mapping_folder_paths(ordered_mapping_definitions_folders, staging_reference_data_folder_path)

            logger.info(f"Mapping from the following folders: {mapping_folder_paths}")
            mapping_definitions_reader = MappingDefinitionsFileReader(
                self._file_system_client,
                mapping_folder_paths,
                self._rmt_spec.reference_tables,
            )
            ReferenceValuesMapper.create_reference_values_mapping(
                self._spark,
                self._rmt_spec.source_domain,
                mapping_definitions_reader,
                self._file_system_client.join_paths(
                    self._rmt_spec.secondary_lake_location, REFERENCE_MAPPING_PATH
                ),
                number_of_partition_files,
            )

            logger.info("RMT execution ended")

        except Exception as e:
            logger.error(f"RMT ends with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def create_reference_data_tables(self,
                                     target_path: str,
                                     reference_tables_folders_paths: list[str] = None,
                                     staging_reference_data_folder_path=None):

        try:
            logger.info(
                f"Running RMT to create tables from data folders.Input parameters:"
                f"reference_tables_folders_paths: {reference_tables_folders_paths}, "
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )
            data_folder_paths = self._paths_parameters_handler.get_data_folder_paths(reference_tables_folders_paths, staging_reference_data_folder_path)

            logger.info(f"Creating reference tables from the following data folders {data_folder_paths}")
            file_reader = ReferenceTablesDataFileReader(
                self._file_system_client, data_folder_paths, set(self._rmt_spec.reference_tables.keys())
            )
            ReferenceTablesCreator.create_reference_data_tables(
                self._spark, target_path, self._rmt_spec.reference_tables, file_reader
            )

            logger.info("RMT execution ended")

        except Exception as e:
            logger.error(f"RMT ended with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def update_staging_reference_data(self, authoring_folder_path,
                                      staging_reference_data_folder_path: str):
        try:
            logger.info(
                f"Running RMT to update staging folder.Input Parameters:"
                f"authoring_folder_path: {authoring_folder_path}, "
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )

            self._paths_parameters_handler.raise_error_if_folder_not_exist(staging_reference_data_folder_path)
            self._paths_parameters_handler.raise_error_if_folder_not_exist(authoring_folder_path)

            authoring_repository_folder = RepositoryFolder(self._file_system_client,
                                                           self._rmt_spec.source_domain,
                                                           authoring_folder_path)

            authoring_data_management_context = DataManagementContext(self._file_system_client,
                                                                      authoring_folder_path,
                                                                      authoring_repository_folder,
                                                                      self._rmt_spec.reference_tables)

            staging_repository_folder = RepositoryFolder(self._file_system_client,
                                                         self._rmt_spec.source_domain,
                                                         staging_reference_data_folder_path)

            staging_data_management_context = DataManagementContext(self._file_system_client,
                                                                    authoring_folder_path,
                                                                    staging_repository_folder,
                                                                    self._rmt_spec.reference_tables)

            authoring_data_reader = AuthoringDataFileReader(authoring_data_management_context)
            authoring_mapping_reader = AuthoringMappingFileReader(authoring_data_management_context)
            repository_contributors_reader = ContributorsFileReader(staging_data_management_context)
            repository_folder_table_mapping_reader = RepositoryFolderTableMappingReader(staging_data_management_context)
            repository_folder_table_data_reader = RepositoryFolderTableDataReader(staging_data_management_context)
            repository_folder_table_mapping_writer = RepositoryFolderTableMappingWriter(staging_data_management_context)
            repository_folder_table_data_writer = RepositoryFolderTableDataWriter(staging_data_management_context)

            RepositoryUpdater.update_repository_folder_reference_data(authoring_data_reader,
                                                                      authoring_mapping_reader,
                                                                      repository_contributors_reader,
                                                                      repository_folder_table_mapping_reader,
                                                                      repository_folder_table_data_reader,
                                                                      repository_folder_table_mapping_writer,
                                                                      repository_folder_table_data_writer)
            logger.info("RMT execution ended")

        except UpdateError as ue:
            logger.error(f"RMT ends with error.{ue}")
            raise
        except AuthoringFileError as afe:
            logger.error(f"RMT ends with error.{afe}")
            raise
        except Exception as e:
            logger.error(f"RMT ended with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def generate_reference_data_authoring_files(self, target_authoring_folder_path: str, staging_reference_data_folder_path: str):

        try:

            logger.info(
                f"Running RMT to generate authoring files.Input Parameters:"
                f"target_authoring_folder_path: {target_authoring_folder_path}, "
                f"staging_reference_data_folder_path: {staging_reference_data_folder_path}"
            )

            self._paths_parameters_handler.raise_error_if_folder_not_exist(staging_reference_data_folder_path)
            repository_folder = RepositoryFolder(self._file_system_client, self._rmt_spec.source_domain, staging_reference_data_folder_path)
            data_management_context = DataManagementContext(self._file_system_client, target_authoring_folder_path, repository_folder, self._rmt_spec.reference_tables)

            source_processors = self._create_source_processors(list(self._rmt_spec.source_configurations))

            repository_folder_data_reader = RepositoryFolderTableDataReader(data_management_context)
            repository_folder_mapping_reader = RepositoryFolderTableMappingReader(data_management_context)

            authoring_data_writer = AuthoringDataFileWriter(self._spark, data_management_context)
            authoring_mapping_writer = AuthoringMappingFileWriter(self._spark, data_management_context)

            repository_contributors_reader = ContributorsFileReader(data_management_context)

            mapping_definitions_file_reader = MappingDefinitionsFileReader(self._file_system_client,
                                                                           [str(value) for value in repository_folder.get_mapping_folder_paths().values()],
                                                                           self._rmt_spec.reference_tables)

            AuthoringFilesGenerator.generate_reference_data_authoring_files(self._spark,
                                                                            self._rmt_spec.source_domain,
                                                                            source_processors,
                                                                            mapping_definitions_file_reader,
                                                                            repository_contributors_reader,
                                                                            repository_folder_mapping_reader,
                                                                            repository_folder_data_reader,
                                                                            authoring_data_writer,
                                                                            authoring_mapping_writer)
        except AuthoringFilesGenerationError as ge:
            logger.error(f"RMT ends with error.{ge}")
            raise
        except Exception as e:
            logger.error(f"RMT ended with error.{e}")
            logger.error(traceback.format_exc())
            raise

    def _create_source_processors(self, source_configs: list[BaseSourceConfiguration]) -> List[SourceProcessor]:

        if not source_configs:
            raise ValueError("No source configs found")

        processors = []
        for source_config in source_configs:
            processor = SourceProcessor(self._spark, source_config)
            try:
                processor.validate()
                processors.append(processor)
            except Exception as e:
                logger.error(f"Validation failed for source configuration {source_config.source_name} with error: {e}")
                raise EnvironmentError(f"Validation failed for source configuration {source_config.source_name} "
                                       f"with error {e}") from e

        return processors

# SIG # Begin Windows Authenticode signature block
# MIIoRgYJKoZIhvcNAQcCoIIoNzCCKDMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBpROqVlh3Wuq2e
# OCJUjiWPjzYzmsKcbzBz0CiSePyFbqCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiYwghoiAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPm4EKfBQp9JrC2d6tCAL2he
# nSH8k1dee5moQpAZXazRMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAfBqV0HbylXGHWRWrTTh6gJA2Qhpdpf9qAMz+FebGqZOWbiGHWY0IyQ51
# uUaQvcuvVQzxBg8yk2rezXcM9rPiCiPC50zyA3qqAP7288JcTq3GYUX7YUN+IUkC
# azajXzdC9hwYrhOKPHNwYOOAveP7neiAMOFbW2hwet0y2Jl8hSBSH3IxRlh/zgVh
# kvlzcjP1QA3NsC9nmO9h4nmgbK6n2s06g7GWkclj352kbtf66qsP1cKrpU/troLg
# X5wFvzfj7ph71rwhKzJQdU2JnJEdrdgaRkpf5rgLjIH+/cz2dW9aIYla/TxgZG0L
# OgLb9m8MWq4nHSiyaySrE892NQ7paqGCF7AwghesBgorBgEEAYI3AwMBMYIXnDCC
# F5gGCSqGSIb3DQEHAqCCF4kwgheFAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAnqEH9UBcrys1pR8ndEm0rL/wWAgpfU+HElPbSHt6YYwIGaFKvkeI4
# GBMyMDI1MDcxNjA0MjEyOS44NzFaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjozMjFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEf4wggcoMIIFEKADAgECAhMzAAAB+KOhJgwMQEj+AAEAAAH4MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzEwOFoXDTI1MTAyMjE4MzEwOFowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjMyMUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxR23pXYnD2BuODdeXs2C
# u/T5kKI+bAw8cbtN50Cm/FArjXyL4RTqMe6laQ/CqeMTxgckvZr1JrW0Mi4F15rx
# /VveGhKBmob45DmOcV5xyx7h9Tk59NAl5PNMAWKAIWf270SWAAWxQbpVIhhPWCnV
# V3otVvahEad8pMmoSXrT5Z7Nk1RnB70A2bq9Hk8wIeC3vBuxEX2E8X50IgAHsyaR
# 9roFq3ErzUEHlS8YnSq33ui5uBcrFOcFOCZILuVFVTgEqSrX4UiX0etqi7jUtKyp
# gIflaZcV5cI5XI/eCxY8wDNmBprhYMNlYxdmQ9aLRDcTKWtddWpnJtyl5e3gHuYo
# j8xuDQ0XZNy7ESRwJIK03+rTZqfaYyM4XSK1s0aa+mO69vo/NmJ4R/f1+KucBPJ4
# yUdbqJWM3xMvBwLYycvigI/WK4kgPog0UBNczaQwDVXpcU+TMcOvWP8HBWmWJQIm
# TZInAFivXqUaBbo3wAfPNbsQpvNNGu/12pg0F8O/CdRfgPHfOhIWQ0D8ALCY+Lsi
# wbzcejbrVl4N9fn2wOg2sDa8RfNoD614I0pFjy/lq1NsBo9V4GZBikzX7ZjWCRgd
# 1FCBXGpfpDikHjQ05YOkAakdWDT2bGSaUZJGVYtepIpPTAs1gd/vUogcdiL51o7s
# huHIlB6QSUiQ24XYhRbbQCECAwEAAaOCAUkwggFFMB0GA1UdDgQWBBS9zsZzz57Q
# lT5nrt/oitLv1OQ7tjAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAYfk8GzzpEVnG
# l7y6oXoytCb42Hx6TOA0+dkaBI36ftDE9tLubUa/xMbHB5rcNiRhFHZ93RefdPpc
# 4+FF0DAl5lP8xKAO+293RWPKDFOFIxgtZY08t8D9cSQpgGUzyw3lETZebNLEA17A
# /CTpA2F9uh8j84KygeEbj+bidWDiEfayoH2A5/5ywJJxIuLzFVHacvWxSCKoF9hl
# SrZSG5fXWS3namf4tt690UT6AGyWLFWe895coFPxm/m0UIMjjp9VRFH7nb3Ng2Q4
# gPS9E5ZTMZ6nAlmUicDj0NXAs2wQuQrnYnbRAJ/DQW35qLo7Daw9AsItqjFhbMcG
# 68gDc4j74L2KYe/2goBHLwzSn5UDftS1HZI0ZRsqmNHI0TZvvUWX9ajm6SfLBTEt
# oTo6gLOX0UD/9rrhGjdkiCw4SwU5osClgqgiNMK5ndk2gxFlDXHCyLp5qB6BoPpc
# 82RhO0yCzoP9gv7zv2EocAWEsqE5+0Wmu5uarmfvcziLfU1SY240OZW8ld4sS8fn
# ybn/jDMmFAhazV1zH0QERWEsfLSpwkOXaImWNFJ5lmcnf1VTm6cmfasScYtElpjq
# Z9GooCmk1XFApORPs/PO43IcFmPRwagt00iQSw+rBeIH00KQq+FJT/62SB70g9g/
# R8TS6k6b/wt2UWhqrW+Q8lw6Xzgex/YwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDWTCCAkECAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# TjozMjFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAtkQt/ebWSQ5DnG+aKRzPELCFE9GggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOwhbWAwIhgPMjAyNTA3MTYwMDE0MjRaGA8yMDI1MDcxNzAwMTQyNFowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA7CFtYAIBADAKAgEAAgIb9QIB/zAHAgEAAgIS
# 6DAKAgUA7CK+4AIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQAcAOPLxP46
# lYuPtKi5UJ0xsG0/Z5+wurt+vtpJ+80BE3Pnm7auFDkC8dJBsPBGcnUc3MCgpG/I
# fNyZdHvQC47hght8CPUTnKhRj6//nVTxcUSfPTxCTUe9EsxEVzwBFuDUKKFZYA1u
# 4FO1bW3FwQnJ02cdcXHbpF/3j4StV4v5XR66rvaz8jvVzAIl66mn30EQLUnM7EXt
# eocf9+iVjap5QK5jfRun0rVemHHrw/8AdK+zZxKetg3+PWtFiQNmeOtEShE8FGeG
# A2qhg7UwUAIDt5jk9C0/ISzKTK5R0xEH20O46rWKVMmooPEx82wvvXV0+kSxSNoI
# Z14YFKeSegMuMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAH4o6EmDAxASP4AAQAAAfgwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgEnxd5gsA
# 3SAGhJkdd4O7AzNCOZivy/E+dHwLzcLz4+MwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCDvzDPyXw1UkAUFYt8bR4UdjM90Qv5xnVaiKD3I0Zz3WjCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB+KOhJgwMQEj+AAEA
# AAH4MCIEIA5PvdgTplKaPqEV01hpE8Uw3glyZhKsGqLRKF4eH+WDMA0GCSqGSIb3
# DQEBCwUABIICAFQIZVFARyOTcG6XiyZAz9av2BYcgKuyxKUvRm7VQcoL4GHOIWxt
# ZsYc86yGSGaJqh2ubkflQncXNEh9zKL0oYVvmnFDuLVdJncsFY5VxeYjZjIhmrPA
# cJ/JnVxU3xsHBafNzocbSOK6pFDiSHRpRHF7uRuf956lpoIbobJzmkZPJmBX5U0u
# gV1NYFZhPhz9BJayc//qETYOCcbEBKlVgiXH5Po7kFugLuFbMDFD4mQrK109aCoH
# YO5HVS1Cm+Yi0rE1nar769mVngLLdWMKhXl8weH6t7xIcbrpDzbTa9DjXI5DnDvY
# xO2xzBjhGxalxbJr5hiMmLuCjUJmtPQQd+qGLlTCZVW9sg2aYnP6YPLCkw50IDcX
# edr6wOMJiUhQiolwovWlEVSNj9KJhFX+rMT5bUA8LKm6r4/0QYpLDTsg4UCUo05h
# 7z0+S6b7N6G5oOG2E2EqH1m8l4qExWsMmT6UG4kUTmRQ7G4e91UKdCC3yfNC8dGv
# CSl+lrVUWv052raGoRZL2RcKsVpQ2kE4W0KTw1VURkGmm0CjTa7SLaSUmAUuENtJ
# 8ct786Sq/SoDp4eoXG6GU+nZaCHQuv83Qahyzgj1wykufdK6LyX5QUWVkgieIkSk
# XiUp2P8PxeBt/QQlM15a5UFFjSZCvCxq5ii28jsCcOSS8XVs43DYQfp5
# SIG # End Windows Authenticode signature block