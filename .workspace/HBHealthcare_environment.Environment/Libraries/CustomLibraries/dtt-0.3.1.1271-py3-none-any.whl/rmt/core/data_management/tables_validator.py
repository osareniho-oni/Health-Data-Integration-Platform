from typing import List, Set

from rmt.core.core_exceptions import MappingTargetKeyNotExistsInTableError
from rmt.core.data_management.primitive_types import TableName
from rmt.core.data_management.repository import Repository
from rmt.core.data_management.table_data import TableData
from rmt.core.data_management.table_data_appender import TableDataAppender
from rmt.core.data_management.table_mapping import TableMapping
from rmt.core.data_management.table_mapping_appender import TableMappingAppender


class TablesValidator:
    """
    this class is responsible for validating the data and mapping of the tables
    it uses the repository to get the data and mapping of the tables
    it first validate the data of the table by adding all TableData of the table from different contributors
    then it validate the mapping of the table by adding all TableMapping of the table from different contributors
    then it validate the mapping with the data of the table by checking that each target key of the mapping exist in the data
    """
    @property
    def validation_errors(self) -> List[ValueError]:
        return self._errors

    def __init__(self, repository: Repository):
        self._repository = repository
        self._invalid_table_names: Set[TableName] = set()
        self._errors: List[ValueError] = []

    def _add_invalid_table(self, table_name: TableName):

        if table_name not in self._invalid_table_names:
            self._invalid_table_names.add(table_name)

    def _get_table_data(self, table_name: str) -> TableData:

        table_data_appender = TableDataAppender(table_name)
        table_data_list = self._repository.get_table_data_list_by_table(table_name)
        for table_data in table_data_list:
            table_data_appender.append(table_data)
        if table_data_appender.errors:
            self._add_invalid_table(table_name)
            for error in table_data_appender.errors:
                self._errors.append(error)
        return table_data_appender.table_data

    def _get_table_mapping(self, table_name: str) -> TableMapping:

        table_mapping_appender = TableMappingAppender(table_name)
        table_mapping_list = self._repository.get_table_mapping_list_by_table(table_name)
        for table_mapping in table_mapping_list:
            table_mapping_appender.append(table_mapping)
        if table_mapping_appender.errors:
            self._add_invalid_table(table_name)
            for error in table_mapping_appender.errors:
                self._errors.append(error)
        return table_mapping_appender.table_mapping

    def _validate_mapping_with_data(self, table_name: str, table_data: TableData, table_mapping: TableMapping):
        for target_key, source_values in table_mapping.target_to_source_mapping.items():
            if not table_data.key_exist_in_data(target_key):
                self._add_invalid_table(table_name)
                self._errors.append((MappingTargetKeyNotExistsInTableError(table_name, source_values, target_key)))

    def _validate_table(self, table_name: str):

        try:
            # Validate table data for table by it to one table data"
            aggregated_table_data = self._get_table_data(table_name)
            # Validate table data for table by it to one table mapping"
            aggregated_table_mapping = self._get_table_mapping(table_name)
            # Validate table mapping with table data."
            if aggregated_table_data is not None and aggregated_table_mapping is not None:
                self._validate_mapping_with_data(table_name, aggregated_table_data, aggregated_table_mapping)
        except ValueError as error:
            self._add_invalid_table(table_name)
            self._errors.append(error)

    def validate_tables(self, table_names: Set[str]) -> bool:
        self._invalid_table_names = set()
        self._errors = []
        for table_name in table_names:
            self._validate_table(table_name)
        return len(self._invalid_table_names) == 0

# SIG # Begin Windows Authenticode signature block
# MIIoKgYJKoZIhvcNAQcCoIIoGzCCKBcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDRBZDJnS1GFKPZ
# kv7rHzgGj3yXhnsGb+FslU0UxDcnUKCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgowghoGAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFDZkvXD/53ET+WuoLX0w7kU
# 912Mi5CjIci7lsyGAguqMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAkq53BnonDn/sQ6HfNwqrjt/7jDVgx7K0QLwNsZFeI5VsXGX7bXq9Z8Ee
# o5UkyAU+jXUxL2TG2PE5EwudYoEMqG8mHGEqUjeJOltjK8hqFY41WUvpz2CmmOsp
# 3TPC6m1+V5WH7SPNM0g24I3LvzFNcpY+KnbyYfxws6hLR9xpFShXuL+ZIoH33IQ7
# HeUZUnWajwFgLVsA4M4RRxri7MLK3XH6AggbxRZoUAIvdSzifG8AA6s2vsF8Lev5
# XO2Zjuuxon1cthmRW0UQ1DxyTHyyDP/UMX0z/bj3eyI10ctG9KqgvYyM7epu7LwH
# DVkVD4DtDkWqVjM4kqa8Zt+y0mRvMqGCF5QwgheQBgorBgEEAYI3AwMBMYIXgDCC
# F3wGCSqGSIb3DQEHAqCCF20wghdpAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBM0rAG8Au3epAmtTMpmyA3ANzCruS++vRAPDW9Lv6HggIGaF2tdYlZ
# GBMyMDI1MDcxNjA0MjEyNy40MDZaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OEQwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHqMIIHIDCCBQigAwIBAgITMwAAAg0Nd757No9/4wABAAACDTANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQz
# MDFaFw0yNjA0MjIxOTQzMDFaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OEQwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCxf6gH3fH3wgmFN5TV8zRF/N0TJguWUYCrQZPUmwA+
# QhSySNp7kiGmFZd4b5zsAfN0Wh+PzIJvYsVMgVCaZcbVr/DJBfexwnQfc+fgIjOi
# AzYSjg7EtSOdWoLk81b/mGiGIBC++fLcSAzbZO3KtW4PRKOSsdD/5eRdtNca/Ed4
# EAcUT32zAGS9Sq//4kDT92KEzRNXJj8z3NDL4oGGzCQMvA83tQG5mrnepxF0OsNf
# KKHYHMqjyOEP5pTgKfT5XMfz0sEG6ARAjlXJ79SG/joeuHh8TqC+cJMry9wB7ZLr
# dMAFy8rHN3W1+kkpw47Ko+9ize2ble+P5jMaqufK033Bu+2FXVSKphil2j0qBUWp
# n5vBtf2W+gsVqydA+eseBHfYxcDZ4+5oRoyDAg0tW9f79vOAv91P4bTzG+BZPBbD
# MzSDwmj8ASKDlVwruTeF1em7NWiedWAB+29gFH/c/NN1uTQLvwGDIOw1DcLnCD0V
# XNL7mOvifYvNWugTAHcMFLVlA1jeOH35E/IW9qcKKqrah7LyJax/6M5UHswQugGg
# LriiMNEvz3IqW+AiIJ097iYzMGzsDqbLSUztIjDEt9xfIHHUs/p3j9Bkr2bPP1v4
# z8vp/45Ck3mfFbW2F0EtjOCnGPMrJNjjGhEG9zAK1105Bg2kJ7Rn8WTWO5IbD/rD
# tQIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFBWXjpDmDgNrTsISj26SjU1/YMOAMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQAcH8gT42wVQ8GQZ+MHIXNJ+d4dQn0+vPG/
# AdFvTxk/tvOOkA2i7hnoEOEFcSbzS5EdIVCMi5Y5EiWT8hEJkztdeq5hXtUWsPY+
# 2lYSU9HdhKDfRDfjwVZ9kfCthrLRC3jw9Fah5MAGI9MHSETo9r7+cux8AUqQ3hma
# M2jmTNWvrFOLbO01B1ciNGbvE2xK+rbzBBh/uWd3k30pau6Lp0azg7rDYGMGv8jW
# otILfpKMBeCQoufMsI/gzxo4+k9dqYBkAwMk7h1hf23ycb5WngSMQV/Uxl3Sxbg+
# 64KK6GCsTSG6z7zNTgbL69PMGfwV2cnawY95Iy2cgJ6cbMORRUcYzvsuUd8oEQ87
# cW4XqqBLrheewJjROT6YyWrQ2oQ+jzGK2WJoGNnfanmNfqQnVKpi320onag95LMF
# jj8BwrflYsO9kEOiy7I5UngPBmF+RHSCv2hFSr8nK7gtuiy9SUOKP6FbQOzyMRvJ
# 3UxsmrH38477XzETb/tZLAj10TdYFfkjkFeFjlb3iMTSs/VrJSF0r0vON/oxZqKC
# Y8WZez+uQP0Try0QQ9wRp5D2FYJ8E1uIX/LvwuFkBdWf7X7qlb+pzdvPpSAcaCgB
# IWTlMn2bWgkU5uPzxRPHh/0u+FI7/eRCZGbLM2qnn3yXQvO/h9wQm8pIABRAvoda
# iV0bVmHbETCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNN
# MIICNQIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjhEMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQB7
# LCwoj6G3nQ7Oxhl/pfne4yATPaCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7CE2vzAiGA8yMDI1MDcxNTIwMjEx
# OVoYDzIwMjUwNzE2MjAyMTE5WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDsITa/
# AgEAMAcCAQACAiASMAcCAQACAhKsMAoCBQDsIog/AgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZI
# hvcNAQELBQADggEBACfKfZikru1VNRxXACHtNGrgqpHJFatZ3QjMp8w+SAAagBn6
# o1QkGgSGAvkJtQnIsUd/agHEdhxm3A3I2E397cthkmoIg0Vb5EUBgBu6ZDM4LHTS
# 8qfzFEAqhZz38P74VC7VMxY0ewh8aM6HObY/iDBBzYqfpuBG9rlA7UYySE1LIDmG
# IjdESuT/nPmETkXxkg7e/KbSyFakxJidwKq8Qnai84vU1UDxvOhbEvbQMdVaUrxB
# goa8QjTY9KrqWpawR96Bb5X9ISrbyH2bCDYagqfF+/afEACAWz+mtokxAElr3Uk/
# DDRLAegN/tt4+sq2mnSbHnaoBrUIQRvEiQT1QMAxggQNMIIECQIBATCBkzB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAg0Nd757No9/4wABAAACDTAN
# BglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8G
# CSqGSIb3DQEJBDEiBCCrKn0+0YfR5CNkPgmb4wf+KIimZ4ghITPbZHcvOHkBgTCB
# +gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIGPqB5TsJGqI8OuknBKtSvb0Ffq6
# w5NSs5veTVwka/hAMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAINDXe+ezaPf+MAAQAAAg0wIgQgTg/z5K68C2e4ceM97ZKArrERkLW7
# ncs1zkDCilcPiqgwDQYJKoZIhvcNAQELBQAEggIAU/134XERyxnsJrcDXfyltd3S
# YeGFEbVlP8L+wDhmCzi7bHtlsdcx9aOMYgk0U+jeYWvNHVTRvoZQ3Leh7MPrVtl0
# aAiLRT0C2zR00c9smDk17Js2yeeuy2mZfACEBrGfnhJ2cB9wzt8Wzg1nDCedoXeQ
# O3f3nUvKgeUi6537uHAbUH8SDpXO309YsVhPJZb6gcjXJaMlu615dG/sWJRSMQV6
# GNyE2DN4GuwA61hmvrcd2fKSH8bf97LppnLttVlhWI0npe+UgwYxIIoHuaoUyLsd
# bFH1i87Cxnz+yfslKwS67aJ5bpFxiGOb6TYhQvWgrUnAthiifh6kHIMGsY2RBvBG
# gDhZXKVc5QCssxlZW76itynxt6muSibbq8uf8P7RJ35alpYq3C/wepqBM41mpA3o
# yrE5LlRoByOb2kXs7Ye9y16gSV8lFk+nMna5eJN4jcphg81IUY12B7yFGzyUpfir
# QGjxsMI+47i0drY5iEmHoYAgCFScZrGtGg/vd6KoAVPojdcXarC+cXIC72yxEOg5
# 5Eqccc8rplfpb7Ntim3QbZsV4ERXBNIjwVUd3w4hVfXBtHLECeSivkF5zz0rbmiT
# BobAnPiCjExk2/iMqJLPMKc5r0wXRqVw0QzQzP6tLIIvanNEMX//4299UDWsxmuT
# Tt84pp7rSVGAOvZL5SU=
# SIG # End Windows Authenticode signature block