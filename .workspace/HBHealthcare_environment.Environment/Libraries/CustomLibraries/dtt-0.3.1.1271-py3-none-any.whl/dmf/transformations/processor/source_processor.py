import os
from typing import Dict, List

from common.reader.reader import Reader
from common.reader.reader_factory import ReaderFactory
from delta import DeltaTable

from common.model.data_access_definition import DataAccessDefinition, DataSourceId
from dmf.model.source_configuration import MappingDefinition, SourceConfiguration, SourceTableSchema
from dmf.model.target_configuration.target_configuration import TargetConfiguration
from dmf.last_processed_line_computer.last_processed_lines import LastProcessedLineCalculator
from common.utils.logging import Logger
from dmf.reference_values.reference_values_enricher import ReferenceValuesEnricher
from dmf.transformations.model.transformation_types import Source2TargetIdMapping
from dmf.transformations.processor.base_processor import BaseProcessor
from dmf.transformations.processor.column_expression_builder import ColumnExpressionBuilder
from dmf.transformations.processor.conditions.condition_source_columns_applier import ConditionedSourceColumnsApplier
from dmf.transformations.processor.conditions.id_mapping import ConditionedIdMappingAdjuster
from dmf.transformations.processor.field_values_source_enricher import FieldValuesSourceEnricher
from dmf.transformations.processor.target_processor import TargetProcessor
from dmf.transformations.utils.min_date_filter import MinDateFilter
from dmf.utils.global_constants import GlobalConstants
from dmf.utils.logging_utils import SyntheticId, Timed
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.utils import AnalysisException
from pyspark.sql import functions as F

from dmf.transformations.processor.column_selector import ColumnSelector
from dmf.model.internal.target_table_schema_helper import TargetTableSchemaHelper


@SyntheticId
class SourceProcessor(BaseProcessor):
    DEFAULT_SOURCE_DATA_PARTITIONS = 100

    def __init__(
            self,
            spark: SparkSession,
            config: SourceConfiguration,
            reference_values_enricher: ReferenceValuesEnricher
    ):
        self._spark: SparkSession = spark
        self.config: SourceConfiguration = config
        if self.config.table_schema is None:
            raise ValueError(f"got config without source schema {self.config}")
        self.df: DataFrame = None
        self._id_mapping_definitions: Dict[DataSourceId, DataAccessDefinition]
        self._reference_values_enricher = reference_values_enricher
        self._schema: SourceTableSchema = self.config.table_schema
        if self._schema is None:
            raise ValueError(f"got config without source schema {self.config}")
        self.is_empty: bool = False
        self.source_id = config.source_id
        self._preprocessed_data_location = None
        self._preprocessed_data_format = "delta"
        try:
            self._data_partitions = int(spark.conf.get(GlobalConstants.SPARK_CONFIG_DTT_DMF_SOURCE_DATA_PARTITIONS))
        except Exception as e:
            Logger.warn(f"Unable to parse {GlobalConstants.SPARK_CONFIG_DTT_DMF_SOURCE_DATA_PARTITIONS}. {e}")
            self._data_partitions = None
        self._data_partitions = self._data_partitions or self.DEFAULT_SOURCE_DATA_PARTITIONS
        Logger.info(f"{self} created with data partitions: {self._data_partitions}")

    def __str__(self):
        return f"source {self.source_id}"

    def __repr__(self) -> str:
        return f"SourceProcessor[{self.id}][{self.source_id:.30}]"

    @property
    def id_mapping_definitions(self):
        return self._id_mapping_definitions

    @id_mapping_definitions.setter
    def id_mapping_definitions(self, id_mapping_definitions: Dict[DataSourceId, DataAccessDefinition]):
        self._id_mapping_definitions = id_mapping_definitions

    def _preprocess(self) -> None:
        # calculate min date (unrelated to source data! merely the target data)
        min_date = LastProcessedLineCalculator(self._spark).compute_last_processed_line_in_source_table(
            executor=None, source_config=self.config
        )
        # filter source by date
        Logger.debug(f"{self} filtering by min_date: {min_date}")
        self.df = MinDateFilter.filter(
            df=self.df,
            min_date=min_date,
            date_col_name=self._schema.source_modified_date_column_name,
        )

        self.df = ColumnExpressionBuilder.build_column_expressions(self.df, self._schema.columns)
        self.df, extra_literal_columns = FieldValuesSourceEnricher.enrich(self.config, self.df)
        self.df = self._reference_values_enricher.enrich(self.df, self.config.source_to_reference_mappings)
        self.df, extra_conditioned_columns = ConditionedSourceColumnsApplier(
            self._spark,
            self.config,
            self.df,
            self._reference_values_enricher.reference_values_configuration.default_value,
        ).apply()
        try:
            self.df = ColumnSelector.select_specific_columns(
                self.df,
                list(self._schema.columns) + extra_literal_columns + extra_conditioned_columns,
            )
        except AnalysisException as ae:
            if "ambiguous" in str(ae):
                raise Exception(
                    "Multiple fields with same name were found. Use a unique aliases for these fields in the query to resolve the ambigiuity."
                ) from ae
            else:
                raise

    @Timed(Logger)
    def read(self) -> int:
        if not self._read_inner():
            self.is_empty = True
        else:
            self._preprocess()
            self._save_data()
        return self.is_empty

    def _save_data(self):
        self._preprocessed_data_location = os.path.join(self.config.secondary_lake_location,
                                                        "PREPROCESSED_SOURCE_DATA",
                                                        self.config.feed_id,
                                                        self.source_id)
        try:
            delta_table = DeltaTable.forPath(self._spark, self._preprocessed_data_location)
            delta_table.vacuum()
        except Exception as e:
            Logger.warn(f"Failed to vacuum delta table from location: {self._preprocessed_data_location}. {e}")

        self.df.write.format(self._preprocessed_data_format).mode("overwrite").save(self._preprocessed_data_location)
        self.df = self._spark.read.format(self._preprocessed_data_format).load(self._preprocessed_data_location) \
            .repartition(self._data_partitions)
        self.is_empty = self.df.isEmpty()

    def _read_inner(self) -> bool:
        Logger.info(f"{self} reading source table: '{self.config.data_access_definition}'")
        reader: Reader = ReaderFactory.get_instance(self.config.data_access_definition)
        source_df = reader.read(self._spark)
        if source_df is not None:
            self.df = source_df.repartition(self._data_partitions)

        return reader.validate(df=self.df, data_access_definition=self.config.data_access_definition)

    def process(self) -> List[TargetProcessor]:
        if self.is_empty:
            return []

        if not self.id_mapping_definitions:
            Logger.info(f"{self} no id mapping definitions")

        target_processors = []
        for target_config in self.config.target_configurations:
            target_processor = self._create_target_processor(target_config)
            target_processors.append(target_processor)

        Logger.info(f"{self} process end. returning target processors: {[tp.id for tp in target_processors]}")
        return target_processors

    def _create_target_processor(self, target_config):
        target_id_mappings: List[Source2TargetIdMapping] = self._calc_id_mappings(target_config)
        target_id_mappings, source_ids_with_conditions = ConditionedIdMappingAdjuster.adjust(
            target_config, target_id_mappings
        )
        mapping_table_data_access_definitions: Dict[DataSourceId, DataAccessDefinition] = {}
        for target_id_mapping in target_id_mappings:
            mapping_table_data_access_definitions[
                target_id_mapping.id_mapping_df_name
            ] = self._find_mapping_table_data_access_definitions(target_id_mapping.id_mapping_df_name)

        target_processor = TargetProcessor(
            spark=self._spark,
            target_config=target_config,
            source_schema=self._schema,
            source_df=self.df,
            id_mappings=target_id_mappings,
            source_ids_with_conditions=source_ids_with_conditions,
            id_mapping_table_access_definitions=mapping_table_data_access_definitions,
            parent_id=self.source_id,
        )

        return target_processor

    def _find_mapping_table_data_access_definitions(self, id_mapping_df_name: str) -> DataAccessDefinition:
        for mapping_definition in self.id_mapping_definitions.values():
            if mapping_definition.data_source_id == id_mapping_df_name:
                return mapping_definition

        raise ValueError(f"Adapter mapping definition for table '{id_mapping_df_name}' was not defined")

    def _calc_id_mappings(self, target_config: TargetConfiguration) -> List[Source2TargetIdMapping]:
        src_to_target_id_mappings = []
        already_appended_target_id_column_names = []
        for mapping_definition in self.config.mapping_definitions:
            append = False
            if mapping_definition.target_mapping_table_name == target_config.target_id:
                append = True

            if not append:
                relations_to_mapping_table = TargetTableSchemaHelper.get_relations_pointing_to_table(
                    target_config.table_schema,
                    mapping_definition.target_mapping_table_name,
                )
                has_fk_to_mapping_definition = bool(relations_to_mapping_table)
                if has_fk_to_mapping_definition:
                    append = True

            if append and mapping_definition.target_id_column_name not in already_appended_target_id_column_names:
                src_to_target_id_mappings.append(
                    Source2TargetIdMapping(
                        id_mapping_df_name=self.id_mapping_definitions[
                            mapping_definition.target_mapping_table_name
                        ].data_source_id,
                        source_id_col_name=SourceProcessor._calc_source_id_column_name(mapping_definition),
                        target_id_col_name=mapping_definition.target_id_column_name,
                    )
                )
                already_appended_target_id_column_names.append(mapping_definition.target_id_column_name)
        return src_to_target_id_mappings

    @staticmethod
    def _calc_source_id_column_name(mapping_definition: MappingDefinition) -> str:
        return SourceProcessor.calc_source_id_column_name(mapping_definition.external_id_column_name,
                                                          mapping_definition.internal_id_column_name)

    @staticmethod
    def calc_source_id_column_name(external_id_column_name: str, internal_id_column_name: str) -> str:
        return external_id_column_name or internal_id_column_name

    def validate(self) -> bool:
        self.read()
        if self.is_empty:
            return True
        validation_methods = [
            self._validate_modified_on_column(),
        ]
        validation_status = all(validation_methods)
        return validation_status

    def _validate_modified_on_column(self) -> bool:
        status = self.df.where(F.col(self._schema.source_modified_date_column_name).isNull()).isEmpty()
        if not status:
            Logger.error(f"{self} has NULL values in modified_on column")

        return status

# SIG # Begin Windows Authenticode signature block
# MIIoRgYJKoZIhvcNAQcCoIIoNzCCKDMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCXChkQaIdHIBxl
# kADL0znVFMrhjf9ybX98TPqxh7YHpaCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiYwghoiAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIFUpsjsxvDxit2x8wfGWSw3q
# H9wDwjtjfM+A7UIHfrm4MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAALu1G+IHmSfhSrXaZZWWuq/zQ1OXgZIzjoqLk/raGfTKG+JChGy53vPh
# tgzGE4sb5hUKYfDqOo+QlqBxV45ItI7HiX6S6OLtuUUbfuJ2B/o0DOvDNTOs7PDs
# cUz1O3hLBL8EqbjyqCUA3RtufOD5cVGDKMA2ZGIs6NrmCpik2PBl/V/GnB3lPv/D
# bFLiFXrK5P3hwGl4QezWEz20GdEj4Wm9mpQlM2/iWrHq1E/GUlaQu3G4itf2mo55
# Gt1P2Vjf2fgzuq9ePqOcfaSwEcCc0De6x4rFdCId2e1V8gosmaOXssodWpD6/xb9
# 7fQCvfzpHJdXTi0EnCi7dDOMCbIYJ6GCF7AwghesBgorBgEEAYI3AwMBMYIXnDCC
# F5gGCSqGSIb3DQEHAqCCF4kwgheFAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBevyYU9dU7upovULguyMQPYLHDF88xRJMyxCFRb5ImogIGaFmRX1JR
# GBMyMDI1MDcxNjA0MjE1OC41ODlaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo2NTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEf4wggcoMIIFEKADAgECAhMzAAAB9ZkJlLzxxlCMAAEAAAH1MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzEwMVoXDTI1MTAyMjE4MzEwMVowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjY1MUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAzO90cFQTWd/WP84IT7JM
# IW1fQL61sdfgmhlfT0nvYEb2kvkNF073ZwjveuSWot387LjE0TCiG93e6I0HzIFQ
# BnbxGP/WPBUirFq7WE5RAsuhNfYUL+PIb9jJq3CwWxICfw5t/pTyIOHjKvo1lQOT
# WZypir/psZwEE7y2uWAPbZJTFrKen5R73x2Hbxy4eW1DcmXjym2wFWv10sBH40aj
# Jfe+OkwcTdoYrY3KkpN/RQSjeycK0bhjo0CGYIYa+ZMAao0SNR/R1J1Y6sLkiCJO
# 3aQrbS1Sz7l+/qJgy8fyEZMND5Ms7C0sEaOvoBHiWSpTM4vc0xDLCmc6PGv03CtW
# u2KiyqrL8BAB1EYyOShI3IT79arDIDrL+de91FfjmSbBY5j+HvS0l3dXkjP3Hon8
# b74lWwikF0rzErF0n3khVAusx7Sm1oGG+06hz9XAy3Wou+T6Se6oa5LDiQgPTfWR
# /j9FNk8Ju06oSfTh6c03V0ulla0Iwy+HzUl+WmYxFLU0PiaXsmgudNwVqn51zr+B
# i3XPJ85wWuy6GGT7nBDmXNzTNkzK98DBQjTOabQXUZ884Yb9DFNcigmeVTYkyUXZ
# 6hscd8Nyq45A3D3bk+nXnsogK1Z7zZj6XbGft7xgOYvveU6p0+frthbF7MXv+i5q
# cD9HfFmOq4VYHevVesYb6P0CAwEAAaOCAUkwggFFMB0GA1UdDgQWBBRV4Hxb9Uo0
# oHDwJZJe22ixe2B1ATAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAcwxmVPaA9xHf
# fuom0TOSp2hspuf1G0cHW/KXHAuhnpW8/Svlq5j9aKI/8/G6fGIQMr0zlpau8jy8
# 3I4zclGdJjl5S02SxDlUKawtWvgf7ida06PgjeQM1eX4Lut4bbPfT0FEp77G76hh
# ysXxTJNHv5y+fwThUeiiclihZwqcZMpa46m+oV6igTU6I0EnneotMqFs0Q3zHgVV
# r4WXjnG2Bcnkip42edyg/9iXczqTBrEkvTz0UlltpFGaQnLzq+No8VEgq0UG7W1E
# LZGhmmxFmHABwTT6sPJFV68DfLoC0iB9Qbb9VZ8mvbTV5JtISBklTuVAlEkzXi9L
# IjNmx+kndBfKP8dxG/xbRXptQDQDaCsS6ogLkwLgH6zSs+ul9WmzI0F8zImbhnZh
# UziIHheFo4H+ZoojPYcgTK6/3bkSbOabmQFf95B8B6e5WqXbS5s9OdMdUlW1gTI1
# r5u+WAwH2KG7dxneoTbf/jYl3TUtP7AHpyck2c0nun/Q0Cycpa9QUH/Dy01k6tQo
# mNXGjivg2/BGcgZJ0Hw8C6KVelEJ31xLoE21m9+NEgSKCRoFE1Lkma31SyIaynbd
# YEb8sOlZynMdm8yPldDwuF54vJiEArjrcDNXe6BobZUiTWSKvv1DJadR1SUCO/Od
# 21GgU+hZqu+dKgjKAYdeTIvi9R2rtLYwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDWTCCAkECAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo2NTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAJsAKu48NbR5YRg3WSBQCyjzdkvaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOwhD0gwIhgPMjAyNTA3MTUxNzMyNTZaGA8yMDI1MDcxNjE3MzI1NlowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA7CEPSAIBADAKAgEAAgIZIwIB/zAHAgEAAgIS
# FjAKAgUA7CJgyAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQBC8hEgq8Yg
# RkBZBuR4rsvF9WZEsowj0qyXc2HYITSyH6Wha7CLNyZGG5cgcgQ6gDyUeVG+SG5w
# RgFwyD36T5sCr2GesWm2WZ9CeJxTOoZHQwmnQH8Yg2QPpRDA4WCIaB5YNIVF3hdJ
# Mi2h1I4pQuxRgLD9v64MuUMTLSEy/hckDCaSsOfM2LaGxid/CmjHF7uksV+BYm+n
# jRWRiBlOupYrflAUAtCyDU7lHDIY0JK8USfjs+PIHTY7r4q5CKHZouWHXugstkfb
# 0kqPjl8Fs1G/zYqvq+uqRkzl5/TXStblFK8Nl1xIGrOPdcj5ZAY6y7+o65cobrXH
# 4lBuOvhIvs8dMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAH1mQmUvPHGUIwAAQAAAfUwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgyRD1SeP+
# naBMDt4ECchE/xwopfG3zhATljwnno6Fl0wwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCDB1vLSFwh09ISu4kdEv4/tg9eR1Yk8w5x7j5GThqaPNTCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB9ZkJlLzxxlCMAAEA
# AAH1MCIEIFIRAI/CkwMFeuFe98pp1Ibst4SehE1pOWyBH46vTVA9MA0GCSqGSIb3
# DQEBCwUABIICAG6DWMxalmVyO7yonhPh5GyzCriinPasCYG/j1hn8IQTX0NmXE6h
# nxVjVq7i3P4GDgx8Sblb3+wXfi694dEICLPWEUUutlI5C7hAbIljWiJZLJN5Wum3
# jJKokTutjNSyDEPrZSaHZBB5xk182jrvlZ5AEsNlk2QvqxPcC35rMxBytwBS134z
# tRHNhNc1bqQcwC8toVWLZyO8fmYeKa5KqNW0I/LR6nm+VnjddYF/UbgDYYt6uc7L
# hXwHhVACEY6MSvSBbdSF5322c3kFs2gFmP3oFR6huHTN9AQFTccVogUOkcwq005l
# E06kn8W7WoWyYSg/jUPZkQLByYWURtRCpvwWvwVZpsxxHfxVEWsbnqWKAQuTsdLP
# ttUAh2+6j+riYLYG1MvX2wMpgoZ3WsrSBXjs1dVglipDaZWB5ONARPUAenXteXC+
# gA6ofbxSQAlGPQ0dDQIbS1POrMWA/Jljv+HG9LIroKsjNDeMMYkvvXwYtedq000y
# BMc9VHtfrw2XsVuo1HOhIp6VqhBqtat4tFRdpa5FfT2U4Q2O+/QER9RL80Sq1T/O
# b0AizbRSEj5BWlqZl5dfWmh1P2sqrPw0uNaUafweIrz+WmWGn69/2RgoMqnS9krA
# bTcIIaFQ6S7y5tR7JmJH8/KO9un+IzNBB0ApA+iU3q3PPw7UMb35H5+d
# SIG # End Windows Authenticode signature block