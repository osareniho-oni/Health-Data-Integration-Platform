import os
from typing import Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, StringType, StructField, StructType

from common.model.data_access_definition import DataAccessDefinition, DataSourceTypeEnum
from common.utils.logging import Logger
from common.reader.reader import Reader
from common.reader.reader_factory import ReaderFactory
from dmf.utils.dataframe_utils import DataFrameUtils
from dmf.utils.global_constants import GlobalConstants
from dmf.utils.logging_utils import SyntheticId, Timed


@SyntheticId
class AdrmIdsMapper:
    DATA_FORMAT = "DELTA"
    SCHEMA = StructType([
        StructField(GlobalConstants.INTERNAL_ID_COLUMN_NAME, StringType(), False),
        StructField(GlobalConstants.EXTERNAL_ID_COLUMN_NAME, StringType(), False),
        StructField(GlobalConstants.ADRM_ID_COLUMN_NAME, LongType(), False),
        StructField(GlobalConstants.FEED_ID_COLUMN_NAME, StringType(), False)
    ])

    @Timed(Logger)
    def map(self,
            spark: SparkSession,
            given_df: DataFrame,
            feed_id: str,
            internal_id_column_name: str,
            external_id_column_name: Optional[str],
            id_mapping_table_name: str,
            id_mapping_table_db_name: Optional[str],
            id_mapping_tables_location: str,
            id_mapping_table_entity_type: DataSourceTypeEnum,
            fast=False):

        Logger.info(
            f"ID Mapper [{self.id}] Mapping IDs (id_mapping_table_name='{id_mapping_table_name}', type='{id_mapping_table_entity_type}', "
            f"internal_id_column='{internal_id_column_name}', external_id_column='{external_id_column_name}')")

        if not external_id_column_name:
            external_id_column_name = AdrmIdsMapper._dummy_external_id_column_name(internal_id_column_name)
            given_df = given_df.dropDuplicates([internal_id_column_name]).\
                select("*", F.lit("").cast(StringType()).alias(external_id_column_name))
        else:
            given_df = given_df.dropDuplicates([internal_id_column_name, external_id_column_name])
            self._validate_all_external_ids_contain_values(given_df, external_id_column_name)
            self._validate_all_ids_are_unique(given_df, internal_id_column_name)
            self._validate_all_ids_are_unique(given_df, external_id_column_name)

        # Cast ID columns just in case they are not strings
        given_df = given_df. \
            select("*",
                   F.col(internal_id_column_name).cast(StringType()).alias(internal_id_column_name + '_temp'),
                   F.col(external_id_column_name).cast(StringType()).alias(external_id_column_name + '_temp')). \
            drop(internal_id_column_name). \
            drop(external_id_column_name). \
            withColumnRenamed(internal_id_column_name + '_temp', internal_id_column_name). \
            withColumnRenamed(external_id_column_name + '_temp', external_id_column_name)

        if id_mapping_table_entity_type == DataSourceTypeEnum.TABLE:
            if id_mapping_table_db_name is None:
                raise ValueError(
                    "id_mapping_table_db_name must be specified when id_mapping_table_entity_type is TABLE")
            AdrmIdsMapper._create_id_mapping_table(spark, id_mapping_table_db_name, id_mapping_table_name,
                                                   id_mapping_tables_location)
            mapping_table_owner = id_mapping_table_db_name
        elif id_mapping_table_entity_type == DataSourceTypeEnum.STORAGE:
            mapping_table_owner = AdrmIdsMapper.specific_table_location(id_mapping_tables_location,
                                                                        id_mapping_table_name)
        else:
            raise ValueError(f"Invalid value for mapping_entity_type: {id_mapping_table_entity_type}")

        reader: Reader = ReaderFactory.get_instance(DataAccessDefinition(data_source_type=id_mapping_table_entity_type,
                                                                         data_source_id=id_mapping_table_name,
                                                                         data_source_owner_id=mapping_table_owner,
                                                                         data_format=AdrmIdsMapper.DATA_FORMAT
                                                                         ))

        id_mapping_table_df = reader.read(spark)
        if not id_mapping_table_df:
            id_mapping_table_df = DataFrameUtils.create_empty_df(spark=spark, schema=AdrmIdsMapper.SCHEMA)

        (id_mapping_column_in_use, data_id_column_in_use) = AdrmIdsMapper._get_id_columns_in_use(
            id_mapping_table_df,
            internal_id_column_name,
            external_id_column_name)
        given_data_with_unmapped_ids_in_current_feed_df = \
            AdrmIdsMapper._get_unmapped_ids_in_current_feed(given_df, id_mapping_table_df, id_mapping_column_in_use,
                                                            data_id_column_in_use,
                                                            feed_id)

        # if and ID mapping does not exist in the current feed, it is required to check if it has already been mapped
        # in other feeds and if it was then that mapped value should be used
        remaining_unmapped_ids_df, mapped_ids_from_other_feeds_df = \
            AdrmIdsMapper._map_ids_from_other_feeds(given_data_with_unmapped_ids_in_current_feed_df,
                                                    id_mapping_table_df,
                                                    internal_id_column_name,
                                                    external_id_column_name,
                                                    id_mapping_column_in_use,
                                                    data_id_column_in_use,
                                                    feed_id)

        new_mapped_df = \
            AdrmIdsMapper._create_id_mapping(remaining_unmapped_ids_df,
                                             id_mapping_table_df,
                                             internal_id_column_name,
                                             external_id_column_name,
                                             feed_id,
                                             fast,
                                             id_mapping_table_name)

        AdrmIdsMapper._save_mappings(spark,
                                     mapped_ids_from_other_feeds_df.unionByName(new_mapped_df),
                                     id_mapping_tables_location, id_mapping_table_name)

    @staticmethod
    def specific_table_location(root: str, table_name: str):
        return os.path.join(root, table_name)

    @staticmethod
    def _should_map_to_ids_from_another_feed(internal_id_column_name: str, external_id_column_name: str):
        return AdrmIdsMapper._dummy_external_id_column_name(internal_id_column_name) != external_id_column_name

    @staticmethod
    def _dummy_external_id_column_name(internal_id_column_name: str) -> str:
        return internal_id_column_name + "_ext"

    @staticmethod
    def _create_id_mapping_table(spark: SparkSession, db_name: str, id_mapping_table_name: str,
                                 id_mapping_tables_location: str):

        table_location = os.path.join(id_mapping_tables_location, id_mapping_table_name)
        sql_str = f"""
                create external table if not exists {db_name}.{id_mapping_table_name} \
                ( \
                    {GlobalConstants.INTERNAL_ID_COLUMN_NAME} STRING, \
                    {GlobalConstants.EXTERNAL_ID_COLUMN_NAME} STRING, \
                    {GlobalConstants.ADRM_ID_COLUMN_NAME} BIGINT, \
                    {GlobalConstants.FEED_ID_COLUMN_NAME} STRING \
                ) \
                USING {AdrmIdsMapper.DATA_FORMAT} \
                PARTITIONED BY ({GlobalConstants.FEED_ID_COLUMN_NAME}) \
                LOCATION '{table_location}'
            """

        spark.sql(sql_str)

    @staticmethod
    def _validate_all_external_ids_contain_values(df: DataFrame, external_id_column_name):

        if (df.filter(F.col(external_id_column_name).isNull() | (F.col(external_id_column_name) == F.lit('')))
                .limit(1)
                .count() > 0):
            raise ValueError(f"Column '{external_id_column_name}' is only partially filled with real values. "
                             f"Please either fix the data so all entries have a value in the '{external_id_column_name}' "
                             f"column or remove the '{external_id_column_name}' column.")

    @staticmethod
    def _create_id_mapping(unmapped_ids_df: DataFrame, id_mapping_table_df: DataFrame,
                           internal_id_column_name: str, external_id_column_name: str, feed_id: str,
                           fast: bool, id_mapping_table_name: str) -> DataFrame:

        AdrmIdsMapper._validate_mapping_creation_allowed(
            AdrmIdsMapper._get_id_mapping_table_current_feed_df(
                id_mapping_table_df,
                feed_id),
            internal_id_column_name,
            external_id_column_name,
            unmapped_ids_df,
            id_mapping_table_name)

        calculated_long_id_column_name = "calc_long_id"

        max_adrm_id = id_mapping_table_df.select(F.max(GlobalConstants.ADRM_ID_COLUMN_NAME)).collect()[0][0]

        if not max_adrm_id:
            max_adrm_id = 0

        summed_columns = ['max_adrm_id', 'const_one', 'long_id']

        expression = '+'.join(summed_columns)

        ids_to_map = unmapped_ids_df.select(internal_id_column_name, external_id_column_name) \
            .filter(F.col(internal_id_column_name).isNotNull()) \
            .filter(F.col(external_id_column_name).isNotNull())
        if fast:
            generated_ids_df: DataFrame = ids_to_map \
                .select("*", F.lit(max_adrm_id).alias("max_adrm_id"), F.lit(1).alias("const_one"),
                        F.monotonically_increasing_id().alias("long_id")) \
                .select("*", F.expr(expression).alias(calculated_long_id_column_name))
        else:
            if DataFrameUtils.is_not_empty(ids_to_map):
                generated_ids_df: DataFrame = ids_to_map \
                    .select("*",
                            F.lit(max_adrm_id).alias("max_adrm_id"),
                            F.lit(1).alias("const_one")) \
                    .rdd.zipWithUniqueId().toDF() \
                    .select("*", F.col('_1.*'), F.col('_2').alias("long_id")) \
                    .select("*", F.expr(expression).alias(calculated_long_id_column_name))
            else:
                generated_ids_df: DataFrame = ids_to_map \
                    .select("*", F.lit(None).cast(LongType()).alias(calculated_long_id_column_name))

        return generated_ids_df \
            .select(F.col(internal_id_column_name).alias(GlobalConstants.INTERNAL_ID_COLUMN_NAME),
                    F.col(external_id_column_name).alias(GlobalConstants.EXTERNAL_ID_COLUMN_NAME),
                    F.col(calculated_long_id_column_name).alias(GlobalConstants.ADRM_ID_COLUMN_NAME),
                    F.lit(feed_id).alias(GlobalConstants.FEED_ID_COLUMN_NAME))

    @staticmethod
    def _validate_mapping_creation_allowed(id_mapping_table_df: DataFrame,
                                           internal_id_column_name: str,
                                           external_id_column_name: str,
                                           unmapped_ids_df: DataFrame,
                                           id_mapping_table_name: str):
        def _mapping_table_has_values_in_external_id_column(id_mapping_table_df: DataFrame) -> bool:
            return (id_mapping_table_df.
                    filter(F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME).isNotNull() &
                           (F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME) != F.lit(""))).limit(1).count() == 1)

        def _current_data_has_no_values_in_external_id_column(df: DataFrame, external_id_column_name: str) -> bool:
            return (df.filter(F.col(external_id_column_name).isNotNull() &
                              (F.col(external_id_column_name) != F.lit(""))).limit(1).count() == 0)

        if (_mapping_table_has_values_in_external_id_column(id_mapping_table_df) and
                _current_data_has_no_values_in_external_id_column(unmapped_ids_df, external_id_column_name)):
            unrecognized_ids_df = \
                unmapped_ids_df.join(id_mapping_table_df,
                                     id_mapping_table_df[GlobalConstants.INTERNAL_ID_COLUMN_NAME] ==
                                     unmapped_ids_df[internal_id_column_name],
                                     "anti")
            if unrecognized_ids_df.limit(1).count() == 1:
                raise ValueError(f"Unable to execute IDs mapping for table {id_mapping_table_name}."
                                 f"Reason: Current data set contains more IDs in column {internal_id_column_name} than"
                                 f"can be processed correctly.")

    @staticmethod
    def _get_id_mapping_table_current_feed_df(id_mapping_table_df: DataFrame, feed_id: str) -> DataFrame:
        return id_mapping_table_df.where(f"{GlobalConstants.FEED_ID_COLUMN_NAME} == '{feed_id}'")

    @staticmethod
    def _map_ids_from_other_feeds(unmapped_ids_in_current_feed_df: DataFrame,
                                  id_mapping_table_df: DataFrame,
                                  internal_id_column_name: str,
                                  external_id_column_name: str,
                                  id_mapping_column_in_use: str,
                                  data_id_column_in_use: str,
                                  feed_id: str) -> Tuple[DataFrame, DataFrame]:
        if not AdrmIdsMapper._should_map_to_ids_from_another_feed(internal_id_column_name, external_id_column_name):
            return (
                unmapped_ids_in_current_feed_df,
                unmapped_ids_in_current_feed_df.sparkSession.createDataFrame(data=[], schema=AdrmIdsMapper.SCHEMA)
            )

        id_mapping_table_other_feeds_df = id_mapping_table_df. \
            where(f"{GlobalConstants.FEED_ID_COLUMN_NAME} != '{feed_id}'")

        attempted_mapped_ids_from_other_feeds_df = \
            AdrmIdsMapper._join_with_existing_ids(unmapped_ids_in_current_feed_df, id_mapping_table_other_feeds_df,
                                                  id_mapping_column_in_use, data_id_column_in_use)

        unmapped_ids_from_other_feeds_df = attempted_mapped_ids_from_other_feeds_df.filter(
            f"{GlobalConstants.ADRM_ID_COLUMN_NAME} is null"). \
            select(unmapped_ids_in_current_feed_df.columns)

        mapped_ids_from_other_feeds_df = attempted_mapped_ids_from_other_feeds_df. \
            filter(f"{GlobalConstants.ADRM_ID_COLUMN_NAME} is not null"). \
            select(F.col(internal_id_column_name).alias(GlobalConstants.INTERNAL_ID_COLUMN_NAME),
                   F.col(external_id_column_name).alias(GlobalConstants.EXTERNAL_ID_COLUMN_NAME),
                   F.col(GlobalConstants.ADRM_ID_COLUMN_NAME),
                   F.lit(feed_id).alias(GlobalConstants.FEED_ID_COLUMN_NAME))

        return (unmapped_ids_from_other_feeds_df, mapped_ids_from_other_feeds_df)

    @staticmethod
    def _get_unmapped_ids_in_current_feed(source_df: DataFrame, id_mapping_table_df: DataFrame,
                                          id_mapping_column_in_use: str, data_id_column_in_use: str,
                                          feed_id: str) -> DataFrame:
        id_mapping_table_current_feed_df = AdrmIdsMapper._get_id_mapping_table_current_feed_df(id_mapping_table_df,
                                                                                               feed_id)

        attempted_mapped_ids_in_current_feed_df = AdrmIdsMapper._join_with_existing_ids(source_df,
                                                                                        id_mapping_table_current_feed_df,
                                                                                        id_mapping_column_in_use,
                                                                                        data_id_column_in_use)

        return attempted_mapped_ids_in_current_feed_df.filter(
            f"{GlobalConstants.ADRM_ID_COLUMN_NAME} is null") \
            .select(*source_df.columns)

    @staticmethod
    def _save_mappings(spark: SparkSession, df: DataFrame, id_mapping_tables_location: str, id_mapping_table_name: str):
        location = AdrmIdsMapper.specific_table_location(id_mapping_tables_location, id_mapping_table_name)

        df. \
            write. \
            mode("append"). \
            format(AdrmIdsMapper.DATA_FORMAT). \
            partitionBy(GlobalConstants.FEED_ID_COLUMN_NAME). \
            save(location)

    @staticmethod
    def _join_with_existing_ids(unmapped_ids: DataFrame, mapping_table_df: DataFrame,
                                id_mapping_column_in_use: str, data_id_column_in_use: str) -> DataFrame:
        return unmapped_ids.join(mapping_table_df,
                                 on=[unmapped_ids[data_id_column_in_use] == mapping_table_df[id_mapping_column_in_use]],
                                 how="left"
                                 ).drop(GlobalConstants.INTERNAL_ID_COLUMN_NAME,
                                        GlobalConstants.EXTERNAL_ID_COLUMN_NAME)

    @staticmethod
    def is_external_id_mapped(mapping_df: DataFrame) -> bool:
        return not mapping_df.filter(
            (F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME) != "") &
            (F.col(GlobalConstants.EXTERNAL_ID_COLUMN_NAME).isNotNull())
        ).limit(1).isEmpty()

    @staticmethod
    def _get_id_columns_in_use(mapping_table_df: DataFrame, internal_id_column_name: str, external_id_column_name) -> \
            Tuple[str, str]:
        if AdrmIdsMapper.is_external_id_mapped(mapping_table_df):
            return (GlobalConstants.EXTERNAL_ID_COLUMN_NAME, external_id_column_name)
        else:
            return (GlobalConstants.INTERNAL_ID_COLUMN_NAME, internal_id_column_name)

    @staticmethod
    def get_mapping_table_name(target_table_name: str) -> str:
        return target_table_name.upper() + GlobalConstants.ID_MAPPING_TABLE_NAME_SUFFIX

    @staticmethod
    def _validate_all_ids_are_unique(df: DataFrame, ids_column_name: str):
        # This method validates that all ids are unique
        # Group by the id column and count occurrences
        duplicate_count_df = df.groupBy(ids_column_name).agg(F.count(ids_column_name).alias('count'))

        # Filter to find ids with more than one occurrence
        duplicate_ids = duplicate_count_df.filter(F.col('count') > 1)

        # If any duplicates are found, raise an exception
        if duplicate_ids.count() > 0:
            raise ValueError(f"Column '{ids_column_name}' contains duplicate values. "
                             f"Please ensure all values are unique.")

# SIG # Begin Windows Authenticode signature block
# MIIoLQYJKoZIhvcNAQcCoIIoHjCCKBoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCm3I3vAGgyjfMz
# qpm3fgGmN7Ew/f9W9bRQUCKAa2HDR6CCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIHP/0qNcIjZGqyBJY7km803B
# ES2kD2iTOkeMQytrOHxTMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAKW4gnoKCPwqNqkQ1lfkwax2xKbG5D/zFjvAwDjux4G9X/hpWpUGuKSOb
# 5c+NgIE8XouoVZJAJFyTXxHppTpeoXvyhcp61YpxGJ4/Tz4knvKsHoaEJnYNCYur
# Ux9yDxn0ktpHwlG5utuHK9SHZGNq8wTgFV2CLkBjQbcqknGNIyZ0fqdRJ15SoP1x
# S3ZXqU2nWURx5hppF6kSWxhjpYLhInbdCNj4gHwb5IFVT9BtjkM8BDdN270vCqXo
# eu79UjQdaass3UwCZYHPPenx90sbUJ3IUdrFXf1PAouvrg7T/IN0l/CHvu2UGBXG
# 8s2xsMV/qEP0AB/aWKdiIiOGOt47tqGCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCC
# F38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBhUDMp1DhuXhOVW1q4edF5hgjUAkDk9cLnPFS+Upj64wIGaEsR/yfL
# GBMyMDI1MDcxNjA0MjIxMC44NjhaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046N0YwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHtMIIHIDCCBQigAwIBAgITMwAAAgbXvFE4mCPsLAABAAACBjANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQy
# NTBaFw0yNjA0MjIxOTQyNTBaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046N0YwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDpRIWbIM3Rlr397cjHaYx85l7I+ZVWGMCBCM911BpU
# 6+IGWCqksqgqefZFEjKzNVDYC9YcgITAz276NGgvECm4ZfNv/FPwcaSDz7xbDbsO
# oxbwQoHUNRro+x5ubZhT6WJeU97F06+vDjAw/Yt1vWOgRTqmP/dNr9oqIbE5oCLY
# dH3wI/noYmsJVc7966n+B7UAGAWU2se3Lz+xdxnNsNX4CR6zIMVJTSezP/2STNcx
# JTu9k2sl7/vzOhxJhCQ38rdaEoqhGHrXrmVkEhSv+S00DMJc1OIXxqfbwPjMqEVp
# 7K3kmczCkbum1BOIJ2wuDAbKuJelpteNZj/S58NSQw6khfuJAluqHK3igkS/Oux4
# 9qTP+rU+PQeNuD+GtrCopFucRmanQvxISGNoxnBq3UeDTqphm6aI7GMHtFD6DOjJ
# lllH1gVWXPTyivf+4tN8TmO6yIgB4uP00bH9jn/dyyxSjxPQ2nGvZtgtqnvq3h3T
# RjRnkc+e1XB1uatDa1zUcS7r3iodTpyATe2hgkVX3m4DhRzI6A4SJ6fbJM9isLH8
# AGKcymisKzYupAeFSTJ10JEFa6MjHQYYohoCF77R0CCwMNjvE4XfLHu+qKPY8GQf
# sZdigQ9clUAiydFmVt61hytoxZP7LmXbzjD0VecyzZoL4Equ1XszBsulAr5Ld2Kw
# cwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFO0wsLKdDGpT97cx3Iymyo/SBm4SMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQB23GZOfe9ThTUvD29i4t6lDpxJhpVRMme+
# UbyZhBFCZhoGTtjDdphAArU2Q61WYg3YVcl2RdJm5PUbZ2bA77zk+qtLxC+3dNxV
# sTcdtxPDSSWgwBHxTj6pCmoDNXolAYsWpvHQFCHDqEfAiBxX1dmaXbiTP1d0Xffv
# gR6dshUcqaH/mFfjDZAxLU1s6HcVgCvBQJlJ7xEG5jFKdtqapKWcbUHwTVqXQGbI
# lHVClNJ3yqW6Z3UJH/CFcYiLV/e68urTmGtiZxGSYb4SBSPArTrTYeHOlQIj/7lo
# VWmfWX2y4AGV/D+MzyZMyvFw4VyL0Vgq96EzQKyteiVeBaVEjxQKo3AcPULRF4Uz
# z98P2tCM5XbFZ3Qoj9PLg3rgFXr0oJEhfh2tqUrhTJd13+i4/fek9zWicoshlwXg
# Fu002ZWBVzASEFuqED48qyulZ/2jGJBcta+Fdk2loP2K3oSj4PQQe1MzzVZO52AX
# O42MHlhm3SHo3/RhQ+I1A0Ny+9uAehkQH6LrxkrVNvZG4f0PAKMbqUcXG7xznKJ0
# x0HYr5ayWGbHKZRcObU+/34ZpL9NrXOedVDXmSd2ylKSl/vvi1QwNJqXJl/+gJkQ
# EetqmHAUFQkFtemi8MUXQG2w/RDHXXwWAjE+qIDZLQ/k4z2Z216tWaR6RDKHGkwe
# CoDtQtzkHTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQ
# MIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjdGMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAE
# a0f118XHM/VNdqKBs4QXxNnN96CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7CEPAjAiGA8yMDI1MDcxNTE3MzE0
# NloYDzIwMjUwNzE2MTczMTQ2WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDsIQ8C
# AgEAMAoCAQACAhxnAgH/MAcCAQACAhQkMAoCBQDsImCCAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQELBQADggEBAI8qZmt72WkLpG1rEXIWwyLP4v43d0f7l+oXhQPf6CET
# LxfbXjMfcmUx7KqFMJqToUO/Yty56DEolqKcBzD+U5lIa4RqdEwTUqxt85uDmUfA
# Q+5Q7+ooaGQbDxTM0b8YzZPy/0AjnvOSWPD7n10g7w/WtgD3nj1f6VAtcgzFuGhh
# 5rpvzMH9zRh+pwZXruqvgCfDJKQxMfBYDOKugKmErcSlMivd5H4X13YKGDBjevDC
# /h9DS2Bgen48rbf1zAxco7dGGGEc5ivDpnrv/c/Bg2dGWPqnSd8ES4E2tsqZbO+m
# 3nwCf+fhzmUASPTle96ewhayjkV9SITfw0RmnF0C9S4xggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAgbXvFE4mCPsLAABAAAC
# BjANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCDcNgxCfbONuCyRTQyRUlb9P1lZvh2H04YHK4ZPb+Ye
# 0jCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIODo9ZSIkZ6dVtKT+E/uZx2W
# Ay7KiXM5R1JIOhNJf0vSMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAIG17xROJgj7CwAAQAAAgYwIgQgChc67iy91y+c9C2Wt5PDX0f2
# 1lCg1udgJkpfHGHM2YowDQYJKoZIhvcNAQELBQAEggIAKj9IyRv1N/yhNuqG0xMo
# 7JJpuMKTM8KCeD9dVkNhUjJ33hWNoZ0i1/AOKHqL0v9tqJCKFdL7gR1zuVCGM8qu
# Ya7PRYT4MclhXTPK+UUPP+OOUz5jilEkiejylV0aJ6Y7fYbPZeVMlVnqa14N7V50
# Av48D6hKVqldrhTIUYMBe+4V5mgnVAcZJdRbboERY9wH7ZAxtKufZgIcSUl7htX2
# zhQCW0h+c8hdGWwg7/CM7s7ESEPm06540ayWOVzX3U5N09kEfUq4gEy+myYL6pjX
# M2JuSen8Apl85VQ5f1SkOoADax7fRQDGspYHmSEI9pjBr6CM/PmPXmi/2xLYoG/A
# hK4fFb0DvusUrp025e7TDx0x4x8AehXha4sYF8zFrRzBjys4sBfPbCaBdNK0mDRR
# TYyyvLCLPgphLSTYdqBLuYhACvoRMMxch5s1LAiQsDElSVLNzjgNiR+Xeqwq1t+9
# Nxisa4V5by2u6ORdgr3vYH/dgwYuAB5s+SHLPwBiMFH/gBXTOJVMyvdD5h58AIH/
# IdNV2CBHu9E9+Krj5Q1KIpt854DoibUtKpQETywGtLighfMyKlSiDIUmIeYNt7mk
# C8IdCYApT4aWbMogDIAIFcbmSpP55jIGAaUcvEbZ8yVcJDS1Rj2z57QlllhV856o
# 9XtKX7rZRIxWDqomNYqg5Cg=
# SIG # End Windows Authenticode signature block