from typing import FrozenSet, List

from common.model.source_to_reference_mapping import SourceToReferenceMapping
from pyspark.sql import DataFrame, SparkSession

from common.utils.logging import Logger
from dmf.model.reference_values_configuration import ReferenceValuesConfiguration
from dmf.reference_values.reference_values_mapping_reader import ReferenceValuesMappingReader
from dmf.reference_values.reference_values_mapping_schema import ReferenceValuesMappingSchema
from dmf.utils.dataframe_utils import DataFrameUtils
from dmf.utils.global_constants import GlobalConstants


class ReferenceValuesEnricher:
    def __init__(self, reference_mapping_df: DataFrame, reference_values_configuration: ReferenceValuesConfiguration):
        self.reference_values_configuration = reference_values_configuration
        if reference_mapping_df is None:
            self.reference_mapping_df = None
        else:
            self.reference_mapping_df = reference_mapping_df.where(
                f"{ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN} = "
                f"'{self.reference_values_configuration.source_domain}'")
        self.reference_mapping_df_by_target_table_and_field = {}

    def _get_filtered(self, target_table: str, target_field: str) -> DataFrame:
        # get the mapping for the target table and field from cache or create it
        key: str = f"{target_table}{target_field}"
        if key not in self.reference_mapping_df_by_target_table_and_field:
            self.reference_mapping_df_by_target_table_and_field[key] = \
                self.reference_mapping_df.where(f"{ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE} ="
                                                f" '{target_table}' and {ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD} = '{target_field}'")
            self.reference_mapping_df_by_target_table_and_field[key].cache()
        return self.reference_mapping_df_by_target_table_and_field[key]

    def enrich(self, source_df: DataFrame,
               source_to_reference_mappings: FrozenSet[SourceToReferenceMapping],
               replace_values_in_src_column: bool = True) -> DataFrame:
        source_fields = []
        for source_to_reference_mapping in source_to_reference_mappings:
            if source_to_reference_mapping.source_field_name in source_df.columns:
                source_fields.append(source_to_reference_mapping.source_field_name)
                filtered_mapping_df = self._get_filtered(source_to_reference_mapping.target_reference_table_name,
                                                         source_to_reference_mapping.target_reference_field_name)
                joined_df = source_df.join(
                    filtered_mapping_df,
                    on=source_df[source_to_reference_mapping.source_field_name].cast("string") == filtered_mapping_df[
                        ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE],
                    how='leftouter')
                source_df = joined_df.drop(ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_SOURCE_VALUE,
                                           ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_SOURCE_DOMAIN,
                                           ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_TARGET_TABLE,
                                           ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_TARGET_FIELD)
                if not replace_values_in_src_column:
                    source_fields.remove(source_to_reference_mapping.source_field_name)
                    source_fields.append(source_to_reference_mapping.mapped_column_name)
                    required_mapped_column_name = source_to_reference_mapping.mapped_column_name
                else:
                    source_df = source_df.drop(source_to_reference_mapping.source_field_name)
                    required_mapped_column_name = source_to_reference_mapping.source_field_name
                source_df = DataFrameUtils.with_column_renamed_fast(source_df,
                                                                    ReferenceValuesMappingSchema.MAPPING_FIELD_NAME_TARGET_VALUE,
                                                                    required_mapped_column_name)
                Logger.debug(f"Reference column enriched: {source_to_reference_mapping.source_field_name} with "
                             f"{source_to_reference_mapping.target_reference_table_name}.{source_to_reference_mapping.target_reference_field_name}")
            else:
                msg = (f"Reference values enriching. Source field: '{source_to_reference_mapping.source_field_name}' "
                       f"was not found in the source dataframe: '{source_df.columns}'")
                raise Exception(msg)
            source_df = self.handle_unmatched_values(source_df, source_fields)
        Logger.debug(f"Reference values enriching end. Source fields: {str(source_fields)}")
        return source_df

    def handle_unmatched_values(self, source_df: DataFrame, source_fields: List[str]) -> DataFrame:
        adapter_name = source_df.sparkSession.conf.get(GlobalConstants.SPARK_CONFIG_ADAPTER_NAME_VARIABLE, None)
        dtt_start_execution_time = source_df.sparkSession.conf.get(GlobalConstants.SPARK_CONFIG_DTT_START_EXECUTION_TIMESTAMP, None)
        if self.reference_values_configuration.fail_upon_missing_reference_values:
            Logger.debug("'fail_upon_missing_reference_values' is true, checking for unmatched values.")
            where_str = " is NULL or ".join(source_fields) + " is NULL"
            null_df = source_df.where(where_str)
            if DataFrameUtils.is_not_empty(null_df):
                msg = "Reference values enriching. Source values where not found in the mapping table. " \
                    "Failing due to setting in adapter: failUponMissingReferenceValues = true"
                missing_reference_value_msg = "DTT has stopped execution."
                self._log_missing_reference_value(missing_reference_value_msg, adapter_name, dtt_start_execution_time)
                raise Exception(msg)

        else:
            Logger.debug(f"Reference filling with default value {self.reference_values_configuration.default_value}.")
            if self.reference_values_configuration.default_value is not None:
                missing_reference_value_msg = "DTT continues the execution. A default value is used to populate the target reference value."
                self._log_missing_reference_value(missing_reference_value_msg, adapter_name, dtt_start_execution_time)
                source_df = source_df.fillna(self.reference_values_configuration.default_value, source_fields)
        return source_df

    def _log_missing_reference_value(self, msg: str, adapter_name: str | None, dtt_start_execution_time: str | None):
        if(adapter_name and dtt_start_execution_time):
            Logger.error(f"At least one source reference value isn't mapped to a target reference value. {msg}.\
                         DTT execution has started at: {dtt_start_execution_time}.\
                         DTT adapter name is: {adapter_name},\
                         adapter source domain is: {self.reference_values_configuration.source_domain}.\
                         Please refer to the documentation, to learn how Reference Data Management can help fix the issue",
                         extra={"dtt_start_execution_timestamp": dtt_start_execution_time,
                                "adapter_source_domain": self.reference_values_configuration.source_domain,
                                "dtt_adapter_name": adapter_name})

    @staticmethod
    def create_from_mapping_file(spark: SparkSession,
                                 reference_values_configuration: ReferenceValuesConfiguration) -> "ReferenceValuesEnricher":
        reference_values_mapping_df = ReferenceValuesMappingReader.read(spark, reference_values_configuration)
        if reference_values_mapping_df is None:
            if reference_values_configuration.default_value is None:
                msg = "Reference values mapping table could not be loaded and no default value was defined in adapter"
                raise Exception(msg)
            else:
                reference_values_mapping_df = spark.createDataFrame([], ReferenceValuesMappingSchema.SCHEMA)
        return ReferenceValuesEnricher(reference_values_mapping_df, reference_values_configuration)

# SIG # Begin Windows Authenticode signature block
# MIIoQAYJKoZIhvcNAQcCoIIoMTCCKC0CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB58JXFCGdfQypd
# u6FTc3pYA+WuQimMf6JFSkx7CZ8jnaCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiAwghocAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIERJI54PbNe5rn+ggG6SlkYL
# oe7n60YSrh0ra5NL6b47MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEASNHR1bH3R6mqq4RAl+AALMD7WJqT4cjCsE7I14JVFwflud5hF6g8Qn6S
# VZZo+opFxBVo7QqECkyGTFvtNluhHGj9o15ZvlDsVu1C0lnDlqBjTDrSox+IWUdY
# n/bMQFz0NH3i9xcHoGssEoMBcJGmTL7RBAOHn8MuZrScL6naOw6keKeNZHEvhu+X
# ZsCm1AfuuS7ZtIFDbj2a3F/0DVaD1VTDnnGwfrd151W9PEXicqFkpNlu7x2w1r4v
# VaHgNdc0/LAkBq3yosEmwc4C16s3Uam7JPqIZO19PmvVT+/jN+rb+cffzpbdT8A+
# f1Vmk66ApVNPu3IUxhfvsuWjtsygGaGCF6owghemBgorBgEEAYI3AwMBMYIXljCC
# F5IGCSqGSIb3DQEHAqCCF4Mwghd/AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFYBgsq
# hkiG9w0BCRABBKCCAUcEggFDMIIBPwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCQQzE88an7UmcA9p7zfY3HUiYQTTsumQ86yywZDFY1+QIGaC3A8vlS
# GBEyMDI1MDcxNjA0MjIwNy40WjAEgAIB9KCB2aSB1jCB0zELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxh
# bmQgT3BlcmF0aW9ucyBMaW1pdGVkMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046
# NkIwNS0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNl
# cnZpY2WgghH6MIIHKDCCBRCgAwIBAgITMwAAAfaDLyZqVF0iwQABAAAB9jANBgkq
# hkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNDA3
# MjUxODMxMDRaFw0yNTEwMjIxODMxMDRaMIHTMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVy
# YXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo2QjA1LTA1
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANFCXizEfzfVjwWYbilRRfnl
# iWevFro3Y+F+iUdOXMTuQnqTV6Ne61Ws8Fi5JuQI2lYdfWVYwwoR84psbKGl8Tbv
# CA4ICsKV76QACLb+FMedHvUtrlcHyr+e6fSShvkO1TjUobo5dTQjJHIEqz3Znf/M
# 3LJoc3DaGy6JqwgCDkWfCMIWMuLIlUJX9TSoZcgM5pFiQ9DfutCIqIBQc4N8iErL
# 66DsdMdcUotj4kSEJU1xO+DIIGQyAyqh/4W/RU9pCv51f2l47qPSzK60Zp+OKGGA
# A3v6zveRfkht7rroX/h+CK4l69IfabQOksByT0tlZmzVgo0FquRuGJK3KmzzGse7
# zV1MLu0+uRPHxT3dSLhPUbBuEzAFe15FwaKZjzX7y9IY8YOOJKUJ9/OFeOqPs3UK
# suSvXQ5Vpvyer2baecgNT8g98Ph2xrm0tJ4hENS+sBjqz38yJtBXTp/sRaOPBEZf
# hccP9zr1zOQmNRKp8xM5z48yXOzicISVUd1UAx4wXBBUzr0vRNHYjbtXqHMPmQpM
# +D7v6EL/oKlPm38S/HuzxZLX0Q5TOhcjs4z+M7iNuYA/LTvcyYOoOn0aWmXON/Zg
# G5Jd8wlc0yw4HIb+ksUGoybb76EGmcUH9LUYj3G69h1nzKKqnfbokNIU1BIRuOBQ
# Uk3lD2XhHp0QlmnQluBvAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUSMGbCbjnCX0n
# D1nF2bgQOAfPSvIwHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBANd5AYqx9XB7tVmE
# dcrI9duaJhrUND2kJBM8Bm+9MbakqCPrL0IobIHU2MWj36diFRXYI2jGgYvNcAfP
# 57vOuhXxSinYXad8JzGfdT6T+DqHuzXH+qiApIErsIHSHUL6hNIfFUOUFubA1eEN
# CZ4+H+yh2MeDYjPAuI08PEkLbLsVokx9h4pH90GAe9Wu3Qfc4BzpFtIYFBHljvZo
# dsFqmEv0OPAEozqmMP4WueKFTn39tlmqB/vx8XfTUxFP+L5b7ESDFk9I7JzSO9Y1
# QK0+EPQbelUoVs8qq2hOkilKGaxMAaVbCNCzINl94Ti25Qtb8TN/sDMjofe2hTrO
# 7BZ7nprSNjH4/KoNegWUycV5aT7q1qxvjgY+AaEw5AvQMV2Ad8hLbsDLO6UVi8sS
# McP8FfUxylBpvsflRNDzi8JK0jII7pUl5KXxCx1loglbJSWxSCAf+AJb/o0CUigC
# bqPQhK25tqng5P84yWJWGlRjMirmGfrkkVSgdqpBD3BMxtXTvcyGtTKd9ifs81tz
# +7LiX48OtrN4Qzi5PupTEDkdOMftqNexty3Hi5JMSZuNRK3Yk4wJnQpXp/cpeh4D
# KRkuKJIxQiV/gqThV+4AQNz1cUFrm4rAEGy+R4ExQbUDRM3AnYdRmMP+p88zTbft
# BkJ56GwXXXzgIqpM7yLal47xsitUMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCA1UwggI9AgEBMIIBAaGB2aSB1jCB0zELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxh
# bmQgT3BlcmF0aW9ucyBMaW1pdGVkMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046
# NkIwNS0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNl
# cnZpY2WiIwoBATAHBgUrDgMCGgMVABVPXkqXcbNGtOiRSLhhRyI/yPt+oIGDMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQELBQAC
# BQDsIWYnMCIYDzIwMjUwNzE1MjM0MzM1WhgPMjAyNTA3MTYyMzQzMzVaMHMwOQYK
# KwYBBAGEWQoEATErMCkwCgIFAOwhZicCAQAwBgIBAAIBXjAHAgEAAgISgzAKAgUA
# 7CK3pwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAID
# B6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQDJovp7C7DlaPud16JA
# a47nQTF5BYa6h73E2gC9kziqmxNZv8WqKLefPzWzuaS1UMhbs47veRbrIuJx6j6n
# VySbipZkbh088gRJ5gf3H207bhlmemXZrwPbEKZD7h4W0+9+NU+HcmzXkkpnye6q
# rnFlETwoOnUx1zOgXSRO+jAqf1Wl/tx1zw6XwSKmzaFDAhzYplUSRiLSHqYs3Wlu
# tf+cpQaScJyM7nINIgYWT/bn5cgHEnmvriOjX81zmQHQZFoH/pz++56v4urZ2Piv
# vDOmjgJPXYsu6fWA2UOdHzU+MxoA2YsuXEq5ZVsOg91nWxPKTGBNZszUSW7HVq5K
# Emm5MYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAAH2gy8malRdIsEAAQAAAfYwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgTvQiKis1DdxECJhZ
# TNIStFzAxjFQSJgjGqetyOZ+GI0wgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCArYUzxlF6m5USLS4f8NXL/8aoNEVdsCZRmF+LlQjG2ojCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB9oMvJmpUXSLBAAEAAAH2MCIE
# IC9iYXztG1fZ/wtrDiGsrHnIwdRf7GgtZYRdgn7l30pWMA0GCSqGSIb3DQEBCwUA
# BIICAHNM7NZIY4/45EJgW0fkpjkfCioghV6Ar+YtYdGBHb+Y7AuxcomB28JukaaS
# jWqLUyXPUIMyl7nbdaZo+DXQzD9psUGv501wYIibo/ColKXoD3psapAj/XKPWgWj
# Scx47Tg+P/+XU5b7qtYrLx/UWeJMlPnehGiq37LKYDDsNBXx9nohxJ3LkY+NCE5R
# caRSdW7phVLQZo9YjVq+Di2M/NpMWuzdlCzhqQLO2xzVxDMGZFthHVBQ+9GfEMsa
# 0iwhDi+HmWaRY85xU7+ts5xXHN7Zirn+ftFaunRe9rWuu7W0NkjK3BhNrTjVt9p0
# rA9esCGH63TVm9+T4/SH7UL3XBov8uxdeyavr6DbYVqEuQZYgo1z65zFIM+gIt5U
# rdJm9aN6d90cyOlNul2G4imLU+9+l5dFqX2sOO90JlZ/7i8n+WUjIVwP+lAJeK0F
# XZ65Lo7ZUbmZBIRJ9CBkjbMZgB5ImikkYu/8xax6JzYDfbbLdpm+1m2RuR3I46me
# xUstbqbRWklVwHVqN+BZWupyKCz79TaEnityyAtd07NkFpbsbaavMPdtm+/9hAE9
# at6Xiw9sDZWoDMp5IATBufoZ2fbcmkQGe3oyjiT+7Vxvz30KrWd4Qx3jDzA4JhGl
# 6CmOOPCkWr/cQLR4WJY/mgS9Q27v6nlA+GHn9Vpjv4VsNpqQ
# SIG # End Windows Authenticode signature block