"""
api.py
-------

This module provides the main API for generating and persisting DTT and RMT specifications from given configuration files.
It also provides an API for getting proposed paths for a given source table and target field.

Functions
---------
persist_dtt_spec
    Generates a DTT spec from the given configuration files and persists it to the given path.

persist_rmt_spec
    Generates an RMT spec from the given configuration files and persists it to the given path.

generate_dtt_specs
    Generates DTT and RMT specs from the given configuration files and persists them to the given paths.
    merely calls persist_dtt_spec and persist_rmt_spec.

get_proposed_paths
    Returns a ProposedPathsResponse object containing the proposed paths from the source table to the target field.
    used by the VsCode extension UI to get proposed paths for a given source table and target field.

_persist_model(config, out_path, exclude=None):
    Persists the given Pydantic model to the given path.

_get_notebookutils():
    Returns the notebookutils module if it is loaded, otherwise returns None.

"""
from pathlib import Path
import sys
from configuration_compiler.constants import Constants
from configuration_compiler.telemetry_reporter import TelemetryReporter
from pyspark.sql import SparkSession
from configuration_compiler.configuration_content_wrapper import (
    DttConfigurationContentWrapper,
    RmtConfigurationContentWrapper,
)
from configuration_compiler.column_transformation.proposed_paths_generator import ProposedPathsResponse
from configuration_compiler.data_feed_configuration_compiler import DataFeedConfigurationCompiler
from configuration_compiler.mount_helpers import LocalFileSystemAccess

from configuration_compiler.path_helpers import uri_parent_path
from configuration_compiler.rmt_configuration_compiler import RMTConfigurationCompiler
from pydantic.main import BaseModel

telemetry_reporter = TelemetryReporter()

telemetry_reporter.report_usage(TelemetryReporter.LIBRARY_IMPORT_FEATURE_NAME,
                                Constants.CC_IMPORT_TELEMETRY_ACTIVITY_NAME)


def persist_dtt_spec(
    spark: SparkSession,
    out_path: str,
    dmf_adaptor_file_location: str = "",
    target_db_semantics_file_location: str = "",
    target_db_semantics_config_file_location: str = "",
    target_db_schema_file_location: str = "",
    db_schema_config_location: str = "",
    env_config_file_location: str = "",
    adaptor_file_content: str = "",
    target_db_semantics_file_content: str = "",
    target_db_semantics_config_file_content: str = "",
    target_db_schema_file_content: str = "",
    db_schema_config_content: str = "",
    env_config_file_content: str = "",
):
    """Generates a DTT spec from the given configuration files and persists it to the given path.
    Arguments:
        spark: SparkSession
        out_path: str, where to persist the spec
        adaptor_file_location: str, path to the adaptor configuration file
        target_db_semantics_file_location: str, path to the target DB semantics file
        target_db_semantics_config_file_location: str, path to the target DB semantics config file
        target_db_schema_file_location: str, path to the target DB schema file
        db_schema_config_location: str, path to the DB schema config file
        env_config_file_location: str, path to the environment config file
        adaptor_file_content: str, content of the adaptor configuration file
        target_db_semantics_file_content: str, content of the target DB semantics file
        target_db_semantics_config_file_content: str, content of the target DB semantics config file
        target_db_schema_file_content: str, content of the target DB schema file
        db_schema_config_content: str, content of the DB schema config file
        env_config_file_content: str, content of the environment config file
    """
    telemetry_reporter.report_usage(TelemetryReporter.LIBRARY_USAGE_FEATURE_NAME,
                                    Constants.CC_CONFGURATION_COMPILATION_FOR_DMF_TELEMETRY_ACTIVITY_NAME)

    config_content_wrapper = DttConfigurationContentWrapper(
        spark=spark,
        adaptor_path=dmf_adaptor_file_location,
        target_db_semantics_path=target_db_semantics_file_location,
        target_db_semantics_config_path=target_db_semantics_config_file_location,
        target_db_schema_path=target_db_schema_file_location,
        db_schema_config_path=db_schema_config_location,
        env_config_path=env_config_file_location,
        dmf_adaptor_content=adaptor_file_content,
        target_db_semantics_content=target_db_semantics_file_content,
        target_db_semantics_config_content=target_db_semantics_config_file_content,
        target_db_schema_content=target_db_schema_file_content,
        db_schema_config_content=db_schema_config_content,
        env_config_content=env_config_file_content,
    )
    config = DataFeedConfigurationCompiler.compile_configuration(config_content_wrapper)

    out_path_parent = uri_parent_path(out_path)
    with LocalFileSystemAccess(out_path_parent, mode="w", notebookutils=_get_notebookutils()) as lfs:
        out_path_local = lfs.adapt_to_local_path(out_path)
        _persist_model(config, out_path_local)


def persist_rmt_spec(
    spark: SparkSession,
    out_path: str,
    adaptor_file_location: str = "",
    target_db_semantics_file_location: str = "",
    env_config_file_location: str = "",
    target_db_schema_file_location: str = "",
    db_schema_config_location: str = "",
    adaptor_file_content: str = "",
    target_db_semantics_file_content: str = "",
    target_db_schema_file_content: str = "",
    db_schema_config_content: str = "",
    env_config_file_content: str = "",
):
    """Generates an RMT spec from the given configuration files and persists it to the given path.
    Arguments:
        spark: SparkSession
        out_path: str, where to persist the spec
        adaptor_file_location: str, path to the adaptor configuration file
        target_db_semantics_file_location: str, path to the target DB semantics file
        env_config_file_location: str, path to the environment config file
        target_db_schema_file_location: str, path to the target DB schema file
        db_schema_config_location: str, path to the DB schema config file
        dmf_adaptor_file_content: str, content of the adaptor configuration file
        target_db_semantics_file_content: str, content of the target DB semantics file
        target_db_schema_file_content: str, content of the target DB schema file
        db_schema_config_content: str, content of the DB schema config file
        env_config_file_content: str, content of the environment config file
    """
    telemetry_reporter.report_usage(TelemetryReporter.LIBRARY_USAGE_FEATURE_NAME,
                                    Constants.CC_CONFGURATION_COMPILATION_FOR_RMT_TELEMETRY_ACTIVITY_NAME)

    config_content_wrapper = RmtConfigurationContentWrapper(
        spark=spark,
        adaptor_path=adaptor_file_location,
        target_db_semantics_path=target_db_semantics_file_location,
        target_db_schema_path=target_db_schema_file_location,
        db_schema_config_path=db_schema_config_location,
        env_config_path=env_config_file_location,
        adaptor_content=adaptor_file_content,
        target_db_semantics_content=target_db_semantics_file_content,
        target_db_schema_content=target_db_schema_file_content,
        db_schema_config_content=db_schema_config_content,
        env_config_content=env_config_file_content,
    )
    config = RMTConfigurationCompiler.compile_rmt_model(config_content_wrapper)

    out_path_parent = uri_parent_path(out_path)
    with LocalFileSystemAccess(out_path_parent, mode="w", notebookutils=_get_notebookutils()) as lfs:
        out_path_local = lfs.adapt_to_local_path(out_path)
        _persist_model(config, out_path_local)


def generate_dtt_specs(
    spark: SparkSession,
    dtt_spec_out_path: str,
    rmt_spec_out_path: str,
    dmf_adaptor_file_location: str,
    target_db_semantics_file_location: str,
    target_db_semantics_config_file_location: str,
    target_db_schema_file_location: str,
    db_schema_config_location: str,
    env_config_file_location: str,
):
    """Generates DTT and RMT specs from the given configuration files and persists them to the given paths.
    Arguments:
        spark: SparkSession
        dtt_spec_out_path: str, where to persist the DTT spec
        rmt_spec_out_path: str, where to persist the RMT spec
        adaptor_file_location: str, path to the adaptor configuration file
        target_db_semantics_file_location: str, path to the target DB semantics file
        target_db_semantics_config_file_location: str, path to the target DB semantics config file
        target_db_schema_file_location: str, path to the target DB schema file
        db_schema_config_location: str, path to the DB schema config file
        env_config_file_location: str, path to the environment config file
    """
    persist_dtt_spec(
        spark=spark,
        out_path=dtt_spec_out_path,
        dmf_adaptor_file_location=dmf_adaptor_file_location,
        target_db_semantics_file_location=target_db_semantics_file_location,
        target_db_semantics_config_file_location=target_db_semantics_config_file_location,
        target_db_schema_file_location=target_db_schema_file_location,
        db_schema_config_location=db_schema_config_location,
        env_config_file_location=env_config_file_location,
    )
    persist_rmt_spec(
        spark=spark,
        out_path=rmt_spec_out_path,
        adaptor_file_location=dmf_adaptor_file_location,
        target_db_semantics_file_location=target_db_semantics_file_location,
        env_config_file_location=env_config_file_location,
        target_db_schema_file_location=target_db_schema_file_location,
        db_schema_config_location=db_schema_config_location,
    )


def get_proposed_paths(
    dmf_adaptor_file_location: str,
    target_db_semantics_file_location: str,
    target_db_schema_file_location: str,
    db_schema_config_location: str,
    source_table_name: str,
    source_field_name: str,
    target_table_name: str,
    target_field_name: str,
) -> ProposedPathsResponse:
    parent_path_uri = uri_parent_path(dmf_adaptor_file_location)
    with LocalFileSystemAccess(parent_path_uri, mode="r", notebookutils=_get_notebookutils()) as lfs:
        return DataFeedConfigurationCompiler.get_proposed_paths(
            adaptor_file_location=lfs.adapt_to_local_path(dmf_adaptor_file_location),
            target_db_semantics_file_location=lfs.adapt_to_local_path(target_db_semantics_file_location),
            target_db_schema_file_location=lfs.adapt_to_local_path(target_db_schema_file_location),
            db_schema_config_location=lfs.adapt_to_local_path(db_schema_config_location),
            source_table_name=source_table_name,
            source_field_name=source_field_name,
            target_table_name=target_table_name,
            target_field_name=target_field_name,
        )


def _persist_model(config: BaseModel, out_path: Path, exclude=None):
    json_str = config.model_dump_json(indent=2, by_alias=True, exclude=exclude)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(json_str)


def _get_notebookutils():
    if "notebookutils" in sys.modules:
        return sys.modules["notebookutils"]
    return None

# SIG # Begin Windows Authenticode signature block
# MIIoRgYJKoZIhvcNAQcCoIIoNzCCKDMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDaIjlC/luZqIw7
# vEyVL5U07Zc5s7Ip1UEQ8Til49QFbaCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiYwghoiAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIDCC9du6cnWChHFMmIj/v/hY
# WCfaFVnNTcywwG0eKDDRMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAoU3xzVEC9q/Ew3neYobYcWLup4suE46JBSHO2huduVxjUxiG0FM0rc3h
# F/AQ78mQG2cnMGEQJeqQbeWBJRl5snP7bsfuBHMfe03JRsYPSCj8CMlI+Y4fmZMy
# DxLyTBEIyXLYm//k1lWPkXAEXef3L6ycIUtGNQPfMmWnQdHb/UBtBd20psGZmT/r
# AYSCe2YeEJDOjAYsUwAAbN8KBC9vVWPqDU03NhD0NUxWZ5tydgsde9zFTTisySYZ
# cFeUq0DA10hQmrxr8c+CSvbYxCUQup5lhCzWvgnLoU2XRy5x/CqAkN0/FI8z3qJd
# 7gWXYSnUIS0RiZSN3BpTL8C6xwZfN6GCF7AwghesBgorBgEEAYI3AwMBMYIXnDCC
# F5gGCSqGSIb3DQEHAqCCF4kwgheFAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCQ6KzY0IFaupeLYRc8DkYpMCPp05FrsTIT7BAYojWY5AIGaFMCbSPM
# GBMyMDI1MDcxNjA0MjIwNi4wNzRaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo1OTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEf4wggcoMIIFEKADAgECAhMzAAAB9BdGhcDLPznlAAEAAAH0MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzA1OVoXDTI1MTAyMjE4MzA1OVowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjU5MUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEApwhOE6bQgC9qq4jJGX2A
# 1yoObfk0qetQ8kkj+5m37WBxDlsZ5oJnjfzHspqPiOEVzZ2y2ygGgNZ3/xdZQN7f
# 9A1Wp1Adh5qHXZZh3SBX8ABuc69Tb3cJ5KCZcXDsufwmXeCj81EzJEIZquVdV8ST
# lQueB/b1MIYt5RKis3uwzdlfSl0ckHbGzoO91YTKg6IExqKYojGreCopnIKxOvkr
# 5VZsj2f95Bb1LGEvuhBIm/C7JysvJvBZWNtrspzyXVnuo+kDEyZwpkphsR8Zvdi+
# s/pQiofmdbW1UqzWlqXQVgoYXbaYkEyaSh/heBtwj1tue+LcuOcHAPgbwZvQLksK
# aK46oktregOR4e0icsGiAWR9IL+ny4mlCUNA84F7GEEWOEvibig7wsrTa6ZbzuMs
# yTi2Az4qPV3QRkFgxSbp4R4OEKnin8Jz4XLI1wXhBhIpMGfA3BT850nqamzSiD5L
# 5px+VtfCi0MJTS2LDF1PaVZwlyVZIVjVHK8oh2HYG9T26FjR9/I85i5ExxmhHpxM
# 2Z+UhJeZA6Lz452m/+xrA4xrdYas5cm7FUhy24rPLVH+Fy+ZywHAp9c9oWTrtjfI
# KqLIvYtgJc41Q8WxbZPR7B1uft8BFsvz2dOSLkxPDLcXWy16ANy73v0ipCxAwUEC
# 9hssi0LdB8ThiNf/4A+RZ8sCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBQrdGWhCtEs
# Pid1LJzsTaLTKQbfmzAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEA3cHSDxJKUDsg
# acIfRX60ugODShsBqwtEURUbUXeDmYYSa5oFj34RujW3gOeCt/ObDO45vfpnYG5O
# S5YowwsFw19giCI6JV+ccG/qqM08nxASbzwWtqtorzQiJh9upsE4TVZeKYXmbyx7
# WN9tdbVIrCelVj7P6ifMHTSLt6BmyoS2xlC2cfgKPPA13vS3euqUl6zwe7GAhjfj
# NXjKlE4SNWJvdqgrv0GURKjqmamNvhmSJane6TYzpdDCegq8adlGH85I1EWKmfER
# b1lzKy5OMO2e9IkAlvydpUun0C3sNEtp0ehliT0Sraq8jcYVDH4A2C/MbLBIwikj
# wiFGQ4SlFLT2Tgb4GvvpcWVzBxwDo9IRBwpzngbyzbhh95UVOrQL2rbWHrHDSE3d
# gdL2yuaHRgY7HYYLs5Lts30wU9Ouh8N54RUta6GFZFx5A4uITgyJcVdWVaN0qjs0
# eEjwEyNUv0cRLuHWJBejkMe3qRAhvCjnhro7DGRWaIldyfzZqln6FsnLQ3bl+ZvV
# JWTYJuL+IZLI2Si3IrIRfjccn29X2BX/vz2KcYubIjK6XfYvrZQN4XKbnvSqBNAw
# IPY2xJeB4o9PDEFI2rcPaLUyz5IV7JP3JRpgg3xsUqvFHlSG6uMIWjwH0GQIIwrC
# 2zRy+lNZsOKnruyyHMQTP7jy5U92qEEwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDWTCCAkECAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo1OTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAv+LZ/Vg0s17Xek4iG9R9c/7+AI6ggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOwhF4AwIhgPMjAyNTA3MTUxODA4MDBaGA8yMDI1MDcxNjE4MDgwMFowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA7CEXgAIBADAKAgEAAgIUhwIB/zAHAgEAAgIV
# AzAKAgUA7CJpAAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQAvVShaaz9v
# UfXHznZsNCePb+FSNsxdgn5VJEoaEoMYKTwkIsPGDw3iB3k4307/obzUUNsdPqIM
# g5djgmcpXToRse0bP2Tmb1mHlJoT8y7JNJ1ilVz42OyJZ4YE3PjePgyxIHlTp/z5
# WjWhyoykG19zMkqzBmoe6cKOgxla9L7pS3XtUotRFP6jaBjsX/wRVtwp9bRqI+YU
# TZ6WHRUajEf48O8S5gr0cBp12llO3xmWKVNegFZMDqUJfWogs0xcdIU7Tpq9OH98
# 6awvOQ8KIh3BWhtAFma/keDnzeWX+cxWVkVl8C2Z5gZgiWCV4iYg1fOuMWelBq3R
# EXwuFBZgLx4uMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAH0F0aFwMs/OeUAAQAAAfQwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgwWdwCzkQ
# nfET0ILsfQIvnT3qHlDyCuqE8S0Tm492s0IwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCA/WMJ8biaT6njvkknB8Q7hSQIi8ys6vIBvZg60RBjWazCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB9BdGhcDLPznlAAEA
# AAH0MCIEIFAG//J/znDUHXr0+SPLeB1Y5a0ukAsLN6dIFPTnXmb3MA0GCSqGSIb3
# DQEBCwUABIICAIRnGCgATJwHAksijXA03yoRH+GRZKSar9qg4BoFFYh50ubn7iQZ
# yj9hH62irqw3WiSNuTICTVhYDM1wd9eUzO2FPrnlPDCT8ODi0PEqgpgqn8N5m6ml
# w7zeMQpVi2ciYqqasegTAPAMUhRKS0Sr3VMhH6f6hAyCg6doBn70/9vnjBNDFFy0
# z6dQT0kW138H3Ni3F+mo0Y3k2KODJkWUEtg3kXJtxnFTdkj8gcnw9N5IvgbOWOJW
# VcrKi8TdPy1t5LW0KuZfQtVlYKeAzUI24suxxquF9dpY49LEjoVGHZLH2J5q3KtW
# zuTaNStDHjetIrBOStui7E7NVfr1hR2fQdOoXaviTC7F2QkodxK0aEEJw8Itxcny
# O2p2XjSD+xwTgE7hHLAYVEsSP7QN/JZM9ZdnhYwoSWWf8tnHFDJz/18tZxI9VeJ4
# my9H0Wbl3QY9gFT1FZDX6YDF7usCxUP50KjB55S3eNipeGDfOV8Ktb72bLGaI7hk
# 3WpYADEYLr+ou9tqgXJX+RsYGwLhx5xidjo38eKyL9YTAbj4Bm+hhRwyCPFmKix1
# xODc6ddgQZIqrw69a9UQx6Ztu+U+T7D7YCom4X/x1e3TASSni0emrlwqPyRbhYnF
# ttXvlBbvdQbsFkD1nf4yjRCai08nE96v2jd10zAht3GLFUo/Mt8MgUuQ
# SIG # End Windows Authenticode signature block