import json
from collections import defaultdict
from copy import deepcopy
from typing import Optional

from configuration_compiler.config_files_models.db_schema.ext_model import DBSchemaModel
from configuration_compiler.config_files_models.db_schema.model import (
    Column,
    FieldProperties,
    JoinPair,
    ModelItem,
    OriginDataTypeName,
    RelationShip,
)
from configuration_compiler.config_files_models.db_schema_config.model import (
    ConfigField,
    DBConfigExtra,
    ExcludedFields,
    PrimaryKey,
    RawDBConfigModel,
)
from configuration_compiler.config_files_models.semantics.ext_model import SemanticsModel


class DBConfigModel(RawDBConfigModel):
    @classmethod
    def from_str(cls, db_schema_config: str) -> "DBConfigModel":
        try:
            db_config_model = cls(**json.loads(db_schema_config))
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse DB schema config: {e}") from e
        db_config_model.verify_extra_config()
        db_config_model.verify_fields_are_present_in_config()
        return db_config_model

    @staticmethod
    def _filter_required_tables(db_schema: DBSchemaModel, required_tables: dict[str, ExcludedFields]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        db_schema.tables = [t for t in db_schema.tables if t.name in required_tables]
        return db_schema

    @staticmethod
    def _remove_fields(db_schema: DBSchemaModel, required_tables: dict[str, ExcludedFields]) -> None:
        if not required_tables:
            return
        excluded_columns: Optional[ExcludedFields] = None

        def should_keep(column: Column):
            return column.name not in excluded_columns.exclude

        for table_model in db_schema.tables:
            excluded_columns = required_tables.get(table_model.name)
            if not excluded_columns:
                continue
            existing_columns: list[Column] = table_model.storageDescriptor.columns
            table_model.storageDescriptor.columns = list(filter(should_keep, existing_columns))

    @staticmethod
    def _add_fields(
        db_schema: DBSchemaModel,
        fields_to_add: list[ConfigField],
        configuration: DBConfigExtra,
        ref_tables: list[str],
    ) -> None:
        if not fields_to_add:
            return

        fields_grouped_by_table = defaultdict(list)
        for field in fields_to_add:
            if not field.enabled:
                continue
            config_field: ConfigField = deepcopy(field)
            config_field.tables = []
            relevant_tables = DBConfigModel._parse_required_tables_for_added_fields(
                configuration, db_schema, field, ref_tables
            )
            for table_name in relevant_tables:
                fields_grouped_by_table[table_name].append(config_field)
        fields_grouped_by_table = dict(fields_grouped_by_table)

        for table_model in db_schema.tables:
            existing_columns: list = table_model.storageDescriptor.columns
            for config_field in fields_grouped_by_table.get(table_model.name, []):
                new_column = Column(
                    name=config_field.name,
                    originDataTypeName=OriginDataTypeName(
                        typeName=config_field.type,
                        isNullable=True,
                        properties=FieldProperties(
                            minValue=None,
                            maxValue=None,
                            description=config_field.description,
                            dateFormat=None,
                            timestampFormat=None,
                        ),
                        length=None,
                        scale=None,
                        precision=None,
                    ),
                )
                datatype_config: OriginDataTypeName = new_column.originDataTypeName
                if config_field.length is not None:
                    datatype_config.length = config_field.length
                if config_field.scale is not None:
                    datatype_config.scale = config_field.scale
                if config_field.precision is not None:
                    datatype_config.precision = config_field.precision
                existing_columns.append(new_column)

    @staticmethod
    def _parse_required_tables_for_added_fields(
        configuration: DBConfigExtra, db_schema: DBSchemaModel, field: ConfigField, ref_tables: list[str]
    ) -> list[str]:
        field_tables = field.tables
        if field_tables == ["*"]:
            if field.name not in (
                configuration.sourceTableField,
                configuration.modifiedOnTargetField,
            ):
                raise ValueError(
                    f"Table name ('*') in the dbSchemaConfig file is only supported for config field names, e.g., ModifiedDate "
                    f"{(configuration.sourceTableField, configuration.modifiedOnTargetField)}"
                )
            # reference tables are not not altered with '*'
            all_tables_names = [t.name for t in db_schema.tables if t.name not in ref_tables]
            relevant_tables = all_tables_names
        else:
            if "*" in field_tables:
                raise ValueError(
                    f"Invalid table name ('*') in dbSchemaConfig file for config field '{field.name}': in position: {field_tables.index('*')}"
                )
            relevant_tables = field_tables
        return relevant_tables

    @staticmethod
    def _remove_redundant_relations(db_schema: DBSchemaModel, required_tables: Optional[dict]) -> DBSchemaModel:
        if not required_tables:
            return db_schema
        for table_model in db_schema.tables:
            filtered_relationships = []
            for r in table_model.properties.relationships:
                to_entity = r.toEntity
                if to_entity in required_tables:
                    filtered_relationships.append(r)
            table_model.properties.relationships = filtered_relationships
        return db_schema

    def verify_fields_are_present_in_config(self):
        if not self.fields:
            return
        if not self.configuration:
            return

        fields_names = [field.name for field in self.fields if field.enabled]
        for field in [
            self.configuration.modifiedOnTargetField,
            self.configuration.sourceTableField,
        ]:
            if field is not None:
                if field not in fields_names:
                    raise ValueError(f"Field '{field}' is not present in the dbSchemaConfig file")

    @staticmethod
    def _update_primary_keys(db_schema: DBSchemaModel, primary_keys: list[PrimaryKey]) -> None:
        for primary_key in primary_keys:
            try:
                table_model: ModelItem = db_schema.tables_dict[primary_key.table]
            except KeyError as ke:
                raise ValueError(f"Table '{primary_key.table}' was not found in the target schema") from ke
            old_pks = table_model.properties.primaryKeys[:]  # copy
            new_pks = table_model.properties.primaryKeys[:]  # copy
            existing_fields = [column.name for column in table_model.storageDescriptor.columns]
            for key_to_remove in primary_key.config.remove:
                if key_to_remove not in old_pks:
                    raise ValueError(
                        f"PK field '{key_to_remove}' was not found in the target table '{primary_key.table}'[0]"
                    )
                new_pks.remove(key_to_remove)
            for key_to_add in primary_key.config.add:
                if key_to_add in old_pks:
                    raise ValueError(
                        f"PK field '{key_to_add}' is already present in the PK fields collection of the target table '{primary_key.table}'[1]"
                    )
                if key_to_add not in existing_fields:
                    raise ValueError(
                        f"PK field '{key_to_add}' was not found in the PK fields collection of the target table '{primary_key.table}'[2]"
                    )
                new_pks.append(key_to_add)
            for old_key, new_key in primary_key.config.replace.items():
                if old_key not in existing_fields:
                    raise ValueError(
                        f"PK field '{old_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[3]"
                    )
                if old_key not in old_pks:
                    raise ValueError(
                        f"PK field '{old_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[4]"
                    )
                if new_key not in existing_fields:
                    raise ValueError(
                        f"PK field '{new_key}' was not found in the PK fields collection of the target table '{primary_key.table}'[5]"
                    )
                new_pks.remove(old_key)
                new_pks.append(new_key)
            table_model.properties.primaryKeys = new_pks
            DBConfigModel._update_primary_keys_in_relationships(db_schema, primary_key, table_model)

    @staticmethod
    def _update_primary_keys_in_relationships(
        db_schema: DBSchemaModel, primary_key: PrimaryKey, table_model: ModelItem
    ):
        # update all fks that reference this table
        for old_key, new_key in primary_key.config.replace.items():
            pointing_join_pairs: list[JoinPair] = db_schema.get_pointing_fks_on_field(table_model.name, old_key)
            for join_pair in pointing_join_pairs:
                join_pair.toAttribute = new_key
        for key_to_remove in primary_key.config.remove:
            pointing_relationships: list[RelationShip] = db_schema.get_pointing_relationships_on_field(
                table_model.name, key_to_remove
            )
            for rel in pointing_relationships:
                rel.joinPairs = list(filter(lambda jp: jp.toAttribute != key_to_remove, rel.joinPairs))

    def adapt_schema(self, db_schema: DBSchemaModel, db_semantics: SemanticsModel | None) -> DBSchemaModel:
        db_schema = DBConfigModel._filter_required_tables(db_schema, self.tables)
        db_schema = DBConfigModel._remove_redundant_relations(db_schema, self.tables)
        DBConfigModel._remove_fields(db_schema, self.tables)
        ref_tables = [t.table for t in db_semantics.referenceTables] if db_semantics else []
        DBConfigModel._add_fields(db_schema, self.fields, self.configuration, ref_tables)
        DBConfigModel._update_primary_keys(db_schema, self.primaryKeys)
        return db_schema

    def verify_extra_config(self):
        if bool(self.configuration.modifiedOnTargetField) ^ bool(self.configuration.sourceTableField):
            raise ValueError(
                "Both modifiedOnTargetField and sourceTableField must be specified, or neither of them. In the DB target schema config file"
            )

# SIG # Begin Windows Authenticode signature block
# MIIoLQYJKoZIhvcNAQcCoIIoHjCCKBoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA8hAYVeOffo28Y
# TXXJBsLyT4SYV4qiCIpqZmp5VB6agaCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBMe1Tz4Rdcnt638CWaK1Z9y
# JulxETKHT3dF+WzStjJ0MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAShOuvS3pPs8kMwnTpW5gmM9c1hdZsG29mNlWaIInl+MPInczg/vU/CEB
# zczmGpUjhtZX5Is9XsrTieury86ji4eTvibZnZ8Vqyf3UopEK9XN+ErH7AOJcL+3
# dIp5xYdSXqNYgiqdZPi0fwfBA3UfWzmr1JY6v1VqfdKzDPkSvSEvZRewkieStHFM
# vXrikIz6uKwcVgYoR9+Mhr9O2HDtqHN8VVxRCtcCG0HhOJ2JWROVy75ZcJotGPdL
# EoadiF6XV9GNiEEvD9+V6NeCsP4Fb9dONISX6CZLTMRmSMKXK724bb7YoFSas/KF
# x6gM9BYCG36tE0XQR1LllT4TYrOjRqGCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCC
# F38GCSqGSIb3DQEHAqCCF3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCAeyF7iu8wF81AyFhU69qKYGk6RPFDYY65yPFy0oLuBwIGaFuFPSif
# GBMyMDI1MDcxNjA0MjEzMC4zMjNaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHtMIIHIDCCBQigAwIBAgITMwAAAgTY4A4HlzJYmAABAAACBDANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQy
# NDdaFw0yNjA0MjIxOTQyNDdaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046OTYwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDw3Sbcee2d66vkWGTIXhfGqqgQGxQXTnq44XlUvNzF
# St7ELtO4B939jwZFX7DrRt/4fpzGNkFdGpc7EL5S86qKYv360eXjW+fIv1lAqDD3
# 1d/p8Ai9/AZz8M95zo0rDpK2csz9WAyR9FtUDx52VOs9qP3/pgpHvgUvD8s6/3KN
# ITzms8QC1tJ3TMw1cRn9CZgVIYzw2iD/ZvOW0sbF/DRdgM8UdtxjFIKTXTaI/bJh
# sQge3TwayKQ2j85RafFFVCR5/ChapkrBQWGwNFaPzpmYN46mPiOvUxriISC9nQ/G
# rDXUJWzLDmchrmr2baABJevvw31UYlTlLZY6zUmjkgaRfpozd+Glq9TY2E3Dglr6
# PtTEKgPu2hM6v8NiU5nTvxhDnxdmcf8UN7goeVlELXbOm7j8yw1xM9IyyQuUMWko
# rBaN/5r9g4lvYkMohRXEYB0tMaOPt0FmZmQMLBFpNRVnXBTa4haXvn1adKrvTz8V
# lfnHxkH6riA/h2AlqYWhv0YULsEcHnaDWgqA29ry+jH097MpJ/FHGHxk+d9kH2L5
# aJPpAYuNmMNPB7FDTPWAx7Apjr/J5MhUx0i07gV2brAZ9J9RHi+fMPbS+Qm4AonC
# 5iOTj+dKCttVRs+jKKuO63CLwqlljvnUCmuSavOX54IXOtKcFZkfDdOZ7cE4DioP
# 1QIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFBp1dktAcGpW/Km6qm+vu4M1GaJfMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQBecv6sRw2HTLMyUC1WJJ+FR+DgA9Jkv0lG
# sIt4y69CmOj8R63oFbhSmcdpakxqNbr8v9dyTb4RDyNqtohiiXbtrXmQK5X7y/Q+
# +F0zMotTtTpTPvG3eltyV/LvO15mrLoNQ7W4VH58aLt030tORxs8VnAQQF5BmQQM
# Oua+EQgH4f1F4uF6rl3EC17JBSJ0wjHSea/n0WYiHPR0qkz/NRAf8lSUUV0gbIMa
# wGIjn7+RKyCr+8l1xdNkK/F0UYuX3hG0nE+9Wc0L4A/enluUN7Pa9vOV6Vi3BOJS
# T0RY/ax7iZ45leM8kqCw7BFPcTIkWzxpjr2nCtirnkw7OBQ6FNgwIuAvYNTU7r60
# W421YFOL5pTsMZcNDOOsA01xv7ymCF6zknMGpRHuw0Rb2BAJC9quU7CXWbMbAJLd
# Z6XINKariSmCX3/MLdzcW5XOycK0QhoRNRf4WqXRshEBaY2ymJvHO48oSSY/kpuY
# vBS3ljAAuLN7Rp8jWS7t916paGeE7prmrP9FJsoy1LFKmFnW+vg43ANhByuAEXq9
# Cay5o7K2H5NFnR5wj/SLRKwK1iyUX926i1TEviEiAh/PVyJbAD4koipig28p/6HD
# uiYOZ0wUkm/a5W8orIjoOdU3XsJ4i08CfNp5I73CsvB5QPYMcLpF9NO/1LvoQAw3
# UPdL55M5HTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQ
# MIICOAIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjk2MDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQC6
# PYHRw9+9SH+1pwy6qzVG3k9lbqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7CEIlTAiGA8yMDI1MDcxNTE3MDQy
# MVoYDzIwMjUwNzE2MTcwNDIxWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDsIQiV
# AgEAMAoCAQACAgTJAgH/MAcCAQACAhQiMAoCBQDsIloVAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQELBQADggEBAEbo2SMzHtphnb9z16FzYHWd+rmYU8ZtJhkjRky3gx/X
# QTBq2E3hoPWqenRwoVx2fm/ZuCChOx2CBMYURvdNMr0DRDkhY1iLkJcFY3sPYjif
# JQQ9FleEE7Lj328wRbybj4XLkvRr/j4ddkwwSUvMyR7c0GK+UtpZcAnCSK7zOX4i
# eMqVDXu0cYNF+RE1cZFxQKMN/qmQRR/9W0CPst0YS6Uj11ncW3kD2sbRO83NXikX
# pI66ggjD0P/4ldt37IaSijD0gevMDOaaM9YRMhv8PH0wte09TuNOuPLMxbrRtR/z
# i6uFHFBaISY+i2WvzcItas8LVXzVlgGTsrzkxeOvoK0xggQNMIIECQIBATCBkzB8
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1N
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAgTY4A4HlzJYmAABAAAC
# BDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEE
# MC8GCSqGSIb3DQEJBDEiBCDxOcSnZlcXtWuKHgciw3R+C90XxxzP/pPkbH5rAUqi
# qDCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIPnteGX9Wwq8VdJM6mjfx1GE
# Jsu7/6kU6l0SS5rcebn+MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAIE2OAOB5cyWJgAAQAAAgQwIgQgnedygsl7eM9bche5VWmhvPZA
# ntavG7bTRb8+urLQXRAwDQYJKoZIhvcNAQELBQAEggIA4EqlgxClcVyWQVIryTE8
# UdmcvaQSY+PPOqxQ3NuJF8glLBuj8xBXq4+Oilo0mNtQtgoO28nfOrlB4zqpS/Gj
# bwhEU2MmKK8VltmgxPFUMl3jL2BSHfg5OWW5hKkjcXo92WvvT3UIKAfGC9NC4eaE
# b2YIbjVV0rYsp0hCOZ7sYM6srEBeiM7rAZmxzI2kbxy+gVczb6J16t2uhLu2+vIC
# 8Z/dQqtOlJ43kB4TobL6yLDPZ6lEF0jw4aif+bFoyDFEaP2fWQRwFbCF3J3CMO/K
# sclJdKAIbejFGwSGdwF4zpR0/dBsqJErhhJgsjptDenwmQrGMNwefET4JbUS+AcL
# v4xvrkOmpQ4nmlytIH1g6g9e14cOrroeOv3+MZ6dxOAPhULeb9rU7VelJAKEAV83
# +LcbXWxMooe8iCI7sFnJzQbSgnmWBQ1vCwn6AZ9GbCip+PQ2o2b5L939UgspvQXa
# +tiNvwnFPU9c8JHgiAN9m7pfeIxyYmaOFo+bzz5gVej3pKIGz63SxQv3AoY7rXO6
# 3oK5B4+cj2BzmD7WnhvL7LgJk/+Mq60WMhPGw8dCLmC5J6tU4QK3/f1zAgmMpZf5
# 0ytM9Jlsbhnon0Do0+zJCeRNjnVfDarbmB7Ty/3By8Mx5POtikLzJKUkx7zdDMQF
# 25S1mFQour7qJDs5d/sdhRE=
# SIG # End Windows Authenticode signature block