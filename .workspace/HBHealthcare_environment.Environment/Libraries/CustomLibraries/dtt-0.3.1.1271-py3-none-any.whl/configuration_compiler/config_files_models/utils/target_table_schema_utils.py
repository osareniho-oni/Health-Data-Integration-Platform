from typing import FrozenSet, Optional
from configuration_compiler.spec_models.target_table_schema import TargetTableSchemaExt
from common.model.types import DataSourceId
from dmf.model.target_configuration.target_table_schema import (
    TargetTableColumn,
    TableRelation,
)
from pyspark.sql.types import DataType


class TargetTableSchemaUtils:
    @staticmethod
    def primary_keys(t: TargetTableSchemaExt) -> FrozenSet[TargetTableColumn]:
        return frozenset(column for column in t.columns if column.is_primary_key)

    @staticmethod
    def is_extension(t: TargetTableSchemaExt) -> bool:
        return bool(TargetTableSchemaUtils.parent_table(t))

    @staticmethod
    def parent_table(t: TargetTableSchemaExt) -> Optional[DataSourceId]:
        """Returns the table which is extended by this table, if any.
        currently this solves only a single field PK and a single parent table
        """
        if len(TargetTableSchemaUtils.primary_keys(t)) != 1:
            return None
        pk = next(iter(TargetTableSchemaUtils.primary_keys(t)))
        for relation in t.relations:
            for fk in relation.foreign_keys:
                if fk.from_attribute == pk.name:
                    return relation.to_entity
        return None

    @staticmethod
    def columns_names(t: TargetTableSchemaExt) -> FrozenSet[str]:
        return frozenset(column.name for column in t.columns)

    @staticmethod
    def get_column(t: TargetTableSchemaExt, column_name: str) -> TargetTableColumn:
        for column in t.columns:
            if column.name == column_name:
                return column
        raise ValueError(
            f"Field '{column_name}' was not found in the field list {t.id}: [{list(TargetTableSchemaUtils.columns_names(t))}]"
        )

    @staticmethod
    def get_column_type(t: TargetTableSchemaExt, column_name: str) -> DataType:
        return TargetTableSchemaUtils.get_column(t, column_name).type

    @staticmethod
    def get_table_pointed_by_fk(t: TargetTableSchemaExt, fk: str) -> Optional[DataSourceId]:
        for relation in t.relations:
            for foreign_key in relation.foreign_keys:
                if foreign_key.from_attribute == fk:
                    return relation.to_entity
        return None

    @staticmethod
    def get_relations_pointing_to_table_id(t: TargetTableSchemaExt, table_id: str) -> set[TableRelation]:
        relations = set()
        for relation in t.relations:
            if relation.to_entity == table_id:
                relations.add(relation)
        return relations

    @staticmethod
    def get_relations_pointing_to_table(t1: TargetTableSchemaExt, t2: TargetTableSchemaExt) -> set[TableRelation]:
        return TargetTableSchemaUtils.get_relations_pointing_to_table_id(t1, t2.id)

    @staticmethod
    def get_self_relations(t: TargetTableSchemaExt) -> set[TableRelation]:
        return TargetTableSchemaUtils.get_relations_pointing_to_table(t, t)

    __pointed_by_cache = {}

    @staticmethod
    def pointed_by(t: TargetTableSchemaExt) -> FrozenSet[DataSourceId]:
        key = t.id
        if key in TargetTableSchemaUtils.__pointed_by_cache:
            return TargetTableSchemaUtils.__pointed_by_cache[key]
        result = frozenset(relation.from_entity for relation in TargetTableSchemaUtils.get_self_relations(t))
        TargetTableSchemaUtils.__pointed_by_cache[key] = result
        return result

# SIG # Begin Windows Authenticode signature block
# MIIoKQYJKoZIhvcNAQcCoIIoGjCCKBYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCdNr7rKeJ6TDE8
# 1tnyfWZdymCzlrKYOa+/G3dnEYzdhKCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgkwghoFAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICOHqTFZkNpgUeR2M/scsmBr
# AMFoKxd4TFgd6YNS1srlMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAdvjv7szHk/hfYBOQHzigLlI/vnYupUgPGrhoygqxDh9Dw1607Gaw3i9e
# Q3KG9gLxaysW9qDWakWo+eUHw24TcJr+QFZ13PQFxc3i5Q1Qf/l+6miOtYmczGy9
# Vb4VIdDLFkQRs4/qcRKp8NoftwQBaEm4X/0frvf4HGlZqNmbYqasoI4KxlXnmyci
# cEW7Crg0GJDGzUCDcrYd/jxdPGy9ex9YO/nGB8j9MBwJj/iDCta6rSJ3n4wP0MP2
# UJtpwOs7YeWByI8LvvfWTkEf/vDr8cS3lMDkwFcw+U0tsxjjfGn/fqrRz5ZAXrqR
# x8mmpUGy4W09UmxgK0mAL4Bs/pM+caGCF5MwghePBgorBgEEAYI3AwMBMYIXfzCC
# F3sGCSqGSIb3DQEHAqCCF2wwghdoAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBnbfXLE9aosxQhDHsDxiBba/U0mCZjDlAzMqgwsJcmUAIGaEsq9PG8
# GBIyMDI1MDcxNjA0MjEyOC44N1owBIACAfSggdGkgc4wgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjozNzAzLTA1
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# EeowggcgMIIFCKADAgECAhMzAAACCkeyFNnusrMPAAEAAAIKMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI1MDEzMDE5NDI1
# N1oXDTI2MDQyMjE5NDI1N1owgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjozNzAzLTA1RTAtRDk0NzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBALLs3PASlvsGnACT0snTRerfRNxONzA1nzRPEC0BuFJo
# naTCckDUC78Oj398QGMAe/oya23d+Y8N4gmdDtUF4irxFx+NyOts8iDfADm/kxB+
# U81IE069xdE/59mcDLQQsPN+ckecKRk2xBRnsYXsvFQtMo5hjZgnDhOuZweiGRjo
# OMJnLGGqYZDDB1uOg9ZFti7+jMV6b/J8k/KNUGqXXTrxtxWHnwDxzkIPpNY38ve7
# 43L7s7z4O96vqoFPjgTLul89kxnUeLvK8Iu/ksbNIHqjY4PkYhnLvPiSHxRgd3OO
# f1bH5BnbbfdIlAq1mGkju4d/egxODTNqdB/PuaC515+YYGtASDWjHef7dOLOHQP3
# NWY1A/2wWOw9C00Zn0gP0fwD6QUifHiatLEDZLIYw5BzGUYzfSS0gozeKoK4URT0
# IdUyk33j/V+XhPo+icn7+hYmoWVq1i4wq/Zny6KmucVwDEKk6wMhUE70rW8d4AyJ
# BBSVwT0IPnfojVgueY7aodqA8+ZeF04asdScJS2inbV6W6QeHvmr/nMf46c16Snm
# 52mNA1kK+JgBl0ewueRTQ19QCvqvVSoNxKrXJ/lGLCKYHxKOx2YeWXiA+OapWLT+
# uaczWgARCbc/JZxNBCJtguK4o3tjiKjlslNXCb69FFuknlQv8PfcL//uqcdt6hYF
# AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUAq8XQQSPgDI99jxb+quwC9+1nCQwHwYD
# VR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZO
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBc
# BggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMC
# B4AwDQYJKoZIhvcNAQELBQADggIBALCTc9bQLKM5qpcIw66xN17t6nYLA//FXUne
# j0oCIpJ2rxrZRHlEIdiGcmx56bB4xQfaQ15+mcCHYGfwfaikPO0MmSPw5hF38pDK
# wTXY3Bpjco7ABbxGDw51e/l9Rkiw5aCmuQJAzRWgUd1dgTGQk3cTMFtQJTDfJviA
# AU8rnpP7pw+kjwwkskJBcc0yC2LZBmFf0qR9EB98VgwVymxsj6jOILkGuuTffrVw
# kUeGAQlHQnjaeplMZKBSkMYdJkBEao1wBXmH45AMt4XandRHH8/oxxSDWcnaAw9g
# GwP5vB30HRz9chn0y3e6OUQs+mSKOMJ1JnGHO7YzdJlYmvnu5j4UL4uym8g4fU6m
# h9qeHckYOiw1wAS73JQxYqwQEyeAPpVZBJBhnpf0XzTMKh5nBOrSL0C6OdjPPHlb
# Z8SBl6NG7orUYIBKbO02VgmUAKOpp9ZGh9OqQmFX8na/3tfeu4O9+m465ChS1UDB
# esOwbY04G69Wyjkp1bniEFKzP/j45EHiouerj8Y21qNQeispEocY6AWjwMppcb5Q
# 0A3CEY3EdsgtJrn0/ETEyAKMFE/fzbzIYqyq5ITPMs1afPlp/1mZ4fjzT1/Ai20j
# jUmS6Jj1fqGYyYti/w5jfi+84r7PLGRL70FQtUA/qC37JodoGWuWfwaLj90GvbLp
# Kuv/nqDQMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az
# /1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V2
# 9YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oa
# ezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkN
# yjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7K
# MtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRf
# NN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SU
# HDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoY
# WmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5
# C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8
# FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TAS
# BgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1
# Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUw
# UzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3
# DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEz
# tTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJW
# AAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G
# 82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/Aye
# ixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI9
# 5ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1j
# dEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZ
# KCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xB
# Zj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuP
# Ntq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvp
# e784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCA00w
# ggI1AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScw
# JQYDVQQLEx5uU2hpZWxkIFRTUyBFU046MzcwMy0wNUUwLUQ5NDcxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVANEA
# xUmUDpsqr3dWe7dSQmCbkeVhoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDsISf2MCIYDzIwMjUwNzE1MTkxODE0
# WhgPMjAyNTA3MTYxOTE4MTRaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOwhJ/YC
# AQAwBwIBAAICE9owBwIBAAICEo8wCgIFAOwieXYCAQAwNgYKKwYBBAGEWQoEAjEo
# MCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG
# 9w0BAQsFAAOCAQEAPxD8Kcyd9o5vgplxTUrK2DuFwMaOCOMr2OZXXn+WVMsrRibF
# 4CL2agwk7o+Q1cJ9/2v1uQlRz0K+PDTLxzUjxrKy/agdbmTrD6QTa9TPY1tERiAJ
# cWCXD3SpGpKMtpBdvHRHufBnGzaB1Jps6DrYBPbUg/zMCZ9J2ex1y6vn0EayOabT
# cePvh5fBiyN8hhSL3rUAL34PVOq2vpZHA87cITE54nKBAnDuUv5dygphIPaup+I+
# IU9bUARmcBho4Yx77evt0J5WOQNR7uaGqw7fLDFLrIAc+7qOxrsvsUmaaM493pxp
# TGHRb397whBxWdDVFx64f6DWTsHg/b99GVMbLTGCBA0wggQJAgEBMIGTMHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAACCkeyFNnusrMPAAEAAAIKMA0G
# CWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJ
# KoZIhvcNAQkEMSIEIGjKCwb16uo069F6N5LNhXRV3o6+sIUFbWaaVpHv5VieMIH6
# BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgTZrL/LR6kr9fdnTcpNyWioTy70hd
# G107sx7HSHD35JowgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAAgpHshTZ7rKzDwABAAACCjAiBCCStvClOMqA2a1FsCoW52W8t2lj9KPZ
# YuItgkW0CMzGkTANBgkqhkiG9w0BAQsFAASCAgA2W7eG9xpUbKNrsOH4jQW+/pUL
# oY1DQKINqGpV7NX2nPo9Ov7j7LD3f4GiebEqnHwB/h/O9mpNmhVbkQvEnebg7vrK
# erbLfmrp+w3nVwS06TWfJ8XUo67/XwPkIvTxS9qLyt6g/cak1Z6kokBNPpaDu/f0
# 6yPBHHc3od1bwr7mq6jgY2iBBup1Zjh+aQPZhBXR+kFOux8fcBq+j6DGOppnlPsz
# dpltezCMEkxXp+AnePcuoqmkXFHTFxwX1+L7bmI/1Pgnu1ccEGNinwr/BlRD0D7S
# +SimLmmoq8nJSBTU2hpT4pdLDkjvcgQ+R1Myku0/eepmw6ItCdVOSs9MhQlwtXy6
# n+J0y/Z7lnhSH6Jzn2t86Bf0ZNHHLZCSirbfJmI/DiPlP2DENu/nO1mZW9YveD4P
# RKx4s97cZKRdYS1vvMAHVYNVFX6CHdkoTGR/Wgqab7LtR6jraJp40oo3zw42/aVu
# LPbx1UkAkjyWjyd3NF7ECr0uM7VoDlXhAC78QQ50fGBmZdUUw8auQjvoWz2wvcgL
# yrCmVWWtE3fNdikq+6VHXvhXFAX3Vg3r2HBsLlW+DBMnlnPal+p9XVpjLCniMMzx
# KzLlXYdK/DTT+6IGkBWupdXiB6TRIYhuT3DdV8MsOG/shnvjZEnoGFnOABLWdb+b
# Asz0M87GsO+JyE6zFQ==
# SIG # End Windows Authenticode signature block