import re
from enum import Enum
from typing import Any, Optional, Union

from configuration_compiler.config_files_models.models_base import FieldTypeEnum, NoExtrasBaseModel
from pydantic import Field, field_validator
from pydantic.functional_validators import model_validator


class DataFormatEnum(str, Enum):
    parquet = "parquet"
    delta = "delta"
    csv = "csv"


class DeleteBehaviorEnum(str, Enum):
    hard = "hard"
    soft = "soft"
    de_id = "de-id"


class Storage(NoExtrasBaseModel):
    dataFormat: Optional[DataFormatEnum] = Field(None, description="The format of data in storage, e.g., delta.")
    connectionStringUri: Optional[str] = Field(
        None,
        description="The path to the root folder of the data in storage, or a path to a file describing for each table a different path.",
    )
    lakeDBName: Optional[str] = Field(
        None,
        title="Source Lakehouse name",
        description="When Fabric Lakehouse is used as a source, the lakeDBName will be used as the source database name, e.g., a Fabric Lakehouse name."
        "\nIn this case the environment file should not contain a source section",
    )


class PKInternalExternalPair(NoExtrasBaseModel):
    internalField: str = Field(
        ...,
        title="Internal field",
        description="The internal field that is used as PK, e.g., contactid.")
    externalField: str = Field(
        ...,
        title="External field",
        description="The external field that is used as keyring between multiple data sources, e.g., integrationKey.",
    )


class QueryTable(NoExtrasBaseModel):
    name: str = Field(..., description="A table name that is used in a source query, e.g., in a join.")
    alias: Optional[str] = Field(None, description="An alias to be used in the source query for that table.")


class TargetAnchorTable(NoExtrasBaseModel):
    tableName: str = Field(
        ...,
        title="Target anchor table",
        description="A target table which the source writes to its single PK field.")


class IntermediateTable(NoExtrasBaseModel):
    intermediateTable: str = Field(
        ...,
        description="Table that is used by DMF to create a relationship graph between anchor table and a target table.",
    )


class TargetTable(NoExtrasBaseModel):
    targetTable: str = Field(..., description="An anchor table.")
    intermediateTables: list[IntermediateTable] = Field(
        ...,
        title="Target table",
        description="Collection of tables in the graph between an anchor table and the last table in the collection.",
    )


class TargetField(NoExtrasBaseModel):
    enabled: Optional[bool] = Field(
        True,
        title="Target field",
        description="A flag to indicate if the target field should be processed by DMF and validated in the DTT VS Extension.",
    )
    tableName: str = Field(
        ...,
        title="Goal table name",
        description="The table DMF uses to decide what table(s) to write to. "
        "\nIf the source field is a FK, The tableName should NOT be the real target table, "
        "but either a reference table or a regular table that the FK relates to. "
        "\nThen, the fieldName should be the PK field of that table. "
        "\nDMF will find the actual tables and fields to write to, "
        "by searching for valid table paths from anchor tables to tableName, "
        "e.g., 'contact.maritalstatusstate' target should be 'MaritalStatus.MaritalStatusId'. "
        "\nIn all other cases, the target table should be the real target table.",
    )
    fieldName: str = Field(
        ...,
        title="Goal field",
        description="The name the field in the target table.")
    condition: Optional[str] = Field(
        None,
        title="Condition",
        description="The target field will be processed if the condition, a Spark SQL scalar expression evaluates to true.",
    )
    fieldValue: Optional[Union[str, float, int, bool]] = Field(
        None,
        title="Field value",
        description="When specified, the Spark SQL expression will be evaluated and used instead of the source field value.",
    )
    targetField: Optional[str] = Field(
        None,
        title="Target field",
        description="When the source field is a FK and the tableName specified is a FK related table (e.g. Customer), "
        "\nnthen, DMF resolves the actual tables and fields to write to, "
        "it may find ambguities that require additional information from the author, e.g., "
        "a RelatedCustomer table has two FK to Customer (from, to). "
        "In this case, the author should specify the target field name in the target table, e.g., 'FromCustomerId'.",
    )
    paths: Optional[list[str]] = Field(
        None,
        title="Paths",
        description="In the rare cases in which DMF cannot decipher a non ambiguous graph path, the adapter should provide the correct path.",
    )
    _paths_split_pattern = re.compile(r"<-|->")

    description: Optional[str] = Field(
        None,
        title="Description",
        description="A description of the target field.")
    # TODO: remove? isLookup is currently not used
    isLookup: Optional[bool] = Field(False, description="A flag to indicate that the target field is a lookup field")

    @field_validator("paths", mode="before")
    @classmethod
    def split(cls, s):
        if s is None:
            return None
        if not re.search(cls._paths_split_pattern, s):
            raise ValueError(f"paths {s} should contain at least one '<-' or '->' arrow")
        return re.split(cls._paths_split_pattern, s)

    @field_validator("paths", mode="after")
    @classmethod
    def path_len_is_more_than_1(cls, paths):
        if paths is None:
            return None
        for path in paths:
            if len(path) < 2:
                raise ValueError("paths should have more than one table")
        return paths

    @model_validator(mode="after")
    def field_value_and_condition_mutually_exclusive(self) -> "TargetField":
        if not self.enabled:
            return self
        condition = self.condition
        fieldValue = self.fieldValue
        if condition and fieldValue:
            raise ValueError(
                f"Cannot define both 'fieldValue' and 'condition' properties for a target field:"
                f"'{self.fieldName}' in table '{self.tableName}' in the adpater file. fieldValue='{fieldValue}', condition='{condition}'"
            )
        return self


class UniqueKeyItem(NoExtrasBaseModel):
    fieldName: str = Field(
        ...,
        description="A target field name that is part of the uniquely collection of target fields.",
    )


class TargetFields(NoExtrasBaseModel):
    fields: list[TargetField] = Field(
        None,
        title="Target fields",
        description="A collection of target fields which may be in multiple tables."
    )
    uniqueKey: Optional[list[UniqueKeyItem]] = Field(
        None,
        description="A collection of some target fields that defines the uniqueness of record to be written, e.g., create "
        "history records for each email type (work/home).",
    )


class SourceField(NoExtrasBaseModel):
    fieldName: str = Field(
        ...,
        title="Source field",
        description="A source field name or a calculation name. A Calculation name should not be an existing field name.",
    )
    fieldType: FieldTypeEnum = Field(
        ...,
        title="Source field type",
        description="The source field type.")
    enabled: Optional[bool] = Field(
        True,
        title="Enabled",
        description="Defines whether DMF should process the field or skip it. \nAlso, whether the DTT VS Extension should validate the field.",
    )
    targetFields: TargetFields = Field(
        ...,
        title="Target fields",
        description="The Fields the data is written to. A source field may write to multiple target fields in different tables.",
    )
    fieldCalculatedValue: Optional[str] = Field(
        None,
        title="Calculated field",
        description="A spark SQL scalar expression.")
    description: Optional[str] = Field(
        None,
        title="Description",
        description="A description of the source field.")
    enforceKeyHarmonization: Optional[bool] = Field(
        False,
        title="Enforce field value harmonization",
        description="Set the property to true when:\n"
        "\t1. bypassHarmonization property on the parent table is set to True\n"
        "\t2. There is a  need for DMF to override the table definition and harmonize "
        "the current field, e.g., a field was introduced in a query (based on the "
        "parent table) so it should not be bypassed",
    )


class SourceTable(NoExtrasBaseModel):
    """Source table to map into target"""

    description: Optional[str] = Field(
        None,
        title="Source table description",
        description="A description of the source table.")
    tableName: str = Field(
        ...,
        title="Source table name",
        description="The name of the source table. If query is defined, "
        "the name provides additional semantics and cannot be the same as an existing table.",
    )
    query: Optional[str] = Field(
        None,
        title="Source query",
        description="Spark SQL query to use as a source, .e.g., performing join with between two or more tables. The result fields "
        "can be mapped to target tables and fields..",
    )
    modifiedonField: str = Field(
        ...,
        title="Modified field",
        description="The field used to identify data updates when performing incremental updates.",
    )
    stateField: Optional[str] = Field(
        None,
        title="State field",
        description="The field used to identify state changes, e.g., customer becomes inactive/active.",
    )
    deletedField: Optional[str] = Field(
        None,
        title="Deleted field",
        description="The field used to identify that record was deleted in the source system.",
    )
    deleteBehavior: Optional[DeleteBehaviorEnum] = Field(
        None,
        title="Deleted behavior",
        description="Delete behavior defines whether to hard delete these records\\tag them as deleted\\tag as deleted "
        "and de-id target fields.",
    )
    targetAnchorTables: list[TargetAnchorTable] = Field(
        ...,
        title="Target anchor tables",
        description="Target Tables to be used as anchors. A source table can have multiple target anchor tables, "
        "e.g., contact->Customer, Location. "
        "\nDMF will resolve all valid tables paths from anchor tables to all target tables "
        "and write to intermeidate tables as needed.",
    )
    pkInternalExternalPairs: list[PKInternalExternalPair] = Field(
        [],
        title="Internal/External field pairs",
        description="Field pairs that define strong relationship between two field, .e.g contactId and intergrationKey "
        "defined respectively, specify that the same mapping value (number) created for the integrationKey (string) will be "
        "used also for contactId.",
    )
    enabled: Optional[bool] = Field(
        True,
        title="Enabled",
        description="Defines whether DMF will process all fields in this table or skip them. "
        "\nAlso, whether the DTT VS Extension should validate the table and its source fields.",
    )
    sourceFields: list[SourceField] = Field(
        ...,
        title="Source fields",
        description="Collection of source fields to be processed.")
    bypassKeysHarmonization: Optional[bool] = Field(
        False,
        title="Bypass PK/FK values harmonization",
        description="When set to True, DMF will use, as is, values that are mapped "
        "to PK/FKs in target tables (with no harmonization).\nApplies to both target "
        "standard tables and reference tables",
    )

    @model_validator(mode="after")
    def paths_mis_definition(self) -> "SourceTable":
        if not self.enabled:
            return self
        paths_by_target_table = {}
        for source_field in self.sourceFields:
            if not source_field.enabled:
                continue
            for target_field in source_field.targetFields.fields:
                if not target_field.enabled:
                    continue
                paths = target_field.paths
                if paths:
                    if target_field.tableName in paths_by_target_table:
                        raise ValueError(
                            f"paths are defined for target table {target_field.tableName} more than once in source table {self.tableName}"
                        )
                    paths_by_target_table[target_field.tableName] = paths

        return self

    @model_validator(mode="after")
    def validate_paths_have_valid_tables(self) -> "SourceTable":
        if not self.enabled:
            return self
        anchors = [anchor.tableName for anchor in self.targetAnchorTables]
        for source_field in self.sourceFields:
            if not source_field.enabled:
                continue
            for target_field in source_field.targetFields.fields:
                if not target_field.enabled:
                    continue
                paths = target_field.paths
                if paths:
                    paths_anchors = []
                    for path in paths:
                        anchor_table, target_table = path[0], path[-1]
                        if anchor_table not in anchors:
                            raise ValueError(
                                f"first table {anchor_table} in path {path} is not defined as a target anchor table in source table {self.tableName}"
                            )
                        if target_table != target_field.tableName:
                            raise ValueError(
                                f"last table {target_table} in path {path} is not the same as the target table {target_field.tableName} in source table {self.tableName}"
                            )
                        paths_anchors.append(anchor_table)

                    if len(paths_anchors) != len(set(paths_anchors)):
                        raise ValueError(
                            f"paths {paths} in source table {self.tableName} should have only one path for every anchor table"
                        )
        return self


def json_schema_extra(schema: dict[str, Any], model) -> None:
    for prop in schema.get("properties", {}).values():
        prop.pop("title", None)


class RawAdapterModel(NoExtrasBaseModel, json_schema_extra=json_schema_extra):
    name: str = Field(...,
                      title="Adapter name",
                      description="The adapter name defines the data source, e.g. Healthcare-Dataverse."
                      "\n1. It is used internally to associate a source table's external/external ID mapping columns to a specific source."
                      "\n2. It is part of the SourceTable lineage column that DMF adds to each target table.")
    description: str = Field(
        "",
        title="Adapter description",
        description="Description of the adapter")
    version: str = Field(
        ...,
        title="Adapter version",
        description="Version of the adapter")
    sourceDomain: str = Field(
        "",
        title="Source name",
        description="Defines the sourceDomain to be used for reference data mappings (e.g., Healthcare-Dataverse)."
        "\nWhen 'reference data mapping update' API is called,"
        "\nusing the current adapter, the associated source schema, and a collection of mapping folders (i.e., Industry\\Source, Customer\\Source) relaing to the source,"
        "\nit will use the sourceDomain as the name of the collected mappings."
        "\nThen, when DMF transforms data and resolves reference values,"
        "\nit will first filter the reference data mapping table by the source domain,"
        "\nto make sure only relevant mapping values for the current data source are used.",
    )
    source: Optional[Storage] = Field(None, description="Source data storage")
    target: Optional[Storage] = Field(None, description="Target data storage")
    dbSourceSchema: Optional[str] = Field(
        None,
        title="Source schema",
        description="Source schema file path (tables/fields names/types/descriptions)."
        "\nIf the property is missing or empty, VS Code will use 'dbSourceSchema.json' file in the adapter's folder"
        "\nThe file is used for validation and auto-complete of source related properties"
    )
    dbTargetSchema: Optional[str] = Field(
        None,
        title="Target schema",
        description="Target schema file path (tables/fields names/types/descriptions, relationships and primary keys...)."
        "\nIf the property is missing or empty, VS Code will use 'dbTargetSchema.json' file in the adapter's folder"
        "\nThe file is used for validation and auto-complete of target related properties"
    )
    dbTargetSchemaConfig: Optional[str] = Field(
        None,
        title="Target schema configuration",
        description="Target schema config file path."
        "\nIf the property is missing or empty, VS Code will use 'dbTargetSchemaConfig.json' file in the adapter's folder"
        "\nThe file defines operational fields (e.g., partitions) DTT will add to target tables"
    )
    dbSemantics: Optional[str] = Field(
        None,
        title="Target semantics",
        description="Target semantics file path."
        "\nIf the property is missing or empty, VS Code will use 'dbTargetSemantics.json' file in the adapter's folder"
        "\nThe file provides additonal semantics to the target tables, e.g., what tables are reference tables, duration tables..."
    )
    dbSemanticsConfig: Optional[str] = Field(
        None,
        title="Target semantics configuration",
        description="Target semantics config file path."
        "\nIf the property is missing or empty, VS Code will use 'dbTargetSemanticsConfig.json' file in the adapter's folder"
        "\nThe file provides additonal operational semantics to the target tables, e.g., what are the partitions field's expression..."
    )
    dmfEnvConfig: Optional[str] = Field(
        None,
        title="Envrionment",
        description="Environment file path."
    )
    defaultReferenceValue: Optional[Union[int, None]] = Field(
        None,
        title="Default reference value",
        description="When reference value is not found during transformation "
        "\nand 'UponMissingReferenceValues' is false, DMF will use this value instead .",
    )
    failUponMissingReferenceValues: bool = Field(
        False,
        title="Missing reference value failure behavior",
        description="If false, DMF will fail during transformation when a reference value is missing in the mapping table. "
        "\nIf true, DMF will use the defaultReferenceValue instead.",
    )
    queryTables: list[QueryTable] = Field(
        [],
        description="Tables used in source tables queries, e.g., when joining two or more tables. Optional, "
        "relevant only if the source is defined as an ADLS storage and not as a Database "
        "Database may be a Fabric Lakehouse.",
    )
    sourceTables: list[SourceTable] = Field(
        ...,
        title="Source tables",
        description="Tables and fields mappings between source and target.")
    jsonSchema_: str = Field(
        "",
        title="Adapter schema definition",
        description="The json schema of the adapter. Used by the DTT VS Extension to validate and autocomplete the adapter properties",
        alias="$schema",
    )

# SIG # Begin Windows Authenticode signature block
# MIIoRgYJKoZIhvcNAQcCoIIoNzCCKDMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB+jK1HPQmbLz9N
# vH9GbPpnwK0mNCjP1RiCqVqheXW9/qCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiYwghoiAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIGs8T/OKyP84t0mg5UDozKI6
# +5Kx8dFq8pLeTh9MWxzWMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEABAp7OEZ1uaK83aVDSVbf6xifjNC8Co8Y3CN76fT6TcjaIPJjdyR0VGwX
# yK3+Bt6/yc9yYPMxwMEfutsr4PakeAfxw7OeHsiWvJg6Tp0z9TLMSLQcv0C7fWNX
# 9F4h+DhoeKuS9tqCXBErBInKfzPh1hocjbfrQBbVEI40sYpcEvq3lBoOdl+DVVWb
# 9Ow5dHhwtxDR07ZD7baaiD+bdlYbwVZ5c6+OAauuNF7a5eaALkZpQJ+gjzILroyB
# 8m84yOZnzYl/h5IryXxDCX5BDZ4smH/V5yYyNNwy4UdhZ7j7mhvwu0vsruA7qpNi
# 6KgCwLRpSJcaDvZVJQjg9RjMOjnx/6GCF7AwghesBgorBgEEAYI3AwMBMYIXnDCC
# F5gGCSqGSIb3DQEHAqCCF4kwgheFAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFaBgsq
# hkiG9w0BCRABBKCCAUkEggFFMIIBQQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBrdCDrTYRflJK4aGf2pAePlftCuGmEQRtHBjQVqYNyXgIGaFmRX1Nq
# GBMyMDI1MDcxNjA0MjIwOC40OTdaMASAAgH0oIHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo2NTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCEf4wggcoMIIFEKADAgECAhMzAAAB9ZkJlLzxxlCMAAEAAAH1MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI0
# MDcyNTE4MzEwMVoXDTI1MTAyMjE4MzEwMVowgdMxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjY1MUEt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAzO90cFQTWd/WP84IT7JM
# IW1fQL61sdfgmhlfT0nvYEb2kvkNF073ZwjveuSWot387LjE0TCiG93e6I0HzIFQ
# BnbxGP/WPBUirFq7WE5RAsuhNfYUL+PIb9jJq3CwWxICfw5t/pTyIOHjKvo1lQOT
# WZypir/psZwEE7y2uWAPbZJTFrKen5R73x2Hbxy4eW1DcmXjym2wFWv10sBH40aj
# Jfe+OkwcTdoYrY3KkpN/RQSjeycK0bhjo0CGYIYa+ZMAao0SNR/R1J1Y6sLkiCJO
# 3aQrbS1Sz7l+/qJgy8fyEZMND5Ms7C0sEaOvoBHiWSpTM4vc0xDLCmc6PGv03CtW
# u2KiyqrL8BAB1EYyOShI3IT79arDIDrL+de91FfjmSbBY5j+HvS0l3dXkjP3Hon8
# b74lWwikF0rzErF0n3khVAusx7Sm1oGG+06hz9XAy3Wou+T6Se6oa5LDiQgPTfWR
# /j9FNk8Ju06oSfTh6c03V0ulla0Iwy+HzUl+WmYxFLU0PiaXsmgudNwVqn51zr+B
# i3XPJ85wWuy6GGT7nBDmXNzTNkzK98DBQjTOabQXUZ884Yb9DFNcigmeVTYkyUXZ
# 6hscd8Nyq45A3D3bk+nXnsogK1Z7zZj6XbGft7xgOYvveU6p0+frthbF7MXv+i5q
# cD9HfFmOq4VYHevVesYb6P0CAwEAAaOCAUkwggFFMB0GA1UdDgQWBBRV4Hxb9Uo0
# oHDwJZJe22ixe2B1ATAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAcwxmVPaA9xHf
# fuom0TOSp2hspuf1G0cHW/KXHAuhnpW8/Svlq5j9aKI/8/G6fGIQMr0zlpau8jy8
# 3I4zclGdJjl5S02SxDlUKawtWvgf7ida06PgjeQM1eX4Lut4bbPfT0FEp77G76hh
# ysXxTJNHv5y+fwThUeiiclihZwqcZMpa46m+oV6igTU6I0EnneotMqFs0Q3zHgVV
# r4WXjnG2Bcnkip42edyg/9iXczqTBrEkvTz0UlltpFGaQnLzq+No8VEgq0UG7W1E
# LZGhmmxFmHABwTT6sPJFV68DfLoC0iB9Qbb9VZ8mvbTV5JtISBklTuVAlEkzXi9L
# IjNmx+kndBfKP8dxG/xbRXptQDQDaCsS6ogLkwLgH6zSs+ul9WmzI0F8zImbhnZh
# UziIHheFo4H+ZoojPYcgTK6/3bkSbOabmQFf95B8B6e5WqXbS5s9OdMdUlW1gTI1
# r5u+WAwH2KG7dxneoTbf/jYl3TUtP7AHpyck2c0nun/Q0Cycpa9QUH/Dy01k6tQo
# mNXGjivg2/BGcgZJ0Hw8C6KVelEJ31xLoE21m9+NEgSKCRoFE1Lkma31SyIaynbd
# YEb8sOlZynMdm8yPldDwuF54vJiEArjrcDNXe6BobZUiTWSKvv1DJadR1SUCO/Od
# 21GgU+hZqu+dKgjKAYdeTIvi9R2rtLYwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIDWTCCAkECAQEwggEBoYHZpIHWMIHTMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVT
# Tjo2NTFBLTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAJsAKu48NbR5YRg3WSBQCyjzdkvaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsF
# AAIFAOwhD0gwIhgPMjAyNTA3MTUxNzMyNTZaGA8yMDI1MDcxNjE3MzI1NlowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA7CEPSAIBADAKAgEAAgIZIwIB/zAHAgEAAgIS
# FjAKAgUA7CJgyAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBCwUAA4IBAQBC8hEgq8Yg
# RkBZBuR4rsvF9WZEsowj0qyXc2HYITSyH6Wha7CLNyZGG5cgcgQ6gDyUeVG+SG5w
# RgFwyD36T5sCr2GesWm2WZ9CeJxTOoZHQwmnQH8Yg2QPpRDA4WCIaB5YNIVF3hdJ
# Mi2h1I4pQuxRgLD9v64MuUMTLSEy/hckDCaSsOfM2LaGxid/CmjHF7uksV+BYm+n
# jRWRiBlOupYrflAUAtCyDU7lHDIY0JK8USfjs+PIHTY7r4q5CKHZouWHXugstkfb
# 0kqPjl8Fs1G/zYqvq+uqRkzl5/TXStblFK8Nl1xIGrOPdcj5ZAY6y7+o65cobrXH
# 4lBuOvhIvs8dMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAH1mQmUvPHGUIwAAQAAAfUwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgbK934jEQ
# q8Gg5xF1GKXp8IvX9tlw1Jqw/jTyTPFTTGAwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCDB1vLSFwh09ISu4kdEv4/tg9eR1Yk8w5x7j5GThqaPNTCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB9ZkJlLzxxlCMAAEA
# AAH1MCIEIFIRAI/CkwMFeuFe98pp1Ibst4SehE1pOWyBH46vTVA9MA0GCSqGSIb3
# DQEBCwUABIICAIzbEe3OAFHq0ve9WjH1gjeN57250JlpiQmeysT3vcpFegLBSqaa
# ziUK3HfNPvM/a+VdMIn+Az7+ygwERgdnxidhpqijqNR6xRVq6Ro07mTsNgDDa8HF
# OelID6BI9T8Pp1YCzmFZyxlQBmkQP5thxiZvAxkctbaB+D2EkM9Ocu69aTd0s/1R
# 9awVeorkucmoHWA0uZSvR7AI3cuOtXEYoEcLVZKl8lBf3Le1I54gcbbYalMYYYpB
# SuDstRVEs1hoZxFsb5JipBZr9zSQMUPLodtvrTtWzCkEnF8QStCIVQE7XP3T7R3e
# yxKAmHovWK3MRcCuECZH0uAWASo6e+5MQnerLaLoy/C8UByzeLrAELF6VX5ehzLE
# qjF+YDZngSrjhNSzHcd2ZWLTX3UCQFRkSZvMNDyk7bm0jyd3nj9tu8pnUdjbI7Wo
# czPKICZV7j7k0EFnbXVV7rUjyEFEPagobOtfgpaaVDaIbrl7RIJUvJtk9R+raMxk
# 305lhO7Guqaj1Edqt+47NnhExkPZJLrrgfUpSHIQxALsUtxOdyq+ZQRScaMZm9o/
# L7U4iyLuOgLk0dPXVO/2GHmh919zWksgk7Z2TzWDj5FOr4J4fkNy+dIDk/juyqfx
# 4hZBdC6oZ0h1BG/q9BsnEOOc838xTXLtwmnfLEh1JdND6/xhENgMf9Rl
# SIG # End Windows Authenticode signature block