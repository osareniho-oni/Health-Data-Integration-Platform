from dataclasses import dataclass
from typing import Any, List, Set, Tuple

from configuration_compiler.graph.graph import NoNodeException
from configuration_compiler.graph.levenshtein_distance import levenshtein_distance
from configuration_compiler.config_files_models.adapter.model import TargetField
from configuration_compiler.config_files_models.common.types import AnchorId
from configuration_compiler.config_files_models.utils.target_table_schema_utils import TargetTableSchemaUtils
from configuration_compiler.schema_graph import SchemaGraph
from configuration_compiler.spec_models.target_table_schema import TargetTableSchemaExt
from common.model.types import DataSourceId, TargetId


@dataclass(frozen=True)
class TableNamesPair:
    left: str
    right: str


class PathResolutionException(Exception):
    pass


class TablesPathResolver:
    """given a list of anchor tables names, and a single target table name,
    this class computes all the possible paths between any anchor to the target.
    It then generates a list of table pairs that correspond to each pair of connected tables
    along that path.
    high level flow:
    1. compute all the possible paths between any anchor to the target
    2. filter out paths that are invalid see `_is_valid_path`
    3. sort the paths by their score (low score means better path)- see `_path_score`
    4. take the best path (for each anchor-target pair)
    5. for each path, generate a list of table pairs that correspond to each pair of connected tables
    """

    def __init__(self,
                 anchor_tables: List[str],
                 schema_graph: SchemaGraph,
                 target_tables_schemas: dict[DataSourceId, TargetTableSchemaExt],
                 tables_paths: dict[DataSourceId, dict[TargetId, List[TargetId]]],
                 source_table_name: str,
                 target_field: TargetField):
        self.anchor_tables = anchor_tables
        self.target_field = target_field
        self.schema_graph = schema_graph
        self.target_tables_schemas = target_tables_schemas
        self.tables_paths = tables_paths
        self.source_table_name = source_table_name

    def generate_pairs(self) -> Set[TableNamesPair]:
        pairs = set()
        paths_overrides_per_source = self.tables_paths.get(self.source_table_name, {})
        specific_paths = paths_overrides_per_source.get(self.target_field.tableName, None)
        if specific_paths:
            paths = [specific_paths]
        else:
            paths = self._compute_shortest_paths(self.anchor_tables, self.target_field.tableName)
        for path in paths:
            pairs |= self.tables_path_to_tables_pairs(path)
        return pairs

    def tables_path_to_tables_pairs(self, path) -> Set[TableNamesPair]:
        path_pairs = set()
        for left, right in self._generate_pairs_from_path(path):
            path_pairs.add(TableNamesPair(left, right))
        return path_pairs

    def get_proposed_paths(self) -> List[List[TargetId]]:
        """for each anchor return the shortest path to the target table
        1. for each anchor and target pair there are multiple paths potentially
        2. for each set of paths, filter out the paths that are not valid (see _is_path_valid)
        """
        anchors = self.anchor_tables
        target = self.target_field.tableName
        try:
            paths_to_target = {anchor_id: self.schema_graph.shortest_paths(anchor_id, target) for anchor_id in anchors}
            paths_to_target_filtered = self._filter_all_paths(paths_to_target)

        except NoNodeException as e:
            raise PathResolutionException(
                f"Could not find path from {anchors} to {target}. Is a table missing from the schema?"
            ) from e
        return self._flatten_one_level(list(paths_to_target_filtered.values()))

    def _compute_shortest_paths(self, anchors: List[str], target: str) -> List[List[TargetId]]:
        """for each anchor return the shortest path to the target table
        1. for each anchor and target pair there are multiple paths potentially
        2. for each set of paths, filter out the paths that are not valid (see _is_path_valid)
        3. for each set of paths, take the best path (see _take_approximated_best_paths)
        """
        try:
            paths_to_target = {anchor_id: self.schema_graph.shortest_paths(anchor_id, target) for anchor_id in anchors}
            paths_to_target_filtered = self._filter_all_paths(paths_to_target)
            paths_to_target_approximated = self._take_approximated_best_paths(paths_to_target_filtered)

        except NoNodeException as e:
            raise PathResolutionException(
                f"Could not find a valid path from an anchor table to target table '{target}'. None of anchor tables '{anchors}' fits"
            ) from e
        return paths_to_target_approximated

    def _is_path_valid(self, path: List[TargetId]) -> bool:
        if not self._is_path_starts_with_correct_target_field(path):
            return False
        if self._is_trivial_path(path):
            return True
        if self._path_has_3_tables_with_intermediate_duration_or_extension(path):
            return True
        if self._path_has_4_tables_with_intermediate_duration_and_extension(path):
            return True
        return False

    def _generate_pairs_from_path(self, path: List[str]) -> Set[Tuple[str, str]]:
        if len(path) == 1:
            return {(path[0], path[0])}

        pairs = set()
        for i in range(len(path) - 1):
            pairs.add((path[i], path[i + 1]))
        return pairs

    def _is_trivial_path(self, path: List[TargetId]) -> bool:
        return len(path) <= 2

    def _path_has_3_tables_with_intermediate_duration_or_extension(self, path: List[TargetId]) -> bool:
        if len(path) != 3:
            return False
        intermediate_table = self.target_tables_schemas[path[1]]
        return intermediate_table.is_duration_table or TargetTableSchemaUtils.is_extension(intermediate_table)

    def _path_has_4_tables_with_intermediate_duration_and_extension(self, path: List[TargetId]) -> bool:
        """
        can be:
        1. anchor -> extension-> duration -> target (like customer and marital_status)
        2. anchor -> duration -> ? -> extension (like branch and bank)
        """
        if len(path) != 4:
            return False
        _, table1, table2, table3 = [self.target_tables_schemas[target_id] for target_id in path]
        if TargetTableSchemaUtils.is_extension(table1) and table2.is_duration_table:
            # e.g. customer <- individualCustomer -> cusrtomerMaritalStatus <- maritalStatus
            return True
        if table1.is_duration_table and TargetTableSchemaUtils.is_extension(table3):
            # e.g. customer <- customerRelatedChannel -> channel <- branch
            return True
        return False

    def _take_approximated_best_paths(self, paths_to_target_by_anchor: dict[AnchorId, List[List[TargetId]]]) -> List[List[TargetId]]:
        best_paths = []
        for paths_to_target in paths_to_target_by_anchor.values():
            best_paths.append(self._take_best_path(paths_to_target))
        return best_paths

    def _take_best_path(self, paths_to_target: List[List[TargetId]]) -> List[TargetId]:
        """if there are multiple paths of the same length, take the one with the smallest levenshtein distance
        between the intermediate tables and the outer tables
        TODO: this is a heuristic, maybe we can do better
        """
        if len(paths_to_target) == 1:
            return paths_to_target[0]
        path_length = len(paths_to_target[0])
        if path_length <= 2:
            raise PathResolutionException(f"Duplicate paths of length <= 2 found: '{paths_to_target}'")

        # at this point there is more than a single path, and the length is at least 3
        return min(paths_to_target, key=self.path_score)

    def path_score(self, path: List[TargetId]) -> int:
        """return levenshtein distance
        between the intermediate tables and the outer tables
        assume that the path is at least of length 3
        """
        intermediate_tables_str = " ".join(path[1:-1])
        outer_tables_str = " ".join((path[0], path[-1]))
        distance = levenshtein_distance(intermediate_tables_str, outer_tables_str)
        return distance

    def _filter_all_paths(self, paths_to_target: dict[AnchorId, List[List[TargetId]]]) -> dict[AnchorId, List[List[TargetId]]]:
        filtered_paths = {}
        for anchor_id, paths in paths_to_target.items():
            filtered_for_anchor = list(filter(self._is_path_valid, paths))
            if filtered_for_anchor:
                filtered_paths[anchor_id] = filtered_for_anchor
        return filtered_paths

    def _is_path_starts_with_correct_target_field(self, path: List[TargetId]) -> bool:
        if self.target_field.targetField is None:
            return True  # no target field, so any path is valid
        first_table_in_path = self.target_tables_schemas[path[0]]
        if len(path) == 1:
            relations = TargetTableSchemaUtils.get_self_relations(first_table_in_path)
        else:
            next_table = self.target_tables_schemas[path[1]]
            # test in both directions as the relation can be first->nex of next->first
            relations = TargetTableSchemaUtils.get_relations_pointing_to_table(first_table_in_path, next_table)
            relations |= TargetTableSchemaUtils.get_relations_pointing_to_table(next_table, first_table_in_path)
        for relation in relations:
            for fk in relation.foreign_keys:
                if fk.from_attribute == self.target_field.targetField:
                    return True
        return False

    def _flatten_one_level(self, nested_list: List[List[Any]]) -> List[Any]:
        flattened_list = []
        for sublist in nested_list:
            flattened_list.extend(sublist)
        return flattened_list

# SIG # Begin Windows Authenticode signature block
# MIIoKgYJKoZIhvcNAQcCoIIoGzCCKBcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCjqJtj1EDRaUFx
# M1sgyHcf7Bebd7yAQB0BpFhBpiU3RqCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgowghoGAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOlkbKtKYg10jG12PsXajavE
# 2ObH4GEptfm4TgO/JDXjMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAA3yjlp0OQPxl25ersrhefW0Niwt57KQ9HbCyUNNN5V/I5mbjBrxSNgSj
# ghpohz+OUQEt4qLJsflN36KPn6BEIF1hmM7T3X3+VjDnNRW+JoNHmDOFokhm0jGU
# dcXY9/uW2IXZmOZoAT2GIzeNBjVDB4Cbt/9yMZEI6NDt3pByxLjI9v3sz8zhIHNY
# RMUM0ucHuhTTMOAtZ4Ji6yB0ByAVE8BhkKISP3G1+r+qccOPPdRWAi0Ehh7buimP
# HhpYNMldD/1oV1X+b/keOEbfhMeSEr2h/zja9DfUa3Vzm/cKsGKI7P2iXSBdrmj7
# IPKZ60xxPHdMA9TpbaXoKB/5ZgkSCKGCF5QwgheQBgorBgEEAYI3AwMBMYIXgDCC
# F3wGCSqGSIb3DQEHAqCCF20wghdpAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsq
# hkiG9w0BCRABBKCCAUEEggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCknPhCWFitiu5oLkPswB0qUhe87TenPbfbtiwjqVIdYAIGaEsGCWKN
# GBMyMDI1MDcxNjA0MjIzOS4wMTVaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046REMwMC0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# ghHqMIIHIDCCBQigAwIBAgITMwAAAgO7HlwAOGx0ygABAAACAzANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yNTAxMzAxOTQy
# NDZaFw0yNjA0MjIxOTQyNDZaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046REMwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQChl0MH5wAnOx8Uh8RtidF0J0yaFDHJYHTpPvRR16X1
# KxGDYfT8PrcGjCLCiaOu3K1DmUIU4Rc5olndjappNuOgzwUoj43VbbJx5PFTY/a1
# Z80tpqVP0OoKJlUkfDPSBLFgXWj6VgayRCINtLsUasy0w5gysD7ILPZuiQjace5K
# xASjKf2MVX1qfEzYBbTGNEijSQCKwwyc0eavr4Fo3X/+sCuuAtkTWissU64k8rK6
# 0jsGRApiESdfuHr0yWAmc7jTOPNeGAx6KCL2ktpnGegLDd1IlE6Bu6BSwAIFHr7z
# OwIlFqyQuCe0SQALCbJhsT9y9iy61RJAXsU0u0TC5YYmTSbEI7g10dYx8Uj+vh9I
# nLoKYC5DpKb311bYVd0bytbzlfTRslRTJgotnfCAIGMLqEqk9/2VRGu9klJi1j9n
# VfqyYHYrMPOBXcrQYW0jmKNjOL47CaEArNzhDBia1wXdJANKqMvJ8pQe2m8/ciby
# DM+1BVZquNAov9N4tJF4ACtjX0jjXNDUMtSZoVFQH+FkWdfPWx1uBIkc97R+xRLu
# PjUypHZ5A3AALSke4TaRBvbvTBYyW2HenOT7nYLKTO4jw5Qq6cw3Z9zTKSPQ6D5l
# yiYpes5RR2MdMvJS4fCcPJFeaVOvuWFSQ/EGtVBShhmLB+5ewzFzdpf1UuJmuOQT
# TwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFLIpWUB+EeeQ29sWe0VdzxWQGJJ9MB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQD
# AgeAMA0GCSqGSIb3DQEBCwUAA4ICAQCQEMbesD6TC08R0oYCdSC452AQrGf/O89G
# Q54CtgEsbxzwGDVUcmjXFcnaJSTNedBKVXkBgawRonP1LgxH4bzzVj2eWNmzGIwO
# 1FlhldAPOHAzLBEHRoSZ4pddFtaQxoabU/N1vWyICiN60It85gnF5JD4MMXyd6pS
# 8eADIi6TtjfgKPoumWa0BFQ/aEzjUrfPN1r7crK+qkmLztw/ENS7zemfyx4kGRgw
# Y1WBfFqm/nFlJDPQBicqeU3dOp9hj7WqD0Rc+/4VZ6wQjesIyCkv5uhUNy2LhNDi
# 2leYtAiIFpmjfNk4GngLvC2Tj9IrOMv20Srym5J/Fh7yWAiPeGs3yA3QapjZTtfr
# 7NfzpBIJQ4xT/ic4WGWqhGlRlVBI5u6Ojw3ZxSZCLg3vRC4KYypkh8FdIWoKirji
# dEGlXsNOo+UP/YG5KhebiudTBxGecfJCuuUspIdRhStHAQsjv/dAqWBLlhorq2OC
# aP+wFhE3WPgnnx5pflvlujocPgsN24++ddHrl3O1FFabW8m0UkDHSKCh8QTwTkYO
# wu99iExBVWlbYZRz2qOIBjL/ozEhtCB0auKhfTLLeuNGBUaBz+oZZ+X9UAECoMhk
# ETjb6YfNaI1T7vVAaiuhBoV/JCOQT+RYZrgykyPpzpmwMNFBD1vdW/29q9nkTWoE
# hcEOO0L9NzCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZI
# hvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# MjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAy
# MDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25Phdg
# M/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPF
# dvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6
# GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBp
# Dco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50Zu
# yjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3E
# XzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0
# lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1q
# GFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ
# +QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PA
# PBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkw
# EgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxG
# NSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARV
# MFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAK
# BggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG
# 9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0x
# M7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmC
# VgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449
# xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wM
# nosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDS
# PeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2d
# Y3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxn
# GSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+Crvs
# QWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokL
# jzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL
# 6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNN
# MIICNQIBATCB+aGB0aSBzjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOkRDMDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQDN
# rxRX/iz6ss1lBCXG8P1LFxD0e6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUAAgUA7CEDDDAiGA8yMDI1MDcxNTE2NDA0
# NFoYDzIwMjUwNzE2MTY0MDQ0WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDsIQMM
# AgEAMAcCAQACAiBkMAcCAQACAhJ0MAoCBQDsIlSMAgEAMDYGCisGAQQBhFkKBAIx
# KDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZI
# hvcNAQELBQADggEBAFjYSlpWrbNgyZnbW/aG4fZYcLajxH49WkfqUTQ2EWdSUZqz
# GapgNgiBRHCRtTpKi9Dt5wSeCVvV5nUa9xFiPyzna0B03ylURgqSIqVVYmFcNAOZ
# QVZdCJkJ7WD+IFYDYgGGlh2kL3JhbR7V2GL2Gw7iHABDi8O4cekwmqaS+51BcZj4
# AUz/dC1j/mW4ek8GQbwYUYDx/p0nYUeEci9FmCtLdl2HSHe7+qj2Z30i/QYdZbgS
# vUqIIeMfcUW0vI7A/6HBcLkl6rkORG3FrqJjBkDQ+ltmZsy4tfzvEy0xdtUs9VC5
# mKUDR6cXM+y+W8dLu3eCka+JY9EjGq9LSmFxJwsxggQNMIIECQIBATCBkzB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAgO7HlwAOGx0ygABAAACAzAN
# BglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8G
# CSqGSIb3DQEJBDEiBCCSPTPEhISj/j3qULv+TlfChSPWQb55gvxCbLNgOP/RCDCB
# +gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIEsD3RtxlvaTxFOZZnpQw0DksPmV
# duo5SyK9h9w++hMtMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAAIDux5cADhsdMoAAQAAAgMwIgQgkx2oYYn89E2ic3oQVIoJXcgMlulJ
# YdpQai+30+jTIg0wDQYJKoZIhvcNAQELBQAEggIALCTpeLCpdZdht0tJNIlPUS72
# aElSlClDCv54VAD0VAFhghff6LjxWqDccq3+QpAueESNBL2ZnHwhHBqyw9NtMxcP
# Ov2b1SLX6YobF4mJMbwUuWv/OJRJNiz7U1OO8YbE4m+iFqRRjE73cfGWRsKPSs+B
# 6siThqh/tv+KQJcoOcmATOfFCz/KJRMAPrJakH7rMRx3lv9YHe3rM8p9uHA5EPwt
# dFkWOsk06YgWIAFAv0o/ESbvJTnu3NroAhb+8DNf0PxIG4faGdefuMElfd73jkgR
# Se5EsrCFZ2HTilwvb5PkgDPD2yJeyygefih5MEV2dZmT/gCu7qntRfBUupgYGs2M
# KD+/BZybMYEfkLwRzkm2YbRnxsipTm02fcc/PizDmYZUlst+ylQu9jta5IbMWaMV
# T5xjPi/0/KBwQhvC+TPuE5wg/q2hkS94h4UgZP7LwBcHsWsu2qtxE2GfvZjXVu3n
# c6jrSzZmLBLbTnHV66uSxqT4o5JnIdLqDEOrf+fBVCyMrrw/hOQ+N3LSsNvMjQKq
# zLDcXjrXpMTaSt70Y+rVvUqrya60IH4P/8kBOd7adeqCPjFbwrJenZKJZsmHZgTH
# p8jq0UQhJqb04Bm3g5gUYa+/rPt9+io9VdB6kC9PsXmOdnJPw+fwQo5laAe8KXTH
# H6K2P6JZzGhKslgXcH4=
# SIG # End Windows Authenticode signature block