from collections import defaultdict
from typing import List, Optional, Set

from configuration_compiler.column_transformation.data_transformation_generator import DataTransformationGenerator
from configuration_compiler.column_transformation.empty_transformations_cleaner import EmptyTransformationsCleaner
from configuration_compiler.column_transformation.fk_transformations_generator import (
    ForeignKeysTransformationsGenerator,
)
from configuration_compiler.column_transformation.ids_mapping_helper import IdsMappingHelper
from configuration_compiler.column_transformation.missings_pks_filler import MissingPKsFiller
from configuration_compiler.column_transformation.relationships_generator import Relationship, RelationshipsGenerator
from configuration_compiler.column_transformation.tables_path_resolver import TableNamesPair, TablesPathResolver
from configuration_compiler.config_files_models.adapter.ext_model import AdapterModel
from configuration_compiler.config_files_models.adapter.model import SourceField, SourceTable, TargetField
from configuration_compiler.schema_graph import SchemaGraph
from configuration_compiler.spec_models.target_table_schema import TargetTableSchemaExt
from common.model.types import DataSourceId, TargetId
from dmf.model.target_configuration.target_transformation import ColumnTransformation


class ColumnsTransformationsParser:
    """
    This class is responsible for parsing the transformations between the source and target columns.
    It uses the following classes:
    - TablesPairGenerator: generates all the possible pairs of tables that can be used to generate the transformations
    - TablesPathResolver: resolves the path between two tables
    - DataTransformationGenerator: generates the transformations between two tables
    - ForeignKeysTransformationGenerator: generates the transformations between two tables based on the foreign keys
    - MissingPKsFiller: generates the transformations between two tables based on the missing primary keys
    - EmptyTransformationsCleaner: cleans the empty transformations

    High level flow:
    1. for each adapter source table:
        a. Generate all the possible pairs of tables, and the relation between them.
            for each relation- compute the required transformation of foreign key
        b. Generate the explicit transformations as listed in the adapter (data and primary keys)
        c. Remove the `empty` transformations- empty transformations are transformations for tables
            that only transform the PKs and for that table there are no data columns transformations.
    """

    def __init__(
        self,
        dmf_adaptor: AdapterModel,
        target_tables_schemas: dict[DataSourceId, TargetTableSchemaExt],
    ):
        self.transformations: dict[DataSourceId, dict[TargetId, Set[ColumnTransformation]]] = defaultdict(
            lambda: defaultdict(set)
        )
        self.dmf_adaptor = dmf_adaptor
        self.schema_graph = SchemaGraph(target_tables_schemas)
        self.target_tables_schemas = target_tables_schemas
        self.ids_mapping_helper = IdsMappingHelper(self.target_tables_schemas)

    def parse_column_transformations(self):
        """
        Parses the column transformations for each transformation defined in the adapter.

        This function iterates over each source table in the adapter, computes the relationships for all of the source table related mappings,
        generates the required transformations for the source table, fills in any unmapped primary keys, and cleans
        transformations without data. The parsed transformations are stored in the `transformations` attribute of the class.

        Returns:
            dict: A dictionary where the keys are the source table names and the values are dictionaries.
                  Each inner dictionary has target table IDs as keys and sets of ColumnTransformation objects as values.
        """
        for source_table in self.dmf_adaptor.source_tables:
            relationships = self._compute_relationships_for_source_table(source_table)
            self._generate_required_transformations_for_source_table(relationships, source_table)
            self._fill_in_unmapped_primary_keys(source_table.tableName)
            self._clean_transformations_without_data(source_table.tableName)
        return self.transformations

    def _clean_bidirectional_relationships_with_anchor(self,
                                                       relationships: Set[Relationship],
                                                       anchors: List[str]) -> Set[Relationship]:

        def _is_bidirectional_relationship_with_anchor(relationship_to_anchor: Relationship, other_relationship: Relationship) -> bool:
            return other_relationship.origin.id == relationship_to_anchor.destination.id and other_relationship.destination.id == relationship_to_anchor.origin.id

        relationships_to_anchors: Set[Relationship] = set()
        result: Set[Relationship] = set()

        for relationship in relationships:
            if relationship.destination.id in anchors:
                relationships_to_anchors.add(relationship)
            else:
                result.add(relationship)

        for relationship_to_anchor in relationships_to_anchors:
            is_bidirectional = False
            for any_other in result:
                is_bidirectional = is_bidirectional or _is_bidirectional_relationship_with_anchor(relationship_to_anchor, any_other)
            if not is_bidirectional:
                result.add(relationship_to_anchor)

        return result

    def _compute_relationships_for_source_table(self, source_table: SourceTable):
        """
        Computes all the relationships between each target and all anchor tables for a given source table.

        This function iterates over each source field in the given source table, and for each source field,
        it iterates over each target field. For each target field, it computes the table names pairs and
        then computes the relationships for these pairs.

        Args:
            source_table (SourceTable): The source table for which to compute the relationships.

        Returns:
            Set[Relationship]: A set of Relationship objects representing the relationships between each target
                               and all anchor tables for the given source table.
        """
        anchors = [anc.tableName for anc in source_table.targetAnchorTables]
        relationships: Set[Relationship] = set()
        for source_field in self.dmf_adaptor.source_fields_on_source_table(source_table):
            for target_field in self.dmf_adaptor.target_fields_on_source_field(source_field):
                table_names_pairs = self._compute_tables_names_pairs(anchors, source_table, target_field)
                relationships |= self._compute_relationships(table_names_pairs)
        relationships = self._clean_bidirectional_relationships_with_anchor(relationships, anchors)
        return relationships

    def _generate_required_transformations_for_source_table(
        self, relationships: Set[Relationship], source_table: SourceTable
    ):
        data_transformations = self._generate_data_transformations(source_table)
        fk_transformations = self._generate_fk_transformations(relationships, source_table, data_transformations)
        self._update_transformations(fk_transformations | data_transformations, source_table)

    def _generate_fk_transformations(
        self,
        relationships: Set[Relationship],
        source_table: SourceTable,
        data_transformations: Set[ColumnTransformation],
    ):
        """
        Generates transformations based on the foreign keys. The foreign keys are computed from the relationships.
        If a foreign key transformation is already explicitly defined, it is skipped.

        Args:
            relationships (Set[Relationship]): A set of relationships for which to generate the transformations.
            source_table (SourceTable): The source table for which to generate the transformations.
            data_transformations (Set[ColumnTransformation]): A set of existing data transformations.

        Returns:
            Set[ColumnTransformation]: A set of ColumnTransformation objects representing the foreign key transformations
                                       for the given relationships and source table.
        """
        transformations = set()
        for relationship in relationships:
            if self._relationship_fk_is_already_explicitly_defined(relationship, data_transformations):
                continue
            transformations |= ForeignKeysTransformationsGenerator(
                self.dmf_adaptor, relationship, source_table, self.target_tables_schemas, self.ids_mapping_helper
            ).generate_fks_transformations()
        return transformations

    def _relationship_fk_is_already_explicitly_defined(
        self, realtionship: Relationship, data_transformations: Set[ColumnTransformation]
    ):
        for data_transformation in data_transformations:
            if data_transformation.transformation_target_id == realtionship.origin.id:
                for fk in realtionship.relation.foreign_keys:
                    if data_transformation.target_field_name == fk.from_attribute:
                        return True
        return False

    def _generate_data_transformations(self, source_table: SourceTable) -> Set[ColumnTransformation]:
        """
        Generates explicit transformations as listed in the adapter for the given source table.
        These transformations include both data and primary keys.

        Args:
            source_table (SourceTable): The source table for which to generate the transformations.

        Returns:
            Set[ColumnTransformation]: A set of ColumnTransformation objects representing the explicit transformations
                                       for the given source table.
        """
        transformations = set()
        for source_field in self.dmf_adaptor.source_fields_on_source_table(source_table):
            for target_field in self.dmf_adaptor.target_fields_on_source_field(source_field):
                if self._is_fk_transformation(target_field):
                    continue
                bypass_key_harmonization = bool(
                    source_table.bypassKeysHarmonization and not source_field.enforceKeyHarmonization
                )
                data_transformation = self._generate_explicit_transformations(
                    source_field, target_field, bypass_key_harmonization
                )
                if data_transformation:
                    transformations.add(data_transformation)
        return transformations

    def _is_fk_transformation(self, target_field: TargetField) -> bool:
        if target_field.targetField is not None and target_field.targetField != target_field.fieldName:
            return True
        return False

    def _compute_relationships(self, table_names_pairs: Set[TableNamesPair]) -> Set[Relationship]:
        return RelationshipsGenerator(self.target_tables_schemas).compute_relationships(table_names_pairs)

    def _update_transformations(self, all_transformations, source_table):
        """store created transformations
        some transformations are created more than once since paths between tables might overlap"""
        for transformation in all_transformations:
            source_transformations = self.transformations[source_table.tableName]
            target_transformations = source_transformations[transformation.transformation_target_id]
            target_transformations.add(transformation)

    def _generate_explicit_transformations(
        self, source_field: SourceField, target_field: TargetField, bypass_keys_harmonization: bool
    ) -> Optional[ColumnTransformation]:
        return DataTransformationGenerator(
            self.target_tables_schemas, self.ids_mapping_helper, bypass_keys_harmonization
        ).generate_data_transformation(source_field, target_field)

    def _compute_tables_names_pairs(
        self, anchors: List[str], source_table: SourceTable, target_field: TargetField
    ) -> Set[TableNamesPair]:
        path_resolver = TablesPathResolver(
            anchors,
            self.schema_graph,
            self.target_tables_schemas,
            self.dmf_adaptor.target_table_paths,
            source_table.tableName,
            target_field,
        )
        return path_resolver.generate_pairs()

    def _clean_transformations_without_data(self, source_table_name: str):
        """if we have fk transformations which refer tables without data transformations, we remove them.
        This is because we don't want to generate fk values for tables without data.
        for that matter, ref tables are not considered as tables with data always
        """
        transformations_from_source_table = self.transformations[source_table_name]
        EmptyTransformationsCleaner(self.target_tables_schemas).clean(transformations_from_source_table)

    def _fill_in_unmapped_primary_keys(self, source_table_name: str):
        transformations_from_source_table = self.transformations[source_table_name]
        MissingPKsFiller(self.target_tables_schemas, transformations_from_source_table).fill_in_unmapped_primary_keys()

# SIG # Begin Windows Authenticode signature block
# MIIoQQYJKoZIhvcNAQcCoIIoMjCCKC4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQse8BENmB6EqSR2hd
# JGAGggIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5uSEdBedeWVgv
# Lw6eRGCkJIrFjsCwoaRpIMS4toQw3aCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGiEwghodAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIDJ2ENu91WV8uKbbFV0yCpl4
# xrIeQyu6TSt8cir0VkYRMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAa6qPt3zf8n87U6Wbw5VctuslvG6opeHwLrClNnpOpDbhEA57vR6tXu2X
# ceD/ZIyI8+kVQk/VxF0sOThKPsI6bM4kwe8hk3tjv03tYJAEurOChhbxuuRD58LY
# nbh9VPReyRgjOqyBGfyPi5dUowYfUSu8NiQCiYfkShVjv5FQ/8HXSWCsZ6albnZ8
# l9BM46TtFZeIAYObLd4WYBqH9vrqR5lrrq8GVZK84OQ5oKiC0LnPv002g5//vmwG
# FCUTtlGQSeKI++d2y01t6mUgka84Psrj/u8/fXfYkeKdB7mhCV7L6dCNio7zWHau
# Vnm7Y24tqVCvLP23BCDGCi0jwjCmnaGCF6swghenBgorBgEEAYI3AwMBMYIXlzCC
# F5MGCSqGSIb3DQEHAqCCF4QwgheAAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCp9kFBtLMKF3Fk/1t0WftxpyuBp3IxDaxfUed0O9wUrgIGaC3A8vkm
# GBIyMDI1MDcxNjA0MjIwNS42NVowBIACAfSggdmkgdYwgdMxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVs
# YW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNO
# OjZCMDUtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIR+jCCBygwggUQoAMCAQICEzMAAAH2gy8malRdIsEAAQAAAfYwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjQw
# NzI1MTgzMTA0WhcNMjUxMDIyMTgzMTA0WjCB0zELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046NkIwNS0w
# NUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDRQl4sxH831Y8FmG4pUUX5
# 5Ylnrxa6N2PhfolHTlzE7kJ6k1ejXutVrPBYuSbkCNpWHX1lWMMKEfOKbGyhpfE2
# 7wgOCArCle+kAAi2/hTHnR71La5XB8q/nun0kob5DtU41KG6OXU0IyRyBKs92Z3/
# zNyyaHNw2hsuiasIAg5FnwjCFjLiyJVCV/U0qGXIDOaRYkPQ37rQiKiAUHODfIhK
# y+ug7HTHXFKLY+JEhCVNcTvgyCBkMgMqof+Fv0VPaQr+dX9peO6j0syutGafjihh
# gAN7+s73kX5Ibe666F/4fgiuJevSH2m0DpLAck9LZWZs1YKNBarkbhiStyps8xrH
# u81dTC7tPrkTx8U93Ui4T1GwbhMwBXteRcGimY81+8vSGPGDjiSlCffzhXjqj7N1
# CrLkr10OVab8nq9m2nnIDU/IPfD4dsa5tLSeIRDUvrAY6s9/MibQV06f7EWjjwRG
# X4XHD/c69czkJjUSqfMTOc+PMlzs4nCElVHdVAMeMFwQVM69L0TR2I27V6hzD5kK
# TPg+7+hC/6CpT5t/Evx7s8WS19EOUzoXI7OM/jO4jbmAPy073MmDqDp9Glplzjf2
# YBuSXfMJXNMsOByG/pLFBqMm2++hBpnFB/S1GI9xuvYdZ8yiqp326JDSFNQSEbjg
# UFJN5Q9l4R6dEJZp0JbgbwIDAQABo4IBSTCCAUUwHQYDVR0OBBYEFEjBmwm45wl9
# Jw9Zxdm4EDgHz0ryMB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8G
# A1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBs
# BggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUH
# AwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQDXeQGKsfVwe7VZ
# hHXKyPXbmiYa1DQ9pCQTPAZvvTG2pKgj6y9CKGyB1NjFo9+nYhUV2CNoxoGLzXAH
# z+e7zroV8Uop2F2nfCcxn3U+k/g6h7s1x/qogKSBK7CB0h1C+oTSHxVDlBbmwNXh
# DQmePh/sodjHg2IzwLiNPDxJC2y7FaJMfYeKR/dBgHvVrt0H3OAc6RbSGBQR5Y72
# aHbBaphL9DjwBKM6pjD+FrnihU59/bZZqgf78fF301MRT/i+W+xEgxZPSOyc0jvW
# NUCtPhD0G3pVKFbPKqtoTpIpShmsTAGlWwjQsyDZfeE4tuULW/Ezf7AzI6H3toU6
# zuwWe56a0jYx+PyqDXoFlMnFeWk+6tasb44GPgGhMOQL0DFdgHfIS27AyzulFYvL
# EjHD/BX1McpQab7H5UTQ84vCStIyCO6VJeSl8QsdZaIJWyUlsUggH/gCW/6NAlIo
# Am6j0IStubap4OT/OMliVhpUYzIq5hn65JFUoHaqQQ9wTMbV073MhrUynfYn7PNb
# c/uy4l+PDrazeEM4uT7qUxA5HTjH7ajXsbctx4uSTEmbjUSt2JOMCZ0KV6f3KXoe
# AykZLiiSMUIlf4Kk4VfuAEDc9XFBa5uKwBBsvkeBMUG1A0TNwJ2HUZjD/qfPM023
# 7QZCeehsF1184CKqTO8i2peO8bIrVDCCB3EwggVZoAMCAQICEzMAAAAVxedrngKb
# SZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIy
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXI
# yjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjo
# YH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1y
# aa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v
# 3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pG
# ve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viS
# kR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYr
# bqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlM
# jgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSL
# W6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AF
# emzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIu
# rQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIE
# FgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWn
# G1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEW
# M2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5
# Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBi
# AEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV
# 9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3Js
# Lm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAx
# MC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2
# LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv
# 6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZn
# OlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1
# bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4
# rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU
# 6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDF
# NLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/
# HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdU
# CbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKi
# excdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTm
# dHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZq
# ELQdVTNYs6FwZvKhggNVMIICPQIBATCCAQGhgdmkgdYwgdMxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVs
# YW5kIE9wZXJhdGlvbnMgTGltaXRlZDEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNO
# OjZCMDUtMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAVT15Kl3GzRrTokUi4YUciP8j7fqCBgzCB
# gKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBCwUA
# AgUA7CFmJzAiGA8yMDI1MDcxNTIzNDMzNVoYDzIwMjUwNzE2MjM0MzM1WjBzMDkG
# CisGAQQBhFkKBAExKzApMAoCBQDsIWYnAgEAMAYCAQACAV4wBwIBAAICEoMwCgIF
# AOwit6cCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQAC
# AwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQsFAAOCAQEAyaL6ewuw5Wj7ndei
# QGuO50ExeQWGuoe9xNoAvZM4qpsTWb/Fqii3nz81s7mktVDIW7OO73kW6yLiceo+
# p1ckm4qWZG4dPPIESeYH9x9tO24ZZnpl2a8D2xCmQ+4eFtPvfjVPh3Js15JKZ8nu
# qq5xZRE8KDp1MdczoF0kTvowKn9Vpf7cdc8Ol8Eips2hQwIc2KZVEkYi0h6mLN1p
# brX/nKUGknCcjO5yDSIGFk/25+XIBxJ5r64jo1/Nc5kB0GRaB/6c/vuer+Lq2dj4
# r7wzpo4CT12LLun1gNlDnR81PjMaANmLLlxKuWVbDoPdZ1sTykxgTWbM1Elux1au
# ShJpuTGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAAB9oMvJmpUXSLBAAEAAAH2MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG
# 9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIC/ebU4btTB/lQgZ
# MigfM0GR9uZmt93f3ojk/9GJ1OLcMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCB
# vQQgK2FM8ZRepuVEi0uH/DVy//GqDRFXbAmUZhfi5UIxtqIwgZgwgYCkfjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAfaDLyZqVF0iwQABAAAB9jAi
# BCAvYmF87RtX2f8Law4hrKx5yMHUX+xoLWWEXYJ+5d9KVjANBgkqhkiG9w0BAQsF
# AASCAgBOeml82/ivPQ5o2l24FptfgEYcV25GZf3BGGu5b1KAp+knTU4TA8+jpGOr
# IV6PmWQHUzFZmDYWFVgOIgnvHY2HrDex6jUBop7qtoJ6b+CftFQSed2sbpMkYCzf
# 0ik7b1ItGH4RGNkbneCS+PpA/PwrStXIgXKMaX5ZeLzbvW2I7s7nTNJun/EHcdLo
# 6m7YneuUYSbOVnaSbFkpfeOwxpgeifcbO2U3mXv/aUIp75l49Irffe5Z94nyL5Uo
# iPLzUODNf6OiW3JWmlEVrYyMubgR54L6BOZ4T8EDHlZepXRsjN51404Trt4EvZRF
# TGpg+QjYHijx49ocoKQJyMQsuOvs605VVsuKpqomU0BXZJ/CQdsIVBzcufXhCsVD
# mTUQtupVVj59BYJeGbzczS3Pz+H5+ql4e71h2vq/1sdEY379jnyvNBkrYxCeUjeV
# eN5wRdBAvRX20xunRoN800iQtEJYkby0j25NRdd1854QA67/7YxBlPKb2li3pQjw
# NmE0/WBAAOmHk3J7ZRLN3Nbo3kXsE6D0RfVFCjwwIObdvZfuHgxB+1fAdEfKAYZh
# HKBsKU9qS2xK51hSIetdL6OqDIvMsWZ4/JF+jZ+TtTI6+6Pd98RLNfXEuE0Bxp+Z
# ZmvD4RDa+Aul09hgcNZIDN9u/UygicGoIDlUw7uDr6xZtS99sQ==
# SIG # End Windows Authenticode signature block